1. Algorithm name and mathematical objective function

**Algorithm Name:** Greedy Adaptive-Threshold Coverage (GATC)  
**Mathematical Objective Function:**

Given a set of points \(P = \{x_1,\dots,x_N\}\subset\mathbb{R}^d\), a personalized distance threshold function \(\tau : P \to \mathbb{R}_{\ge 0}\), and a budget \(k \in \mathbb{N}\), the goal is to select a subset \(S \subseteq P\) of size \(k\) that maximizes the *coverage count*:

\[
F(S) \;=\; \bigl|\{\, x_i \in P \mid \exists\, x_j \in S \text{ with } \operatorname{dist}(x_i, x_j) \le \tau(x_i) \,\}\bigr|.
\]

In words, point \(x_j\) *covers* point \(x_i\) if \(x_j\) lies inside the closed ball of radius \(\tau(x_i)\) centered at \(x_i\). The objective counts how many points in \(P\) are covered by at least one chosen point. The optimization problem is

\[
\max_{S\subseteq P,\ |S|=k} F(S).
\]

---

2. Mathematical Formalization & Mapping Argument

**(a) Formalization as a pure mathematical optimization problem**

Let \((\mathcal{X}, d)\) be a finite metric space with \(|\mathcal{X}|=N\). For each \(x\in\mathcal{X}\) define a radius \(r_x > 0\) via the rule \(r_x = \operatorname{dist}(x, \operatorname{NN}_m(x))\), where \(\operatorname{NN}_m(x)\) is the \(m\)-th nearest neighbor of \(x\) (excluding itself). This yields a family of balls \(\mathcal{B} = \{B(x, r_x)\}_{x\in\mathcal{X}}\). The *weighted geometric maximum \(k\)-cover problem* asks for a set \(S\subseteq\mathcal{X}\) with \(|S|=k\) that maximizes \(\bigl|\bigcup_{x_j\in S} \{\,x_i \in\mathcal{X} : x_j \in B(x_i, r_{x_i})\,\}\bigr|\). Equivalently, we are finding a hitting set for the family of inverse balls: for each \(x_i\), the set of points \(x_j\) that can cover \(x_i\) is the ball \(B(x_i, r_{x_i})\). The objective is submodular and monotone.

**(b) Why the recalled mathematical theory is a natural solution**

The recalled theory on *geometric hitting set / set cover* provides greedy algorithms that achieve logarithmic (online) or \((1-1/e)\) (offline) approximation guarantees for covering problems defined by geometric proximity. Specifically, the greedy algorithm that iteratively picks the set covering the most uncovered elements (or, dually, the point that hits the most unhit ranges) is the canonical strategy for submodular maximization. The “improved greedy algorithm for set covering” (Chandu, 2015) generalizes this by selecting multiple elements per step, confirming the core idea that a stepwise coverage‑gain maximization is theoretically sound. Moreover, using an adaptive threshold derived from local neighbor distances instantiates the “geometric threshold spatial cutoff proximity filter” – the threshold adapts to the local density of the point cloud, acting as a data‑driven proximity criterion instead of a global constant. This fusion naturally solves the sensor placement / facility location variant of token selection where each candidate token can “serve” nearby tokens, and we want the selected subset to serve as many tokens as possible under a spatial bandwidth that respects the intrinsic geometry.

**(c) Computational Steps and PyTorch mapping**

| Theoretical step | PyTorch / Python realization |
|------------------|------------------------------|
| Compute all pairwise distances \(\operatorname{dist}(x_i,x_j)\) | `dist = torch.cdist(features, features, p=2)` (after optional L2 normalization) |
| Sort each row, extract the distance to the \(m\)-th neighbor as \(\tau(x_i)\) | `sorted_dists, _ = torch.sort(dist, dim=1)`; `tau = sorted_dists[:, m]` (skip column 0, the self‑distance) |
| Build coverage indicator matrix \(C_{ij} = \mathbf{1}[\operatorname{dist}(x_i,x_j) \le \tau(x_i)]\) | `cov = (dist <= tau.unsqueeze(1))` (bool tensor `[N,N]`) |
| Greedy selection: maintain a mask `uncovered[i]` of points not yet covered. At each step compute gain of every candidate \(j\): \(\text{gain}_j = \sum_{i:\ \text{uncovered}[i]} C_{ij}\) | `gains = (uncovered.unsqueeze(0) & cov.T).sum(dim=1)`; then `gains[selected] = -1` to exclude already‑chosen points |
| Pick candidate with maximum gain, update `uncovered` | `j = torch.argmax(gains).item()`, `uncovered &= ~cov[:, j]`; repeat \(k\) times |

---

3. Concrete forward computation graph derivation and PyTorch pseudocode

The algorithm operates **exclusively on `vision_tokens_clip`** (CLIP space) to respect the documented signal superiority and avoid any dimension‑mismatch issues with text embeddings. It returns indices and the corresponding embeddings from `vision_tokens` (LLM projector output).

```python
import torch
import torch.nn.functional as F

def gatc_selection(
    vision_tokens_clip: torch.Tensor,   # [N, D_clip] e.g. [576, 1280]
    vision_tokens: torch.Tensor,        # [N, D_llm]  e.g. [576, 3584]
    target_vision_tokens: int,
    m: int = 15,                        # neighbor rank for adaptive threshold
    normalize: bool = True
):
    """
    Greedy Adaptive-Threshold Coverage (GATC) token selection.
    Returns selected_indices (LongTensor) and selected_image_embeds (Tensor).
    """
    N = vision_tokens_clip.shape[0]
    k = target_vision_tokens

    # ---------- boundary conditions ----------
    if k <= 0 or N == 0:
        return (torch.empty(0, dtype=torch.long, device=vision_tokens.device),
                torch.empty(0, vision_tokens.shape[1], device=vision_tokens.device))
    if k >= N:
        return (torch.arange(N, dtype=torch.long, device=vision_tokens.device),
                vision_tokens.clone())

    # ------ 1. Preprocessing: L2 normalization for cosine distance ------
    feat = vision_tokens_clip.to(torch.float32)  # ensure stable fp32
    if normalize:
        feat = F.normalize(feat, p=2, dim=1)

    # ------ 2. Distance matrix and adaptive threshold ------
    dist_mat = torch.cdist(feat, feat, p=2)  # [N, N] Euclidean distance (or cosine if normalized)

    # self-distance is zero; skip column 0 when picking neighbor
    sorted_dists, _ = torch.sort(dist_mat, dim=1)
    # ensure m does not exceed N-1 (column 0 is self), use at least 1st nearest
    m_eff = min(max(m, 1), N - 1)
    tau = sorted_dists[:, m_eff]             # [N] adaptive radii

    # ------ 3. Coverage matrix: cov[i, j] = True if x_j covers x_i ------
    cov = (dist_mat <= tau.unsqueeze(1))    # bool [N, N]

    # ------ 4. Greedy selection ------
    uncovered = torch.ones(N, dtype=torch.bool, device=feat.device)
    selected = []

    for step in range(k):
        # gain of candidate j = number of currently uncovered points covered by j
        # cov.T[j, i] is True if j covers i  => we need cov[:, j] for coverage of j
        gains = (uncovered.unsqueeze(0) & cov.T).sum(dim=1)  # [N]
        gains[selected] = -1                                  # exclude already chosen
        if gains.max() <= 0:                                  # no further coverage possible
            # fill remaining slots with arbitrary uncovered points, then break
            remaining = torch.where(uncovered)[0]
            extra = remaining[:(k - step)]
            selected.extend(extra.tolist())
            break
        best = torch.argmax(gains).item()
        selected.append(best)
        uncovered = uncovered & (~cov[:, best])

    selected_indices = torch.tensor(selected, dtype=torch.long, device=vision_tokens.device)
    selected_image_embeds = vision_tokens[selected_indices]
    return selected_indices, selected_image_embeds
```

**Boundary condition handling:**
- `target_vision_tokens=0` → empty output.
- `target_vision_tokens >= N` → return all tokens.
- If `cov` has no remaining coverage gain (`gains.max() == 0`) before reaching `k`, the loop fills the rest with arbitrary still‑uncovered tokens (or the loop continues until `k`, which is safe because no gain is possible, but we break to avoid wasted computations). The `gains[selected] = -1` prevents re‑selection.
- All tensors are created on the same device as `vision_tokens`.
- `feat` is cast to `float32` to avoid half‑precision stability issues in `torch.cdist` and `torch.sort`.

---

4. Key hyperparameter suggestions

- **`m` (neighbor rank for threshold):** A natural starting point is `m = 15`. Lower values (e.g., 5) create smaller, stricter coverage balls, leading to selections that emphasize diverse clusters; higher values (e.g., 30) enlarge balls, making the coverage easier and the selection more like a density‑based sampling. For a typical 24×24 patch grid (\(N=576\)) we recommend \(m \in [5, 25]\).
- **`normalize`:** Set `True`. L2 normalization converts Euclidean distance into cosine distance (up to a factor 2), which is more robust in high‑dimensional CLIP space and mimics the inner‑product geometry used in vision‑language models. If you prefer raw Euclidean metrics in CLIP space, set `False`, but then absolute distance magnitudes must be interpreted carefully.
- **Budget `target_vision_tokens`:** This is externally fixed (e.g., 10% of \(N\)), never tuned by the algorithm.

---

5. Numerical stability precautions

- **fp16/bf16:** The entire distance computation and sorting is performed in `float32` by casting `feat = vision_tokens_clip.to(torch.float32)`. PyTorch’s `cdist` and `sort` are stable in float32; using lower precision may yield inaccurate neighbour distances or degenerate coverage matrices. The final indices and extracted embeddings are returned in the original dtype of `vision_tokens`.
- **Division by zero / degenerate cov:** If many points are identical (all pairwise distances zero), `tau` becomes zero and `cov` becomes an identity matrix. Then each point covers only itself, leading to gains of at most 1 per step. The algorithm gracefully selects `k` arbitrary points. If `sorted_dists` has ties at the tail, `m_eff` is clamped to `N-1`, so `tau` is well defined.
- **NaN/Inf:** We assume `vision_tokens_clip` is finite. If any NaN appears, `torch.cdist` will propagate it; a pre‑filter `torch.nan_to_num` could be added, but is typically unnecessary.

---

6. Cited theoretical sources

- **Computational Geometry – Greedy Algorithm for Facility Location / Set Cover:**  
  De, Mandal, Singh, *Online Geometric Hitting Set and Set Cover Beyond Unit Balls in ℝ²* (arXiv 2304.06780). Provides the theoretical grounding for greedy online/offline hitting set algorithms with logarithmic competitive ratios in geometric spaces.
- **Set Cover – Improved Greedy Algorithm:**  
  Chandu, *Improved Greedy Algorithm for Set Covering Problem* (arXiv 1506.04220). Generalizes greedy selection to batch steps, reinforcing the coverage‑gain maximization principle.
- **Geometric Threshold / Spatial Cutoff:**  
  The idea of personalized thresholding from local neighbor distances is a direct spatial instantiation of “proximity filtering” commonly used in density‑based clustering (e.g., DBSCAN) and geometric filtering; it is here adapted as a first‑class mechanism to define balls for coverage.

---

7. Difference explanation from historical schemes

- **vs. Farthest Point Sampling (FPS):** FPS maximizes the minimum distance to already chosen points (min‑max criteria), essentially solving the \(k\)-center problem. GATC maximizes the number of points covered under a density‑adaptive radius, which is a max‑cover objective, not a min‑max one. Our selection criterion is gain in coverage count, not maximin distance.
- **vs. CosineSimilarity+TopK:** Simple similarity ranking selects the points most similar to a query (text) or to the first principal component; GATC does *not* require a query and builds a covering set purely from the geometry of the visual token cloud without a global ranking or learned projection.
- **vs. KMeans+distance ranking:** Clustering implicitly assumes spherical Gaussian clusters; GATC makes no assumption about cluster membership and works directly on pairwise distances with individual thresholds, avoiding cluster‑center artifacts.
- **vs. RandomProjection+TopK:** No random projection is used; the coverage matrix is computed in the original CLIP space, preserving the full geometric structure.

---

8. Cell Declaration

- **Cell A (domain: geometry, mechanism: greedy_selection):** Instantiates *greedy selection* by iteratively picking the point that maximizes the marginal coverage gain over the yet‑uncovered points, directly solving the geometric max‑cover problem.
- **Cell B (domain: geometry, mechanism: thresholding):** Instantiates *thresholding* by assigning each point a personalized radius derived from its \(m\)-th nearest neighbor distance, which acts as a spatial proximity filter to define which points are “covered.”

---

PRIMARY_DIRECTION: geometry