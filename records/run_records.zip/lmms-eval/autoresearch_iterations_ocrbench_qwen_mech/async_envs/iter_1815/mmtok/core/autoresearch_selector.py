# MMTok: Multimodal Coverage Maximization for Efficient Inference of VLMs
# Paper: https://arxiv.org/abs/2508.18264
# Copyright (c) 2025 Zoom Communications, Inc.
# Author: Anonymous
# Licensed under the Apache License, Version 2.0

"""
Qwen2.5-VL algorithm core: query-aware vision token selection.

This file contains the algorithmic core for vision token selection in Qwen2.5-VL.
The Coder Agent modifies the region between ALGORITHM CORE placeholders to experiment
with new selection algorithms, while the model file (qwen2_5_VLmodel_mmtok.py) handles
the fixed post-processing (compaction, padding, position_ids/attention_mask updates).
"""

import torch
import torch.nn.functional as F
from typing import List, Optional, Tuple


class QwenAlgorithmCore:
    """
    Algorithm core for Qwen2.5-VL vision token selection.

    Separates the selection algorithm from the model's forward-pass plumbing,
    enabling safe AutoResearch experiments on the algorithm without risking
    the multimodal sequence post-processing logic.
    """

    def __init__(self, mmtok_core=None):
        self.mmtok_core = mmtok_core

    def select_vision_tokens(
        self,
        image_embeds: torch.Tensor,
        image_features: torch.Tensor,
        question: str = "",
        target_vision_tokens: int = None,
        image_grid_thw: torch.Tensor = None,
        text_token_embedding: torch.Tensor = None,
    ) -> torch.Tensor:
        """
        Select vision tokens for a single sample.

        Args:
            image_embeds: [N, D] mm_projector output embeddings.
            image_features: [N, D] CLIP-space vision features.
            question: Question text string.
            target_vision_tokens: Target number of tokens to retain.
            image_grid_thw: [3] or [num_images, 3] grid shape (optional).

        Returns:
            selected_indices: [K] torch.long, indices of selected vision tokens.
        """
        if target_vision_tokens is None:
            target_vision_tokens = getattr(
                self.mmtok_core, "target_vision_tokens", 64
            )

        # --- ALGORITHM CORE START ---
        N = image_embeds.shape[0]
        device = image_embeds.device
        eps = 1e-8
        lambda_reg = 0.5

        # Work in full float32 for numerical stability
        vis_tokens = image_embeds.to(torch.float32)
        if text_token_embedding is not None:
            txt_tokens = text_token_embedding.to(torch.float32)
        else:
            # Fallback: zero text embedding to avoid crash
            txt_tokens = torch.zeros(1, vis_tokens.shape[1], device=device, dtype=torch.float32)

        # 1. Normalised query vector (mean of text tokens)
        q = txt_tokens.mean(dim=0)                         # [D]
        q = F.normalize(q, dim=0, eps=eps)                 # [D]

        # 2. Normalise visual tokens
        vis_norm = F.normalize(vis_tokens, dim=1, eps=eps)  # [N, D]

        # 3. Target scores (cosine similarity) -> rank-1 label kernel
        s = torch.matmul(vis_norm, q.to(vis_norm.dtype))  # [N]

        # 4. Kernel matrix: centred RBF on normalised vision tokens
        sq_dists = torch.cdist(vis_norm, vis_norm, p=2) ** 2   # [N, N]
        # gamma: 1/(2 * median squared distance)
        median_sq_dist = torch.median(sq_dists) + eps
        gamma = 1.0 / (2.0 * median_sq_dist)
        K = torch.exp(-gamma * sq_dists)                      # [N, N]

        # Centre the kernel matrix: H = I - 1/N
        one_N = torch.ones(N, 1, device=device, dtype=torch.float32) / N
        mean_rows = one_N @ (one_N.t() @ K)                   # [N, N]
        mean_cols = (K @ one_N) @ one_N.t()                   # [N, N]
        overall_mean = (one_N.t() @ K @ one_N).squeeze()       # scalar
        K_c = K - mean_rows - mean_cols + overall_mean * (one_N @ one_N.t())

        # 5. Greedy selection with HSIC objective
        selected = []
        remaining = set(range(N))
        all_indices = torch.arange(N, device=device)          # used later for complement

        for step in range(target_vision_tokens):
            best_i = -1
            best_val = torch.tensor(-float('inf'), device=device)
            # Evaluate all remaining candidates
            for i in list(remaining):
                cur_set = selected + [i]                      # indices as Python list of ints
                m = len(cur_set)                              # = step + 1
                # Sub‑kernel for the candidate set
                K_sub = K_c[cur_set][:, cur_set]              # [m, m]
                # Label kernel (rank‑1 outer product)
                s_sub = s[cur_set]                            # [m]
                L_sub = torch.outer(s_sub, s_sub)             # [m, m]
                hsic_q = torch.sum(K_sub * L_sub) / (m * m)

                # Complement indices (all tokens NOT in cur_set)
                cur_tensor = torch.tensor(cur_set, device=device)
                is_compl = ~torch.isin(all_indices, cur_tensor)  # boolean mask
                complement = all_indices[is_compl]            # [N-m]
                K_sub_comp = K_c[cur_set][:, complement]      # [m, N-m]
                # HSIC between selected and complement: trace(K_sub_comp @ K_sub_comp.T) / (m*(N-m))
                M = K_sub_comp @ K_sub_comp.T                  # [m, m]
                hsic_red = torch.trace(M) / (m * (N - m))

                val = hsic_q - lambda_reg * hsic_red
                if val > best_val:
                    best_val = val
                    best_i = i

            # Add best candidate
            selected.append(best_i)
            remaining.remove(best_i)

        selected_indices = torch.tensor(selected, dtype=torch.long, device=device)
        # Output must be sorted in ascending order
        selected_indices, _ = torch.sort(selected_indices)
        # --- ALGORITHM CORE END ---

        return selected_indices

    def select_vision_tokens_batch(
        self,
        image_embeds_list,
        image_features_list,
        questions,
        target_vision_tokens_list,
        image_grid_thw_list=None,
    ):
        """
        Select vision tokens for a batch of samples.

        Args:
            image_embeds_list: List of [N_i, D] tensors.
            image_features_list: List of [N_i, D] tensors.
            questions: List of question strings.
            target_vision_tokens_list: List of target token counts.
            image_grid_thw_list: Optional list of grid shapes.

        Returns:
            selected_indices_list: List of [K_i] tensors.
        """
        selected_indices_list = []
        n = len(image_embeds_list)
        for i in range(n):
            emb = image_embeds_list[i]
            feat = image_features_list[i]
            q = questions[i] if i < len(questions) else questions[-1]
            tgt = (
                target_vision_tokens_list[i]
                if i < len(target_vision_tokens_list)
                else target_vision_tokens_list[-1]
            )
            grid = None
            if image_grid_thw_list is not None and i < len(image_grid_thw_list):
                grid = image_grid_thw_list[i]

            selected_indices = self.select_vision_tokens(
                emb, feat, q, target_vision_tokens=tgt, image_grid_thw=grid
            )
            selected_indices_list.append(selected_indices)

        return selected_indices_list


# ---------------------------------------------------------------------------
# AutoResearchSelector wrapper
# ---------------------------------------------------------------------------
# mmtok/qwen/mmtok_core.py imports AutoResearchSelector from this module and
# expects it to expose the same interface as the selectors in mmtok/qwen/
# (i.e. __init__(target_vision_tokens, alpha) and mm_coverage_selection(...)).
# The QwenAlgorithmCore class above is the actual target that the Coder Agent
# patches; this thin wrapper adapts it to the interface expected by MMTokCore.
# ---------------------------------------------------------------------------


class AutoResearchSelector:
    """
    Adapter that exposes the MMTok selector interface on top of
    QwenAlgorithmCore (the file that the AutoResearch Coder Agent modifies).
    """

    def __init__(self, target_vision_tokens: int = 32, alpha: float = 0.5):
        self.target_vision_tokens = target_vision_tokens
        self.alpha = alpha
        # QwenAlgorithmCore only needs mmtok_core for a default
        # target_vision_tokens fallback; passing None is safe because we always
        # supply target_vision_tokens explicitly in the call below.
        self._core = QwenAlgorithmCore(mmtok_core=None)

    def mm_coverage_selection(
        self,
        text_token_embedding: torch.Tensor,
        vision_tokens: torch.Tensor,
        vision_tokens_clip: torch.Tensor,
        tv_temp: float = 0.01,
        vv_temp: float = 0.2,
        padding_patch_indices: Optional[List[int]] = None,
    ) -> Tuple[List[int], torch.Tensor]:
        """
        Run the algorithm core and return results in the format expected by
        MMTokCore.select_vision_tokens.

        Args / Returns follow the contract of the other selectors in
        mmtok/qwen/ (e.g. semantic_selector.py).
        """
        # QwenAlgorithmCore.select_vision_tokens returns a [K] torch.long tensor.
        selected_indices_tensor = self._core.select_vision_tokens(
            image_embeds=vision_tokens,
            image_features=vision_tokens_clip,
            question="",
            target_vision_tokens=self.target_vision_tokens,
            text_token_embedding=text_token_embedding,
        )

        # Convert to Python list to match the selector contract.
        selected_indices = selected_indices_tensor.tolist()
        # Guard against scalar tensor (when only one index is selected).
        if not isinstance(selected_indices, list):
            selected_indices = torch.tensor([selected_indices], dtype=torch.long, device=image_embeds.device)
        selected_tokens = vision_tokens[selected_indices_tensor]
        return selected_indices, selected_tokens