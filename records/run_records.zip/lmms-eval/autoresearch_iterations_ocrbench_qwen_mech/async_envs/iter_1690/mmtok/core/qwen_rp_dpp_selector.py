# MMTok: Multimodal Coverage Maximization for Efficient Inference of VLMs
# Paper: https://arxiv.org/abs/2508.18264
# Copyright (c) 2025 Zoom Communications, Inc.
# Author: Anonymous
# Licensed under the Apache License, Version 2.0

"""
QwenRPDPPSelector: random-projection DPP vision token selection for Qwen2.5-VL.

Projects vision features into a lower-dimensional space and performs greedy
DPP marginal maximisation, updating the L-ensemble inverse via the
Sherman-Morrison formula.
"""

from typing import List, Optional, Tuple

import torch


class QwenRPDPPAlgorithmCore:
    """
    Algorithm core for Qwen2.5-VL vision token selection.

    Separates the selection algorithm from the model's forward-pass plumbing,
    enabling safe AutoResearch experiments on the algorithm without risking
    the multimodal sequence post-processing logic.
    """

    def __init__(self, mmtok_core=None):
        self.mmtok_core = mmtok_core

    def select_vision_tokens(
        self,
        image_embeds: torch.Tensor,
        image_features: torch.Tensor,
        question: str = "",
        target_vision_tokens: int = None,
        image_grid_thw: torch.Tensor = None,
        text_token_embedding: torch.Tensor = None,
    ) -> torch.Tensor:
        # --- ALGORITHM CORE START ---
        N = image_features.shape[0]
        proj_dim = 64

        # Cast to float32 for numerical stability in matrix inversions
        feat = image_features.to(torch.float32)
        device = feat.device

        # Random projection with a fixed seed for deterministic behaviour
        rng = torch.Generator(device=device)
        rng.manual_seed(42)
        proj_mat = torch.randn(feat.shape[1], proj_dim, generator=rng, device=device, dtype=torch.float32)
        proj_mat = proj_mat / (proj_dim ** 0.5)          # preserve pairwise distances in expectation
        V_proj = feat @ proj_mat                         # (N, proj_dim)

        M_inv = torch.eye(proj_dim, device=device, dtype=torch.float32)  # inverse of current L-ensemble
        selected = []
        mask = torch.ones(N, dtype=torch.bool, device=device)

        for _ in range(target_vision_tokens):
            V_M = V_proj @ M_inv                          # (N, proj_dim)
            scores = (V_M * V_proj).sum(dim=1)            # (N,)  = v_j^T M_inv v_j
            scores[~mask] = -float('inf')
            idx = torch.argmax(scores)
            selected.append(idx.item())
            mask[idx] = False

            v = V_proj[idx]                               # (proj_dim,)
            M_inv_v = M_inv @ v                           # (proj_dim,)
            denom = 1.0 + torch.dot(v, M_inv_v)
            # Sherman-Morrison update: M_inv <- M_inv - (M_inv_v * M_inv_v^T) / denom
            M_inv -= torch.outer(M_inv_v, M_inv_v) / denom

        selected_indices = torch.tensor(selected, dtype=torch.long, device=device)
        # --- ALGORITHM CORE END ---
        return selected_indices

    def select_vision_tokens_batch(
        self,
        image_embeds_list,
        image_features_list,
        questions,
        target_vision_tokens_list,
        image_grid_thw_list=None,
    ):
        selected_indices_list = []
        n = len(image_embeds_list)
        for i in range(n):
            emb = image_embeds_list[i]
            feat = image_features_list[i]
            q = questions[i] if i < len(questions) else questions[-1]
            tgt = (
                target_vision_tokens_list[i]
                if i < len(target_vision_tokens_list)
                else target_vision_tokens_list[-1]
            )
            grid = None
            if image_grid_thw_list is not None and i < len(image_grid_thw_list):
                grid = image_grid_thw_list[i]

            selected_indices = self.select_vision_tokens(
                emb, feat, q, target_vision_tokens=tgt, image_grid_thw=grid
            )
            selected_indices_list.append(selected_indices)

        return selected_indices_list


class QwenRPDPPSelector:
    def __init__(self, target_vision_tokens: int = 32, alpha: float = 0.5):
        self.target_vision_tokens = target_vision_tokens
        self.alpha = alpha
        self._core = QwenRPDPPAlgorithmCore(mmtok_core=None)

    def mm_coverage_selection(
        self,
        text_token_embedding: torch.Tensor,
        vision_tokens: torch.Tensor,
        vision_tokens_clip: torch.Tensor,
        tv_temp: float = 0.01,
        vv_temp: float = 0.2,
        padding_patch_indices: Optional[List[int]] = None,
    ) -> Tuple[List[int], torch.Tensor]:
        selected_indices_tensor = self._core.select_vision_tokens(
            image_embeds=vision_tokens,
            image_features=vision_tokens_clip,
            question="",
            target_vision_tokens=self.target_vision_tokens,
            text_token_embedding=text_token_embedding,
        )
        selected_indices = selected_indices_tensor.tolist()
        if not isinstance(selected_indices, list):
            selected_indices = torch.tensor([selected_indices_tensor.item()], dtype=torch.long, device=vision_tokens.device)
        selected_tokens = vision_tokens[selected_indices_tensor]
        return selected_indices, selected_tokens
