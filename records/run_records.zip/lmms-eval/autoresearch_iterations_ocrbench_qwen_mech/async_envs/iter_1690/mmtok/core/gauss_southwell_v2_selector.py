# MMTok: Improved Gauss-Southwell vision token selector
# (adaptive lambda + FPS-based initialization)

from typing import Optional, List, Tuple

import torch
import torch.nn.functional as F


class GaussSouthwellV2Selector:
    """
    Improved Gauss-Southwell greedy vision token selector.

    Improvements:
    1. Adaptive lambda: computed from the spectral norm of normalized vision tokens.
       lambda = 1.0 - 1.0 / (max_eigenvalue + eps), clamped to [0, 1].
    2. FPS-based initialization: the first token is the one farthest from the
       centroid of all vision tokens (better spatial coverage).

    Computes a question embedding q from text tokens, then greedily selects
    vision tokens balancing relevance to the question and diversity within
    the selected set (Gauss-Southwell criterion).
    """

    def __init__(self, target_vision_tokens: int = 64):
        self.target_vision_tokens = target_vision_tokens

    def mm_coverage_selection(
        self,
        text_token_embedding: torch.Tensor,
        vision_tokens: torch.Tensor,
        vision_tokens_clip: torch.Tensor,
        tv_temp: float = 0.01,
        vv_temp: float = 0.2,
        padding_patch_indices: Optional[List[int]] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Improved Gauss-Southwell-based vision token selection.

        Args:
            text_token_embedding: [T, D] text token embeddings (question/keywords).
            vision_tokens: [N, D] mm_projector output tokens.
            vision_tokens_clip: Unused (interface compatibility).
            tv_temp: Unused (interface compatibility).
            vv_temp: Unused (interface compatibility).
            padding_patch_indices: Optional list of indices to exclude from selection.

        Returns:
            selected_indices: [K] sorted LongTensor of selected token indices.
            selected_tokens: [K, D] selected vision tokens.
        """
        device = vision_tokens.device
        N = vision_tokens.size(0)
        k = min(self.target_vision_tokens, N)

        if k <= 0:
            selected_indices = torch.empty(0, dtype=torch.long, device=device)
            selected_tokens = torch.empty(0, vision_tokens.size(1), device=device, dtype=vision_tokens.dtype)
            return selected_indices, selected_tokens
        elif k >= N or N == 0:
            selected_indices = torch.arange(N, device=device)
            return selected_indices, vision_tokens

        # 1. Compute question embedding q from text tokens
        if text_token_embedding is not None and text_token_embedding.numel() > 0:
            q_raw = text_token_embedding.mean(dim=0)  # [D]
            q = F.normalize(q_raw, p=2, dim=0)  # [D]
        else:
            q = torch.ones(vision_tokens.size(1), device=device, dtype=vision_tokens.dtype)
            q = F.normalize(q, p=2, dim=0)

        # 2. Normalize image embeddings and compute relevance scores
        X_norm = F.normalize(vision_tokens, p=2, dim=1)  # [N, D]
        r = torch.matmul(X_norm, q)  # [N]

        # Handle padding exclusion
        excluded_mask = torch.zeros(N, dtype=torch.bool, device=device)
        if padding_patch_indices is not None and len(padding_patch_indices) > 0:
            excluded_mask[padding_patch_indices] = True

        # --- ADAPTIVE LAMBDA ---
        X_norm_f32 = X_norm.to(torch.float32)
        spectral_norm = torch.linalg.matrix_norm(X_norm_f32, ord=2)
        max_eigenvalue = spectral_norm ** 2
        lambda_ = 1.0 - 1.0 / (max_eigenvalue + 1e-8)
        lambda_ = torch.clamp(lambda_, 0.0, 1.0).item()
        # --- END ADAPTIVE LAMBDA ---

        # 3. FPS-based initialisation: pick the token farthest from the centroid
        centroid = X_norm.mean(dim=0)  # [D]
        dist_to_centroid = torch.norm(X_norm - centroid, dim=1)  # [N]
        dist_to_centroid[excluded_mask] = -float("inf")

        if dist_to_centroid.max().item() == -float("inf"):
            first_idx = 0
        else:
            first_idx = torch.argmax(dist_to_centroid)

        selected_mask = torch.zeros(N, dtype=torch.bool, device=device)
        D = vision_tokens.size(1)
        M = torch.zeros(D, device=device, dtype=vision_tokens.dtype)

        selected_mask[first_idx] = True
        selected_indices_list = [first_idx.item()]
        M = M + X_norm[first_idx]

        # 4. Greedy Gauss-Southwell loop
        for step in range(1, k):
            M_mean = M / step
            scores = r - lambda_ * torch.matmul(X_norm, M_mean)
            scores[selected_mask] = -float("inf")
            scores[excluded_mask] = -float("inf")
            j = torch.argmax(scores)
            selected_mask[j] = True
            selected_indices_list.append(j.item())
            M = M + X_norm[j]

        selected_indices = torch.tensor(selected_indices_list, dtype=torch.long, device=device)
        selected_indices = torch.sort(selected_indices).values
        selected_tokens = vision_tokens[selected_indices]
        return selected_indices, selected_tokens
