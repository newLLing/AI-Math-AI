# MMTok: Multimodal Coverage Maximization for Efficient Inference of VLMs
# Paper: https://arxiv.org/abs/2508.18264
# Copyright (c) 2025 Zoom Communications, Inc.
# Author: Anonymous
# Licensed under the Apache License, Version 2.0

"""
QwenCustomSelector: query-aware vision token selection via relevance-weighted
spatial-augmented greedy volume maximisation (pivoted QR).

Compatible with both the QwenAlgorithmCore interface (select_vision_tokens)
and the MMTok selector registry (mm_coverage_selection).
"""

import math
from typing import List, Optional, Tuple

import torch
import torch.nn.functional as F


class QwenCustomSelector:
    """
    Algorithm core for Qwen2.5-VL vision token selection.

    Separates the selection algorithm from the model's forward-pass plumbing,
    enabling safe AutoResearch experiments on the algorithm without risking
    the multimodal sequence post-processing logic.
    """

    def __init__(self, mmtok_core=None, target_vision_tokens: int = 64):
        self.mmtok_core = mmtok_core
        self.target_vision_tokens = target_vision_tokens

    def select_vision_tokens(
        self,
        image_embeds: torch.Tensor,
        image_features: torch.Tensor,
        question: str = "",
        target_vision_tokens: int = None,
        image_grid_thw: torch.Tensor = None,
        text_token_embedding: torch.Tensor = None,
    ) -> torch.Tensor:
        """
        Select vision tokens for a single sample.

        Args:
            image_embeds: [N, D] mm_projector output embeddings.
            image_features: [N, D] CLIP-space vision features.
            question: Question text string.
            target_vision_tokens: DEPRECATED – ignored; use token_retain_ratio.
            image_grid_thw: [3] or [num_images, 3] grid shape (optional).

        Returns:
            selected_indices: [K] torch.long, indices of selected vision tokens.
        """
        # --- ALGORITHM CORE START ---
        N = image_embeds.shape[0]
        device = image_embeds.device

        # --- Convert all inputs to float32 for numerical stability ---
        image_embeds = image_embeds.float()
        image_features = image_features.float()
        text_token_embedding = text_token_embedding.float()

        # Use token_retain_ratio directly; do NOT rely on deprecated target_vision_tokens
        token_retain_ratio = (
            getattr(self.mmtok_core, "token_retain_ratio", None)
            or getattr(self.mmtok_core, "retain_ratio", None)
            or 0.1
            if self.mmtok_core is not None
            else 0.1
        )
        K = max(1, int(token_retain_ratio * N))

        # Boundary cases
        if K <= 0:
            selected_indices = torch.empty(0, dtype=torch.long, device=device)
            return selected_indices
        if K >= N:
            selected_indices = torch.arange(N, dtype=torch.long, device=device)
            return selected_indices

        # 1. Text query aggregation
        q = text_token_embedding.mean(dim=0)  # [D]

        # 2. Relevance weights from LLM-aligned space (image_embeds)
        v_norm = F.normalize(image_embeds, dim=1)
        q_norm = F.normalize(q.unsqueeze(0), dim=1).squeeze(0)  # [D]
        cos_sim = torch.matmul(v_norm, q_norm)  # [N]
        tau = 0.1
        w = torch.softmax(cos_sim / tau, dim=0)  # [N]

        # 3. Spatial coordinates (robust factorization)
        H = int(math.sqrt(N))
        while N % H != 0:
            H -= 1
        W = N // H

        y = torch.arange(H, device=device, dtype=torch.float32) / max(H - 1, 1)
        x = torch.arange(W, device=device, dtype=torch.float32) / max(W - 1, 1)
        grid_y, grid_x = torch.meshgrid(y, x, indexing="ij")
        pos = torch.stack([grid_x.reshape(-1), grid_y.reshape(-1)], dim=1)  # [N, 2]

        # 4. Augmented feature matrix (CLIP + spatial)
        c_norm = F.normalize(image_features, dim=1)  # [N, d_clip]
        lmbda = 0.5
        f = torch.cat([c_norm, lmbda * pos], dim=1)  # [N, d_clip+2]

        # 5. Weighted feature matrix
        sqrt_w = torch.sqrt(w + 1e-8).unsqueeze(1)  # [N, 1]
        f_weighted = f * sqrt_w  # [N, d_aug]

        # 6. Greedy volume maximisation (pivoted QR)
        K = min(K, N)
        selected = []
        residual = f_weighted.clone()
        for _ in range(K):
            norms = torch.norm(residual, dim=1)  # [N]
            # Mask out already selected indices
            mask = torch.ones(N, dtype=torch.bool, device=device)
            if selected:
                mask[selected] = False
            norms[~mask] = -torch.inf
            idx = torch.argmax(norms).item()
            selected.append(idx)

            # Orthogonalise remaining rows against chosen vector
            u = residual[idx].clone()
            u_norm = torch.norm(u)
            if u_norm > 1e-10:
                u = u / u_norm
                proj = torch.matmul(residual, u)  # [N]
                residual = residual - torch.outer(proj, u)  # [N, d_aug]

        selected_indices = torch.tensor(selected, dtype=torch.long, device=device)
        # --- ALGORITHM CORE END ---

        return selected_indices

    def select_vision_tokens_batch(
        self,
        image_embeds_list,
        image_features_list,
        questions,
        target_vision_tokens_list,
        image_grid_thw_list=None,
    ):
        """
        Select vision tokens for a batch of samples.

        Args:
            image_embeds_list: List of [N_i, D] tensors.
            image_features_list: List of [N_i, D] tensors.
            questions: List of question strings.
            target_vision_tokens_list: List of target token counts.
            image_grid_thw_list: Optional list of grid shapes.

        Returns:
            selected_indices_list: List of [K_i] tensors.
        """
        selected_indices_list = []
        n = len(image_embeds_list)
        for i in range(n):
            emb = image_embeds_list[i]
            feat = image_features_list[i]
            q = questions[i] if i < len(questions) else questions[-1]
            tgt = (
                target_vision_tokens_list[i]
                if i < len(target_vision_tokens_list)
                else target_vision_tokens_list[-1]
            )
            grid = None
            if image_grid_thw_list is not None and i < len(image_grid_thw_list):
                grid = image_grid_thw_list[i]

            selected_indices = self.select_vision_tokens(
                emb, feat, q, target_vision_tokens=tgt, image_grid_thw=grid
            )
            selected_indices_list.append(selected_indices)

        return selected_indices_list

    def mm_coverage_selection(
        self,
        text_token_embedding: torch.Tensor,
        vision_tokens: torch.Tensor,
        vision_tokens_clip: torch.Tensor,
        tv_temp: float = 0.01,
        vv_temp: float = 0.2,
        padding_patch_indices: Optional[List[int]] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        MMTok selector registry interface.

        Args:
            text_token_embedding: [T, D] text token embeddings.
            vision_tokens: [N, D] mm_projector output embeddings.
            vision_tokens_clip: [N, D] CLIP-space vision features.
            tv_temp: Ignored (present for API compatibility).
            vv_temp: Ignored (present for API compatibility).
            padding_patch_indices: Optional list of indices to exclude.

        Returns:
            (selected_indices, selected_vision_tokens)
        """
        selected_indices = self.select_vision_tokens(
            image_embeds=vision_tokens,
            image_features=vision_tokens_clip,
            text_token_embedding=text_token_embedding,
            target_vision_tokens=self.target_vision_tokens,
        )

        if padding_patch_indices is not None and len(padding_patch_indices) > 0:
            # Filter out padding indices and keep up to target count
            mask = torch.ones(
                vision_tokens.shape[0], dtype=torch.bool, device=vision_tokens.device
            )
            mask[padding_patch_indices] = False
            valid_mask = mask[selected_indices]
            selected_indices = selected_indices[valid_mask]
            if self.target_vision_tokens is not None:
                max_k = min(self.target_vision_tokens, len(selected_indices))
                selected_indices = selected_indices[:max_k]

        selected_tokens = vision_tokens[selected_indices]
        return selected_indices, selected_tokens
