
import torch
import torch.nn.functional as F
from typing import List, Optional, Tuple
import math

from loguru import logger as eval_logger
eval_logger.info("[MMTok] autoresearch_v28_c0_selector.py loaded")


class QwenAlgorithmCoreV15:
    """
    Algorithm core for Qwen2.5-VL vision token selection (v28).

    Separates the selection algorithm from the model's forward-pass plumbing,
    enabling safe AutoResearch experiments on the algorithm without risking
    the multimodal sequence post-processing logic.
    """

    def __init__(self, mmtok_core=None):
        self.mmtok_core = mmtok_core

    def select_vision_tokens(
        self,
        image_embeds: torch.Tensor,
        image_features: torch.Tensor,
        question: str = "",
        target_vision_tokens: int = None,
        image_grid_thw: torch.Tensor = None,
        text_token_embedding: torch.Tensor = None,
    ) -> torch.Tensor:
        # --- ALGORITHM CORE START ---
        N = image_features.size(0)
        K = target_vision_tokens
        device = image_features.device
        beta = 0.5              # spatial weight (trade‑off parameter)
        eps = 1e-8          # division guard

        # Boundary cases
        if K <= 0 or N == 0:
            selected_indices = torch.empty(0, dtype=torch.long, device=device)
        elif K >= N:
            selected_indices = torch.arange(N, dtype=torch.long, device=device)
        else:
            # Reconstruct spatial grid dimensions (H, W) from image_grid_thw or fallback
            if image_grid_thw is not None and image_grid_thw.numel() > 0:
                if image_grid_thw.dim() == 2:
                    h = image_grid_thw[0, 1].item()
                    w = image_grid_thw[0, 2].item()
                else:
                    h = image_grid_thw[1].item()
                    w = image_grid_thw[2].item()
                H, W = int(h), int(w)
                if H * W != N:
                    # Fallback to linear ordering if provided grid size doesn't match
                    H = N
                    W = 1
            else:
                H = W = int(N ** 0.5)
                if H * W != N:
                    H = N
                    W = 1

            # Normalised coordinates in [-1, 1]
            y_coords = (torch.arange(H, dtype=torch.float32, device=device) - (H - 1) / 2) / ((H - 1) / 2 + eps)
            x_coords = (torch.arange(W, dtype=torch.float32, device=device) - (W - 1) / 2) / ((W - 1) / 2 + eps)
            grid_y, grid_x = torch.meshgrid(y_coords, x_coords, indexing='ij')
            pos = torch.stack([grid_x.flatten(), grid_y.flatten()], dim=1)  # (N, 2)

            # Build augmented feature matrix (float32 for numerical stability)
            X = image_features.to(torch.float32)
            Z = torch.cat([X, beta * pos], dim=1)  # (N, d_feat + 2)
            # Greedy determinant‑maximization via incremental orthogonalization
            R = Z.clone()
            selected = torch.empty(K, dtype=torch.long, device=device)
            available = torch.ones(N, dtype=torch.bool, device=device)

            for step in range(K):
                norm2 = (R ** 2).sum(dim=1)                     # (N,)
                norm2[~available] = -float('inf')               # exclude already selected
                i = torch.argmax(norm2)                         # keep as tensor; avoid GPU→CPU sync
                available[i] = False
                selected[step] = i

                q = R[i] / (norm2[i].sqrt() + eps)              # new orthonormal basis vector
                dot = R @ q                                      # (N,)
                R = R - dot[:, None] * q[None, :]                # project out q from all residuals

            selected_indices = selected.sort()[0]
        # --- ALGORITHM CORE END ---
        return selected_indices


    def select_vision_tokens_batch(
        self,
        image_embeds_list,
        image_features_list,
        questions,
        target_vision_tokens_list,
        image_grid_thw_list=None,
    ):
        selected_indices_list = []
        n = len(image_embeds_list)
        for i in range(n):
            emb = image_embeds_list[i]
            feat = image_features_list[i]
            q = questions[i] if i < len(questions) else questions[-1]
            tgt = (
                target_vision_tokens_list[i]
                if i < len(target_vision_tokens_list)
                else target_vision_tokens_list[-1]
            )
            grid = None
            if image_grid_thw_list is not None and i < len(image_grid_thw_list):
                grid = image_grid_thw_list[i]

            selected_indices = self.select_vision_tokens(
                emb, feat, q, target_vision_tokens=tgt, image_grid_thw=grid
            )
            selected_indices_list.append(selected_indices)

        return selected_indices_list


class AutoResearchSelectorV280:
    def __init__(self, target_vision_tokens: int = 32, alpha: float = 0.5):
        self.target_vision_tokens = target_vision_tokens
        self.alpha = alpha
        self._core = QwenAlgorithmCoreV15(mmtok_core=None)

    def mm_coverage_selection(
        self,
        text_token_embedding: torch.Tensor,
        vision_tokens: torch.Tensor,
        vision_tokens_clip: torch.Tensor,
        tv_temp: float = 0.01,
        vv_temp: float = 0.2,
        padding_patch_indices: Optional[List[int]] = None,
        image_grid_thw: torch.Tensor = None,
    ) -> Tuple[List[int], torch.Tensor]:
        selected_indices_tensor = self._core.select_vision_tokens(
            image_embeds=vision_tokens,
            image_features=vision_tokens_clip,
            question="",
            target_vision_tokens=self.target_vision_tokens,
            text_token_embedding=text_token_embedding,
            image_grid_thw=image_grid_thw,
        )
        selected_indices = selected_indices_tensor.tolist()
        if not isinstance(selected_indices, list):
            selected_indices = [selected_indices]
        selected_tokens = vision_tokens[selected_indices_tensor]
        return selected_indices, selected_tokens




