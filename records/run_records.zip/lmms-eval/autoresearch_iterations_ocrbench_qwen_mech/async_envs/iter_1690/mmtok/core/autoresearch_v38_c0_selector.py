# MMTok: Multimodal Coverage Maximization for Efficient Inference of VLMs
# Paper: https://arxiv.org/abs/2508.18264
# Copyright (c) 2025 Zoom Communications, Inc.
# Author: Anonymous
# Licensed under the Apache License, Version 2.0

import torch
from typing import List, Optional, Tuple

from loguru import logger as eval_logger

eval_logger.info("[MMTok] autoresearch_v38_c0_selector.py loaded")


class QwenAlgorithmCoreV38:
    """
    Algorithm core for Qwen2.5-VL vision token selection (v38).

    Accelerated version of v34: greedy determinant maximization through
    incremental orthogonalization on the original visual features.

    Optimizations over the baseline v34 implementation:
      1. Incrementally updating residual squared norms.
      2. Updating the residual matrix in place.
      3. Preallocating temporary buffers.
      4. Disabling autograd during inference.
      5. Avoiding unnecessary GPU-to-CPU synchronization.
    """

    def __init__(self, mmtok_core=None):
        self.mmtok_core = mmtok_core

    @torch.inference_mode()
    def select_vision_tokens(
        self,
        image_embeds: torch.Tensor,
        image_features: torch.Tensor,
        question: str = "",
        target_vision_tokens: int = None,
        image_grid_thw: torch.Tensor = None,
        text_token_embedding: torch.Tensor = None,
    ) -> torch.Tensor:
        # --- ALGORITHM CORE START ---
        N = image_features.size(0)
        K = target_vision_tokens
        device = image_features.device
        eps = 1e-8

        # Boundary cases
        if K <= 0 or N == 0:
            return torch.empty(
                0,
                dtype=torch.long,
                device=device,
            )

        if K >= N:
            return torch.arange(
                N,
                dtype=torch.long,
                device=device,
            )

        # The original implementation converts the selection features to
        # float32. Since the optimized implementation updates R in place,
        # an independent contiguous tensor must be created.
        if image_features.dtype == torch.float32:
            R = image_features.detach().clone(
                memory_format=torch.contiguous_format
            )
        else:
            R = image_features.detach().to(
                dtype=torch.float32
            ).contiguous()

        _, feature_dim = R.shape

        selected = torch.empty(
            K,
            dtype=torch.long,
            device=device,
        )

        # Compute the initial residual squared norms only once.
        # vector_norm avoids explicitly constructing an N x d temporary
        # tensor such as R ** 2.
        residual_norm2 = torch.linalg.vector_norm(
            R,
            ord=2,
            dim=1,
        )
        residual_norm2.square_()

        # Reusable temporary buffers avoid allocating q and dot at every step.
        q = torch.empty(
            feature_dim,
            dtype=R.dtype,
            device=device,
        )
        dot = torch.empty(
            N,
            dtype=R.dtype,
            device=device,
        )

        for step in range(K):
            # Select the token with the largest residual squared norm.
            # torch.argmax returns a device tensor, so this operation does
            # not introduce a GPU-to-CPU synchronization.
            i = torch.argmax(residual_norm2)
            selected[step] = i

            # Numerical protection only. In exact arithmetic, every
            # unselected residual squared norm is nonnegative.
            pivot_norm2 = residual_norm2[i].clamp_min(0.0)
            denominator = pivot_norm2.sqrt().add_(eps)

            # q = R[i] / (sqrt(||R[i]||^2) + eps)
            # The output buffer is reused at every iteration.
            torch.div(
                R[i],
                denominator,
                out=q,
            )

            # dot_j = <R[j], q>
            torch.mv(
                R,
                q,
                out=dot,
            )

            # Incremental orthogonalization:
            # R_j <- R_j - <R_j, q> q
            # addcmul_ performs the update in place and avoids allocating
            # an additional N x d residual matrix.
            R.addcmul_(
                dot.unsqueeze(1),
                q.unsqueeze(0),
                value=-1.0,
            )

            # Update residual squared norms using
            # ||R_j - <R_j,q>q||^2 = ||R_j||^2 - <R_j,q>^2,
            # because q is normalized.
            # This is mathematically equivalent to recomputing
            # (R ** 2).sum(dim=1), but only requires O(N) computation.
            residual_norm2.addcmul_(
                dot,
                dot,
                value=-1.0,
            )

            # Exclude the selected token from subsequent iterations.
            residual_norm2[i] = -torch.inf

        # Restore the original spatial/token order.
        selected_indices = selected.sort().values
        # --- ALGORITHM CORE END ---

        return selected_indices

    @torch.inference_mode()
    def select_vision_tokens_batch(
        self,
        image_embeds_list,
        image_features_list,
        questions,
        target_vision_tokens_list,
        image_grid_thw_list=None,
    ):
        selected_indices_list = []

        num_samples = len(image_embeds_list)
        num_questions = len(questions)
        num_targets = len(target_vision_tokens_list)
        num_grids = (
            len(image_grid_thw_list)
            if image_grid_thw_list is not None
            else 0
        )

        default_question = questions[-1] if num_questions > 0 else ""
        default_target = target_vision_tokens_list[-1]

        for i in range(num_samples):
            emb = image_embeds_list[i]
            feat = image_features_list[i]

            question = (
                questions[i]
                if i < num_questions
                else default_question
            )

            target = (
                target_vision_tokens_list[i]
                if i < num_targets
                else default_target
            )

            grid = (
                image_grid_thw_list[i]
                if image_grid_thw_list is not None and i < num_grids
                else None
            )

            selected_indices = self.select_vision_tokens(
                image_embeds=emb,
                image_features=feat,
                question=question,
                target_vision_tokens=target,
                image_grid_thw=grid,
            )

            selected_indices_list.append(selected_indices)

        return selected_indices_list


class AutoResearchSelectorV380:
    def __init__(
        self,
        target_vision_tokens: int = 32,
        alpha: float = 0.5,
        theta: float = 0.0,
    ):
        self.target_vision_tokens = target_vision_tokens
        self.alpha = alpha
        self.theta = theta
        self._core = QwenAlgorithmCoreV38(mmtok_core=None)

    @torch.inference_mode()
    def mm_coverage_selection(
        self,
        text_token_embedding: torch.Tensor,
        vision_tokens: torch.Tensor,
        vision_tokens_clip: torch.Tensor,
        tv_temp: float = 0.01,
        vv_temp: float = 0.2,
        padding_patch_indices: Optional[List[int]] = None,
        image_grid_thw: torch.Tensor = None,
    ) -> Tuple[List[int], torch.Tensor]:
        selected_indices_tensor = self._core.select_vision_tokens(
            image_embeds=vision_tokens,
            image_features=vision_tokens_clip,
            question="",
            target_vision_tokens=self.target_vision_tokens,
            text_token_embedding=text_token_embedding,
            image_grid_thw=image_grid_thw,
        )

        # Launch the GPU gather before .tolist(). Since .tolist() forces a
        # GPU-to-CPU synchronization, placing index_select first allows the
        # token gather to complete during the same synchronization.
        selected_tokens = torch.index_select(
            vision_tokens,
            dim=0,
            index=selected_indices_tensor,
        )

        selected_indices = selected_indices_tensor.tolist()

        if not isinstance(selected_indices, list):
            selected_indices = [selected_indices]

        return selected_indices, selected_tokens
