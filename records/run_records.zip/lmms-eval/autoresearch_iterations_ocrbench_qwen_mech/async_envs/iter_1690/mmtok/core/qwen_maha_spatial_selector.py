# MMTok: Multimodal Coverage Maximization for Efficient Inference of VLMs
# Paper: https://arxiv.org/abs/2508.18264
# Copyright (c) 2025 Zoom Communications, Inc.
# Author: Anonymous
# Licensed under the Apache License, Version 2.0

"""
QwenMahaSpatialFPSSelector: Mahalanobis-weighted, spatially-augmented greedy
farthest-point sampling for Qwen2.5-VL vision token selection.

Separates the selection algorithm from the model's forward-pass plumbing,
enabling safe AutoResearch experiments on the algorithm without risking
the multimodal sequence post-processing logic.
"""

from typing import List, Optional, Tuple

import torch


class QwenMahaSpatialAlgorithmCore:
    """
    Algorithm core for Qwen2.5-VL vision token selection.

    Combines feature-space Mahalanobis whitening with 2D spatial coordinates
    and greedy farthest-point sampling (facility location).
    """

    def __init__(self, mmtok_core=None):
        self.mmtok_core = mmtok_core

    def select_vision_tokens(
        self,
        image_embeds: torch.Tensor,
        image_features: torch.Tensor,
        question: str = "",
        target_vision_tokens: int = None,
        image_grid_thw: torch.Tensor = None,
        text_token_embedding: torch.Tensor = None,
    ) -> torch.Tensor:
        # --- ALGORITHM CORE START ---
        N, D_feat = image_features.shape
        K = target_vision_tokens

        # Compute Mahalanobis weights from CLIP feature variance (float32 for stability)
        image_features_f32 = image_features.to(torch.float32)
        eps = 1e-4
        var = torch.var(image_features_f32, dim=0, unbiased=False)  # (D_feat,)
        w = 1.0 / (var + eps)
        w_sqrt = torch.sqrt(w)  # (D_feat,)

        # Whiten features (implicit Mahalanobis distance -> Euclidean on scaled features)
        x_scaled = image_features_f32 * w_sqrt.unsqueeze(0)  # (N, D_feat)

        # Spatial coordinates
        H = int(N ** 0.5)
        if H * H == N:
            # Perfect square -> 2D grid
            y_coords, x_coords = torch.meshgrid(
                torch.arange(H, device=image_features.device, dtype=torch.float32),
                torch.arange(H, device=image_features.device, dtype=torch.float32),
                indexing='ij'
            )
            spatial = torch.stack([x_coords.reshape(-1), y_coords.reshape(-1)], dim=1)  # (N, 2)
        else:
            # Fallback: 1D normalised index
            spatial = torch.arange(N, device=image_features.device, dtype=torch.float32).unsqueeze(1)  # (N, 1)
            spatial = spatial / (N - 1) if N > 1 else spatial

        # Normalise spatial coordinates to [0, 1]
        spatial = spatial / spatial.max()

        beta = 1.0  # spatial weight

        # Joint embedding: whitened features + scaled spatial coordinates
        z = torch.cat([x_scaled, beta * spatial], dim=1)  # (N, D_feat + spatial_dim)

        # Greedy facility location (farthest point sampling on joint metric)
        min_dist = torch.full((N,), float('inf'), device=image_features.device)
        selected = []

        # Initialise with first token
        selected.append(0)
        d0 = torch.sum((z - z[0].unsqueeze(0)) ** 2, dim=1)
        min_dist = torch.minimum(min_dist, d0)

        for _ in range(1, K):
            idx = torch.argmax(min_dist).item()
            selected.append(idx)
            d_new = torch.sum((z - z[idx].unsqueeze(0)) ** 2, dim=1)
            min_dist = torch.minimum(min_dist, d_new)

        selected_indices = torch.tensor(selected, dtype=torch.long, device=image_features.device)
        # --- ALGORITHM CORE END ---
        return selected_indices

    def select_vision_tokens_batch(
        self,
        image_embeds_list,
        image_features_list,
        questions,
        target_vision_tokens_list,
        image_grid_thw_list=None,
    ):
        selected_indices_list = []
        n = len(image_embeds_list)
        for i in range(n):
            emb = image_embeds_list[i]
            feat = image_features_list[i]
            q = questions[i] if i < len(questions) else questions[-1]
            tgt = (
                target_vision_tokens_list[i]
                if i < len(target_vision_tokens_list)
                else target_vision_tokens_list[-1]
            )
            grid = None
            if image_grid_thw_list is not None and i < len(image_grid_thw_list):
                grid = image_grid_thw_list[i]

            selected_indices = self.select_vision_tokens(
                emb, feat, q, target_vision_tokens=tgt, image_grid_thw=grid
            )
            selected_indices_list.append(selected_indices)

        return selected_indices_list


class QwenMahaSpatialSelector:
    def __init__(self, target_vision_tokens: int = 32, alpha: float = 0.5):
        self.target_vision_tokens = target_vision_tokens
        self.alpha = alpha
        self._core = QwenMahaSpatialAlgorithmCore(mmtok_core=None)

    def mm_coverage_selection(
        self,
        text_token_embedding: torch.Tensor,
        vision_tokens: torch.Tensor,
        vision_tokens_clip: torch.Tensor,
        tv_temp: float = 0.01,
        vv_temp: float = 0.2,
        padding_patch_indices: Optional[List[int]] = None,
    ) -> Tuple[List[int], torch.Tensor]:
        selected_indices_tensor = self._core.select_vision_tokens(
            image_embeds=vision_tokens,
            image_features=vision_tokens_clip,
            question="",
            target_vision_tokens=self.target_vision_tokens,
            text_token_embedding=text_token_embedding,
        )
        selected_indices = selected_indices_tensor.tolist()
        if not isinstance(selected_indices, list):
            selected_indices = torch.tensor([selected_indices_tensor.item()], dtype=torch.long, device=vision_tokens.device)
        selected_tokens = vision_tokens[selected_indices_tensor]
        return selected_indices, selected_tokens
