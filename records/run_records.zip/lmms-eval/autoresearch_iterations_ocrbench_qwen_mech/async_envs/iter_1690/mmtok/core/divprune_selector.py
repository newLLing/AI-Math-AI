# MMTok: Multimodal Coverage Maximization for Efficient Inference of VLMs
# Paper: https://arxiv.org/abs/2508.18264
# Copyright (c) 2025 Zoom Communications, Inc.
# Author: Anonymous
# Licensed under the Apache License, Version 2.0

"""
DivPrune selector: diversity-based vision token selection via greedy
max-min cosine distance (a.k.a. farthest-point sampling in angular space).

Ignores text–vision coverage and selects purely by vision–vision diversity.
Compatible with the MMTok selector registry (mm_coverage_selection interface).
"""

from typing import List, Optional, Tuple

import torch


class DivPruneSelector:
    """
    Diversity pruning selector.

    Greedily picks vision tokens that maximize minimum pairwise cosine distance
    to already-selected tokens. Equivalent to a greedy farthest-point sampling
    in the angular space of vision features.
    """

    def __init__(self, target_vision_tokens: int = 32):
        self.target_vision_tokens = target_vision_tokens

    def mm_coverage_selection(
        self,
        text_token_embedding: torch.Tensor,
        vision_tokens: torch.Tensor,
        vision_tokens_clip: torch.Tensor,
        tv_temp: float = 0.01,
        vv_temp: float = 0.2,
        padding_patch_indices: Optional[List[int]] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        DivPrune selection: diversity-only greedy farthest-point sampling.

        Args:
            text_token_embedding: Ignored (present for API compatibility).
            vision_tokens: [N, D] mm_projector output embeddings (returned as selected tokens).
            vision_tokens_clip: [N, D] CLIP-space vision features used for diversity computation.
            tv_temp: Ignored.
            vv_temp: Ignored.
            padding_patch_indices: Optional list of indices to exclude from selection.

        Returns:
            (selected_indices, selected_vision_tokens)
        """
        features = vision_tokens_clip if vision_tokens_clip is not None else vision_tokens
        n = features.shape[0]
        target = min(self.target_vision_tokens, n)
        if target <= 0:
            return (
                torch.empty(0, dtype=torch.long, device=features.device),
                vision_tokens[:0],
            )

        # Pairwise cosine distance = 1 - cosine_similarity
        normed = features / features.norm(dim=1, keepdim=True).clamp(min=1e-8)
        cosine_matrix = torch.mm(normed, normed.t())
        distance_matrix = 1.0 - cosine_matrix

        selected = torch.empty(target, dtype=torch.long, device=features.device)
        selected_mask = torch.zeros(n, dtype=torch.bool, device=features.device)

        for i in range(target):
            if i == 0:
                scores = distance_matrix
            else:
                scores = distance_matrix[selected[:i], :]

            if i == 0:
                # First pick: maximize distance to the *second* nearest neighbor
                # (original DivPrune heuristic: topk(..., 2, largest=False).values[1, :])
                top2 = torch.topk(scores, 2, dim=0, largest=False).values
                agg_scores = top2[1, :]
            else:
                agg_scores = torch.min(scores, dim=0).values

            if padding_patch_indices is not None and len(padding_patch_indices) > 0:
                agg_scores[padding_patch_indices] = float("-inf")

            agg_scores[selected_mask] = float("-inf")

            best_idx = torch.argmax(agg_scores)
            selected[i] = best_idx
            selected_mask[best_idx] = True

        selected, _ = selected.sort()
        selected_tokens = vision_tokens[selected]
        return selected, selected_tokens
