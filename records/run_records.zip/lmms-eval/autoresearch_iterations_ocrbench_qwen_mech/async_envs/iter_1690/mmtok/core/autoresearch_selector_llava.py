import torch
import torch.nn.functional as F
from typing import List, Optional, Tuple
import math


class LLaVAAlgorithmCore:
    """
    Algorithm core for Qwen2.5-VL vision token selection.

    Separates the selection algorithm from the model's forward-pass plumbing,
    enabling safe AutoResearch experiments on the algorithm without risking
    the multimodal sequence post-processing logic.
    """

    def __init__(self, mmtok_core=None):
        self.mmtok_core = mmtok_core

    def select_vision_tokens(
        self,
        image_embeds: torch.Tensor,
        image_features: torch.Tensor,
        question: str = "",
        target_vision_tokens: int = None,
        image_grid_thw: torch.Tensor = None,
        text_token_embedding: torch.Tensor = None,
    ) -> torch.Tensor:
        # --- ALGORITHM CORE START ---
        # Projected‑Kernel Greedy (PKG) selection on image_embeds
        X = image_embeds.double()                        # [N, D]
        N, D = X.shape
        device = X.device

        # Pairwise squared Euclidean distances
        dist_sq = torch.cdist(X, X, p=2).pow(2)          # [N, N]

        # Estimate lengthscale from off‑diagonal median distance
        triu_idx = torch.triu_indices(N, N, offset=1, device=device)
        offdiag = dist_sq[triu_idx[0], triu_idx[1]]
        if offdiag.numel() == 0:   # all tokens collapse to a single point
            selected_indices = torch.randperm(N, device=device)[:target_vision_tokens]
            selected_indices = selected_indices.sort().values
            # --- ALGORITHM CORE END ---
        return selected_indices


    def select_vision_tokens_batch(
        self,
        image_embeds_list,
        image_features_list,
        questions,
        target_vision_tokens_list,
        image_grid_thw_list=None,
    ):
        selected_indices_list = []
        n = len(image_embeds_list)
        for i in range(n):
            emb = image_embeds_list[i]
            feat = image_features_list[i]
            q = questions[i] if i < len(questions) else questions[-1]
            tgt = (
                target_vision_tokens_list[i]
                if i < len(target_vision_tokens_list)
                else target_vision_tokens_list[-1]
            )
            grid = None
            if image_grid_thw_list is not None and i < len(image_grid_thw_list):
                grid = image_grid_thw_list[i]
            selected_indices = self.select_vision_tokens(
                emb, feat, q, target_vision_tokens=tgt, image_grid_thw=grid
            )
            selected_indices_list.append(selected_indices)
        return selected_indices_list