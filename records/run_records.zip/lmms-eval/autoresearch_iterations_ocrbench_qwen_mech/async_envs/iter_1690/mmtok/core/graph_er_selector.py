# MMTok: Multimodal Coverage Maximization for Efficient Inference of VLMs
# Paper: https://arxiv.org/abs/2508.18264
# Copyright (c) 2025 Zoom Communications, Inc.
# Licensed under the Apache License, Version 2.0

"""
Graph-Effective-Resistance vision token selector (iter_037).

Core operators:
1. Graph construction: similarity matrix A = X @ X^T, non-negative clip,
   combinatorial Laplacian L = D - A_pos.
2. Eigendecomposition of L (symmetric, guaranteed real eigenvalues).
3. Pseudoinverse of L via regularised eigenvalue inversion.
4. Effective-resistance leverage scores: diag(L^+).
5. Importance-weighted sampling: token L2 norms combined with leverage scores
   via power-law fusion (beta=0.5).
6. Multinomial sampling without replacement for final subset.

Note: This selector is stochastic (multinomial sampling). For deterministic
behaviour across runs, ensure a fixed torch manual seed before evaluation.
"""

from typing import List, Optional, Tuple

import torch


class GraphERSelector:
    """
    Graph Laplacian effective-resistance sampling selector.
    """

    def __init__(self, target_vision_tokens: int = 64):
        self.target_vision_tokens = target_vision_tokens

    def mm_coverage_selection(
        self,
        text_token_embedding: torch.Tensor,
        vision_tokens: torch.Tensor,
        vision_tokens_clip: torch.Tensor,
        tv_temp: float = 0.01,
        vv_temp: float = 0.2,
        padding_patch_indices: Optional[List[int]] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        device = vision_tokens.device
        N = vision_tokens.size(0)
        k = min(self.target_vision_tokens, N)

        if k <= 0:
            selected_indices = torch.empty(0, dtype=torch.long, device=device)
            selected_tokens = torch.empty(
                0, vision_tokens.size(1), device=device, dtype=vision_tokens.dtype
            )
            return selected_indices, selected_tokens
        elif k >= N or N == 0:
            selected_indices = torch.arange(N, device=device)
            return selected_indices, vision_tokens

        X = vision_tokens.to(torch.float32)
        w_importance = X.norm(p=2, dim=1)

        # Build similarity graph and Laplacian
        A = torch.mm(X, X.t())
        A_pos = A.clamp(min=0)
        deg = A_pos.sum(dim=1)
        D = torch.diag(deg)
        L = D - A_pos

        # Eigendecomposition
        eigvals, eigvecs = torch.linalg.eigh(L.to(torch.float32))
        eigvals = eigvals.clamp(min=0.0)

        # Pseudoinverse with regularisation
        reg = 1e-5
        mask = eigvals > reg
        inv_eigvals = torch.zeros_like(eigvals)
        inv_eigvals[mask] = 1.0 / eigvals[mask]

        # Effective-resistance leverage scores
        V_scaled = eigvecs[:, mask] * inv_eigvals[mask].sqrt()
        lev_scores = (V_scaled ** 2).sum(dim=1)

        # Importance-weighted fusion
        w_pos = w_importance.clamp(min=1e-8)
        beta = 0.5
        scores = w_pos * (lev_scores ** beta)

        # Exclude padding patches
        if padding_patch_indices is not None and len(padding_patch_indices) > 0:
            scores[padding_patch_indices] = 0.0

        probs = scores / scores.sum()

        # Sample without replacement
        selected = torch.multinomial(probs, num_samples=k, replacement=False)
        selected_indices = torch.sort(selected).values.to(torch.long)
        selected_tokens = vision_tokens[selected_indices]
        return selected_indices, selected_tokens
