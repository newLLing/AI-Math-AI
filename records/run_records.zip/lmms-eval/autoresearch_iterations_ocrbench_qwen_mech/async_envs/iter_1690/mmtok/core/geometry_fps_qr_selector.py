# MMTok: Multimodal Coverage Maximization for Efficient Inference of VLMs
# Paper: https://arxiv.org/abs/2508.18264
# Copyright (c) 2025 Zoom Communications, Inc.
# Licensed under the Apache License, Version 2.0

"""
Geometry-FPS-QR vision token selector (iter_413).

Core operators:
1. Randomized low-rank PCA for leverage scores (projection-based dimension reduction).
2. Query-relevance fusion: combined_score = leverage * relevance.
3. Statistical thresholding (mean + 0.5*std) to prune low-quality candidates.
4. Farthest Point Sampling (FPS) on the projected subspace for geometric spread.
5. Pivoted QR (volume-maximising) selection on the FPS candidate set.
"""

from typing import List, Optional, Tuple

import torch
import torch.nn.functional as F


class GeometryFPSQRSelector:
    """
    Geometry-based selector: leverage + relevance + FPS + pivoted QR.
    """

    def __init__(self, target_vision_tokens: int = 64):
        self.target_vision_tokens = target_vision_tokens

    def mm_coverage_selection(
        self,
        text_token_embedding: torch.Tensor,
        vision_tokens: torch.Tensor,
        vision_tokens_clip: torch.Tensor,
        tv_temp: float = 0.01,
        vv_temp: float = 0.2,
        padding_patch_indices: Optional[List[int]] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        device = vision_tokens.device
        N = vision_tokens.size(0)
        k = min(self.target_vision_tokens, N)

        if k <= 0:
            selected_indices = torch.empty(0, dtype=torch.long, device=device)
            selected_tokens = torch.empty(
                0, vision_tokens.size(1), device=device, dtype=vision_tokens.dtype
            )
            return selected_indices, selected_tokens
        elif k >= N or N == 0:
            selected_indices = torch.arange(N, device=device)
            return selected_indices, vision_tokens

        # 1. Query embedding & relevance
        if text_token_embedding is not None and text_token_embedding.numel() > 0:
            q_emb = text_token_embedding.mean(dim=0)
        else:
            q_emb = vision_tokens.mean(dim=0)

        image_embeds_norm = F.normalize(vision_tokens.float(), dim=-1)
        q_emb_norm = F.normalize(q_emb.float(), dim=-1)
        relevance = (image_embeds_norm * q_emb_norm.unsqueeze(0)).sum(dim=-1)
        relevance = torch.clamp(relevance, min=0)

        # 2. Feature matrix for leverage
        if vision_tokens_clip is not None and vision_tokens_clip.shape[1] > 0:
            X = vision_tokens_clip
        else:
            X = vision_tokens

        if X.dim() != 2:
            X = X.reshape(N, -1)
        X = X.to(dtype=torch.float32, device=device)
        feature_dim = X.shape[1]

        row_norms = torch.norm(X, dim=1)
        if row_norms.max() < 1e-8:
            perm = torch.randperm(N, device=device)[:k]
            selected_indices = torch.sort(perm).values
            return selected_indices, vision_tokens[selected_indices]

        # 3. Randomized low-rank PCA for leverage scores
        r = min(k, min(N, feature_dim) - 1)
        if r < 1:
            r = 1

        proj_dim = max(feature_dim // 4, 64)
        torch.manual_seed(42)
        random_proj = torch.randn(feature_dim, proj_dim, device=device, dtype=torch.float32)
        random_proj = random_proj / torch.sqrt(torch.tensor(proj_dim, dtype=torch.float32, device=device))
        X_proj = X @ random_proj
        X_proj_center = X_proj - X_proj.mean(dim=0, keepdim=True)

        U_proj, S_proj, _ = torch.svd_lowrank(X_proj_center, q=r, niter=2)
        leverage_scores = torch.norm(U_proj, dim=1)

        # 4. Fusion with query relevance
        combined_score = leverage_scores * (relevance + 1e-6)

        # Exclude padding patches
        if padding_patch_indices is not None and len(padding_patch_indices) > 0:
            exclude_mask = torch.zeros(N, dtype=torch.bool, device=device)
            exclude_mask[padding_patch_indices] = True
            combined_score[exclude_mask] = float("-inf")
            relevance[exclude_mask] = float("-inf")

        # 5. Statistical thresholding
        score_mean = combined_score.mean()
        score_std = combined_score.std()
        if score_std > 1e-8:
            threshold_val = score_mean + 0.5 * score_std
            valid_mask = combined_score > threshold_val
            if valid_mask.sum().item() < k:
                valid_mask = torch.ones_like(valid_mask)
        else:
            valid_mask = torch.ones_like(combined_score, dtype=torch.bool, device=device)

        n_valid = valid_mask.sum().item()
        m = min(N, max(int(2 * k), k))
        m = min(m, n_valid)

        # Normalized scores for FPS
        c_min = combined_score.min()
        c_max = combined_score.max()
        if c_max - c_min < 1e-8:
            normalized_score = torch.ones_like(combined_score)
        else:
            normalized_score = (combined_score - c_min) / (c_max - c_min)
        normalized_score[~valid_mask] = float("-inf")

        # 6. FPS on projected subspace
        X_proj_norm = F.normalize(X_proj.float(), dim=-1)
        S_matrix_fps = X_proj_norm @ X_proj_norm.t()

        alpha = 0.7
        init_idx = torch.argmax(normalized_score).item()
        selected = [init_idx]
        min_dist_to_S = 1.0 - S_matrix_fps[:, init_idx]

        for _ in range(1, m):
            obj = alpha * normalized_score + (1.0 - alpha) * min_dist_to_S
            obj[selected] = float("-inf")
            next_idx = torch.argmax(obj).item()
            selected.append(next_idx)
            new_dist = 1.0 - S_matrix_fps[:, next_idx]
            min_dist_to_S = torch.minimum(min_dist_to_S, new_dist)

        top_idx = torch.tensor(selected, device=device, dtype=torch.long)

        # 7. Pivoted QR on the FPS candidate set
        U_sub = U_proj[top_idx]

        def _pivoted_qr_selection(pts, num_select, dev):
            m_s, r_s = pts.shape
            if num_select >= m_s:
                return torch.arange(m_s, device=dev)
            pts = pts.to(torch.float32)
            selected_qr = []
            remaining = list(range(m_s))
            work = pts.clone()
            norms_qr = torch.norm(work, dim=1)
            for _ in range(num_select):
                rem_norms = norms_qr[remaining]
                idx_local = torch.argmax(rem_norms)
                col = remaining[idx_local]
                selected_qr.append(col)
                remaining.pop(idx_local)
                v = work[col]
                v_norm_sq = torch.dot(v, v)
                if v_norm_sq < 1e-12:
                    continue
                for j in remaining:
                    work[j] -= torch.dot(work[j], v) / v_norm_sq * v
                norms_qr = torch.norm(work, dim=1)
            return torch.tensor(selected_qr, device=dev)

        sub_selected = _pivoted_qr_selection(U_sub, k, device)
        selected_indices = top_idx[sub_selected].to(dtype=torch.long, device=device)
        selected_indices = torch.sort(selected_indices).values
        selected_tokens = vision_tokens[selected_indices]
        return selected_indices, selected_tokens
