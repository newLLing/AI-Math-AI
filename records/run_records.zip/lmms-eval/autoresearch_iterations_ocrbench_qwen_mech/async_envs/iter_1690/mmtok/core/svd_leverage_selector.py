# MMTok: Multimodal Coverage Maximization for Efficient Inference of VLMs
# Paper: https://arxiv.org/abs/2508.18264
# Copyright (c) 2025 Zoom Communications, Inc.
# Licensed under the Apache License, Version 2.0

"""
SVD低秩分解 + 杠杆分数的vision token选择器。

基于低秩SVD计算每个vision token的杠杆分数，
然后确定性选择Top-k个最高杠杆分数的token。
"""

from typing import Optional, List, Tuple

import torch


class SVDLeverageSelector:
    """
    SVD低秩分解 + 杠杆分数的vision token选择器。

    使用低秩SVD计算每个vision token的杠杆分数，
    然后确定性选择Top-k个最高杠杆分数的token。
    """

    def __init__(self, target_vision_tokens: int = 64):
        self.target_vision_tokens = target_vision_tokens

    def mm_coverage_selection(
        self,
        text_token_embedding: torch.Tensor,
        vision_tokens: torch.Tensor,
        vision_tokens_clip: torch.Tensor,
        tv_temp: float = 0.01,
        vv_temp: float = 0.2,
        padding_patch_indices: Optional[List[int]] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        基于SVD低秩分解和杠杆分数的vision token选择。

        Args:
            text_token_embedding: 未使用，保持接口兼容
            vision_tokens: [N, D] mm_projector输出的vision token
            vision_tokens_clip: [N, D] CLIP输出的vision token（用于SVD）
            tv_temp: 未使用，保持接口兼容
            vv_temp: 未使用，保持接口兼容
            padding_patch_indices: 未使用，保持接口兼容

        Returns:
            selected_indices: [K] 选中的token索引（已排序）
            selected_tokens: [K, D] 选中的vision token
        """
        device = vision_tokens.device
        N = vision_tokens.size(0)
        target_vision_tokens = min(self.target_vision_tokens, N)

        if target_vision_tokens <= 0:
            selected_indices = torch.empty(0, dtype=torch.long, device=device)
            selected_tokens = torch.empty(
                0, vision_tokens.size(1), device=device, dtype=vision_tokens.dtype
            )
            return selected_indices, selected_tokens
        elif target_vision_tokens >= N or N == 0:
            selected_indices = torch.arange(N, device=device)
            return selected_indices, vision_tokens

        # 确保2D输入
        image_features = vision_tokens_clip
        image_embeds = vision_tokens

        orig_embeds_shape = image_embeds.shape
        if image_features.dim() != 2:
            image_features = image_features.reshape(N, -1)
        if image_embeds.dim() != 2:
            image_embeds = image_embeds.reshape(N, -1)

        # 低秩SVD计算（使用float32保证数值稳定性）
        k = min(target_vision_tokens, image_features.size(1), N, 64)
        image_features_fp32 = image_features.to(torch.float32)

        # 使用低秩SVD
        U, _, _ = torch.svd_lowrank(image_features_fp32, q=k, niter=2, M=None)

        # 杠杆分数计算：||u_i||_2^2
        leverage = torch.sum(U * U, dim=1)  # [N]

        # 数值安全检查
        if (
            torch.isnan(leverage).any()
            or torch.isinf(leverage).any()
            or leverage.sum() < 1e-8
        ):
            # 回退：选择前target_vision_tokens个索引
            selected_indices = torch.arange(target_vision_tokens, device=device)
        else:
            # 确定性选择Top-k杠杆分数
            _, topk_idx = torch.topk(
                leverage, target_vision_tokens, largest=True, sorted=False
            )
            selected_indices = torch.sort(topk_idx).values

        # 提取选中的embeds
        selected_tokens = image_embeds[selected_indices]
        if len(orig_embeds_shape) > 2:
            selected_tokens = selected_tokens.reshape(-1, *orig_embeds_shape[1:])

        return selected_indices, selected_tokens
