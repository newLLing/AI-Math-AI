# MMTok: Multimodal Coverage Maximization for Efficient Inference of VLMs
# Paper: https://arxiv.org/abs/2508.18264
# Copyright (c) 2025 Zoom Communications, Inc.
# Author: Anonymous
# Licensed under the Apache License, Version 2.0

"""
QwenMorseDensitySelector: density-peaks vision token selection for Qwen2.5-VL.

Estimates local density via a Gaussian kernel on Johnson-Lindenstrauss projected
embeddings augmented with spatial coordinates, then scores each token by a Morse
persistence surrogate (density times distance to the nearest higher-density point).
"""

from typing import List, Optional, Tuple

import torch


class QwenMorseDensityAlgorithmCore:
    """
    Algorithm core for Qwen2.5-VL vision token selection.

    Separates the selection algorithm from the model's forward-pass plumbing,
    enabling safe AutoResearch experiments on the algorithm without risking
    the multimodal sequence post-processing logic.
    """

    def __init__(self, mmtok_core=None):
        self.mmtok_core = mmtok_core

    def select_vision_tokens(
        self,
        image_embeds: torch.Tensor,
        image_features: torch.Tensor,
        question: str = "",
        target_vision_tokens: int = None,
        image_grid_thw: torch.Tensor = None,
        text_token_embedding: torch.Tensor = None,
    ) -> torch.Tensor:
        # --- ALGORITHM CORE START ---
        N = image_embeds.shape[0]
        device = image_embeds.device
        original_dtype = image_embeds.dtype

        # Use image_embeds (mm_projector output) as the primary feature
        embeds_f32 = image_embeds.to(torch.float32)

        # Build spatial coordinates
        H = int(N ** 0.5)
        if H * H == N:
            yy, xx = torch.meshgrid(
                torch.linspace(0, 1, H, device=device),
                torch.linspace(0, 1, H, device=device),
                indexing='ij'
            )
            spatial_coords = torch.stack([yy.flatten(), xx.flatten()], dim=1)
        else:
            spatial_coords = torch.linspace(0, 1, N, device=device).unsqueeze(1)

        spatial_coords = spatial_coords.to(torch.float32)

        # Dimensionality reduction via Johnson-Lindenstrauss projection
        D = embeds_f32.shape[1]
        proj_dim = 128
        R = torch.randn(D, proj_dim, device=device, dtype=torch.float32) / (proj_dim ** 0.5)
        features_proj = embeds_f32 @ R

        # Augment with spatial coordinates (weight controls spatial influence)
        spatial_weight = 0.5
        aug = torch.cat([features_proj, spatial_weight * spatial_coords], dim=1)

        # Pairwise distance matrix
        D_mat = torch.cdist(aug, aug, p=2)

        # Automatic kernel bandwidth from median off-diagonal distance
        triu_idx = torch.triu_indices(N, N, offset=1, device=device)
        distances_off_diag = D_mat[triu_idx[0], triu_idx[1]]
        if distances_off_diag.numel() > 0:
            sigma = distances_off_diag.median()
        else:
            sigma = torch.tensor(1.0, device=device)
        sigma = sigma.clamp(min=1e-6)
        kernel_gamma = 1.0 / (2.0 * sigma ** 2)

        # Density estimation (Gaussian kernel)
        K = torch.exp(-kernel_gamma * D_mat ** 2)
        rho = K.sum(dim=1)  # (N,)

        # Compute delta: minimum distance to a point with higher density
        sort_rho, sort_idx = rho.sort(descending=True)
        delta = torch.zeros(N, device=device, dtype=torch.float32)
        # Point with highest density gets max distance to any other point
        delta[sort_idx[0]] = D_mat[sort_idx[0]].max()

        for k in range(1, N):
            i = sort_idx[k]                # current point index
            higher = sort_idx[:k]          # indices of points with higher density
            dists = D_mat[i, higher]       # distances to higher-density points
            delta[i] = dists.min()

        # Morse persistence surrogate score
        gamma_score = rho * delta

        # Select top-K tokens
        _, selected_indices = torch.topk(gamma_score, target_vision_tokens)

        # Ensure the output is a long tensor on the correct device
        selected_indices = selected_indices.to(torch.long)
        # --- ALGORITHM CORE END ---
        return selected_indices

    def select_vision_tokens_batch(
        self,
        image_embeds_list,
        image_features_list,
        questions,
        target_vision_tokens_list,
        image_grid_thw_list=None,
    ):
        selected_indices_list = []
        n = len(image_embeds_list)
        for i in range(n):
            emb = image_embeds_list[i]
            feat = image_features_list[i]
            q = questions[i] if i < len(questions) else questions[-1]
            tgt = (
                target_vision_tokens_list[i]
                if i < len(target_vision_tokens_list)
                else target_vision_tokens_list[-1]
            )
            grid = None
            if image_grid_thw_list is not None and i < len(image_grid_thw_list):
                grid = image_grid_thw_list[i]

            selected_indices = self.select_vision_tokens(
                emb, feat, q, target_vision_tokens=tgt, image_grid_thw=grid
            )
            selected_indices_list.append(selected_indices)

        return selected_indices_list


class QwenMorseDensitySelector:
    def __init__(self, target_vision_tokens: int = 32, alpha: float = 0.5):
        self.target_vision_tokens = target_vision_tokens
        self.alpha = alpha
        self._core = QwenMorseDensityAlgorithmCore(mmtok_core=None)

    def mm_coverage_selection(
        self,
        text_token_embedding: torch.Tensor,
        vision_tokens: torch.Tensor,
        vision_tokens_clip: torch.Tensor,
        tv_temp: float = 0.01,
        vv_temp: float = 0.2,
        padding_patch_indices: Optional[List[int]] = None,
    ) -> Tuple[List[int], torch.Tensor]:
        selected_indices_tensor = self._core.select_vision_tokens(
            image_embeds=vision_tokens,
            image_features=vision_tokens_clip,
            question="",
            target_vision_tokens=self.target_vision_tokens,
            text_token_embedding=text_token_embedding,
        )
        selected_indices = selected_indices_tensor.tolist()
        if not isinstance(selected_indices, list):
            selected_indices = torch.tensor([selected_indices_tensor.item()], dtype=torch.long, device=vision_tokens.device)
        selected_tokens = vision_tokens[selected_indices_tensor]
        return selected_indices, selected_tokens
