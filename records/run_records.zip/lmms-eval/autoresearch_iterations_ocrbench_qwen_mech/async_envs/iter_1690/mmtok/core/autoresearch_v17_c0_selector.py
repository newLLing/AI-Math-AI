
import torch
import torch.nn.functional as F
from typing import List, Optional, Tuple
import math

from loguru import logger as eval_logger
eval_logger.info("[MMTok] autoresearch_v17_c0_selector.py loaded")


class QwenAlgorithmCoreV11:
    """
    Algorithm core for Qwen2.5-VL vision token selection (v17).

    Separates the selection algorithm from the model's forward-pass plumbing,
    enabling safe AutoResearch experiments on the algorithm without risking
    the multimodal sequence post-processing logic.
    """

    def __init__(self, mmtok_core=None):
        self.mmtok_core = mmtok_core

    def select_vision_tokens(
        self,
        image_embeds: torch.Tensor,
        image_features: torch.Tensor,
        question: str = "",
        target_vision_tokens: int = None,
        image_grid_thw: torch.Tensor = None,
        text_token_embedding: torch.Tensor = None,
    ) -> torch.Tensor:
        # --- ALGORITHM CORE START ---
        N = image_embeds.shape[0]
        K = target_vision_tokens
        if K <= 0:
            return torch.empty(0, dtype=torch.long, device=image_embeds.device)
        if K >= N:
            return torch.arange(N, device=image_embeds.device)

        # QR‑Volume Greedy Selection (D‑optimal token sampling)
        X = image_features.to(torch.float32)                     # [N, d_feat]
        X_orth = X.clone()
        eps = 1e-12
        selected = []
        for _ in range(K):
            norms = (X_orth ** 2).sum(dim=1)                    # [N]
            for idx in selected:
                norms[idx] = -float('inf')
            idx = int(torch.argmax(norms).item())
            selected.append(idx)

            v = X_orth[idx]                                     # [d_feat]
            v_norm_sq = (v ** 2).sum() + eps
            dot = X_orth @ v                                    # [N]  # fixed: removed erroneous dtype conversion
            # deflation: project all rows onto the orthogonal complement of v
            X_orth = X_orth - (dot.unsqueeze(1) * v.unsqueeze(0)) / v_norm_sq

        selected_indices = torch.tensor(selected, dtype=torch.long, device=image_embeds.device)
        # --- ALGORITHM CORE END ---
        return selected_indices


    def select_vision_tokens_batch(
        self,
        image_embeds_list,
        image_features_list,
        questions,
        target_vision_tokens_list,
        image_grid_thw_list=None,
    ):
        selected_indices_list = []
        n = len(image_embeds_list)
        for i in range(n):
            emb = image_embeds_list[i]
            feat = image_features_list[i]
            q = questions[i] if i < len(questions) else questions[-1]
            tgt = (
                target_vision_tokens_list[i]
                if i < len(target_vision_tokens_list)
                else target_vision_tokens_list[-1]
            )
            grid = None
            if image_grid_thw_list is not None and i < len(image_grid_thw_list):
                grid = image_grid_thw_list[i]

            selected_indices = self.select_vision_tokens(
                emb, feat, q, target_vision_tokens=tgt, image_grid_thw=grid
            )
            selected_indices_list.append(selected_indices)

        return selected_indices_list


class AutoResearchSelectorV170:
    def __init__(self, target_vision_tokens: int = 32, alpha: float = 0.5):
        self.target_vision_tokens = target_vision_tokens
        self.alpha = alpha
        self._core = QwenAlgorithmCoreV11(mmtok_core=None)

    def mm_coverage_selection(
        self,
        text_token_embedding: torch.Tensor,
        vision_tokens: torch.Tensor,
        vision_tokens_clip: torch.Tensor,
        tv_temp: float = 0.01,
        vv_temp: float = 0.2,
        padding_patch_indices: Optional[List[int]] = None,
    ) -> Tuple[List[int], torch.Tensor]:
        selected_indices_tensor = self._core.select_vision_tokens(
            image_embeds=vision_tokens,
            image_features=vision_tokens_clip,
            question="",
            target_vision_tokens=self.target_vision_tokens,
            text_token_embedding=text_token_embedding,
        )
        selected_indices = selected_indices_tensor.tolist()
        if not isinstance(selected_indices, list):
            selected_indices = [selected_indices]
        selected_tokens = vision_tokens[selected_indices_tensor]
        return selected_indices, selected_tokens




