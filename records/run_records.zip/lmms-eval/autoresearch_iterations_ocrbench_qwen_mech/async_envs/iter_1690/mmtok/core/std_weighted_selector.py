# MMTok: Multimodal Coverage Maximization for Efficient Inference of VLMs
# Paper: https://arxiv.org/abs/2508.18264
# Copyright (c) 2025 Zoom Communications, Inc.
# Licensed under the Apache License, Version 2.0

"""
Std-Weighted vision token selector (optimised iter_422 / iter_376_std_weighted).

Combines query relevance, SVD leverage scores, per-token variance weighting,
anchor+Pivoted QR selection, submodular refinement, and dispersion refinement.

Key performance optimisation over the original iter_422 forward block:
- Submodular refinement uses the Matrix Determinant Lemma to evaluate all
  candidate swaps for a fixed drop-token in a single batched pass (O(M*r^2))
  instead of O(M) independent Cholesky decompositions (O(M*r^3)).
- Dispersion refinement similarly vectorises the pairwise-cosine evaluation.
"""

from typing import List, Optional, Tuple

import torch
import torch.nn.functional as F


class StdWeightedSelector:
    """
    Std-Weighted vision token selector.

    Preserves the full iter_422 algorithmic logic while replacing Python-loop
    bottlenecks with batched tensor operations.
    """

    def __init__(self, target_vision_tokens: int = 64):
        self.target_vision_tokens = target_vision_tokens

    def mm_coverage_selection(
        self,
        text_token_embedding: torch.Tensor,
        vision_tokens: torch.Tensor,
        vision_tokens_clip: torch.Tensor,
        tv_temp: float = 0.01,
        vv_temp: float = 0.2,
        padding_patch_indices: Optional[List[int]] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Std-Weighted vision token selection.

        Args:
            text_token_embedding: [T, D] text token embeddings (question/keywords).
            vision_tokens: [N, D] mm_projector output tokens (used for returns).
            vision_tokens_clip: [N, D] CLIP output tokens (used for leverage/X).
            tv_temp: Unused (interface compatibility).
            vv_temp: Unused (interface compatibility).
            padding_patch_indices: Optional list of indices to exclude from selection.

        Returns:
            selected_indices: [K] sorted LongTensor of selected token indices.
            selected_tokens: [K, D] selected vision tokens (from vision_tokens).
        """
        device = vision_tokens.device
        N = vision_tokens.size(0)
        k = min(self.target_vision_tokens, N)

        if k <= 0:
            selected_indices = torch.empty(0, dtype=torch.long, device=device)
            selected_tokens = torch.empty(
                0, vision_tokens.size(1), device=device, dtype=vision_tokens.dtype
            )
            return selected_indices, selected_tokens
        elif k >= N or N == 0:
            selected_indices = torch.arange(N, device=device)
            return selected_indices, vision_tokens

        # ------------------------------------------------------------------
        # 1. Query embedding & relevance
        # ------------------------------------------------------------------
        if text_token_embedding is not None and text_token_embedding.numel() > 0:
            q_emb = text_token_embedding.mean(dim=0)
        else:
            q_emb = vision_tokens.mean(dim=0)

        image_embeds = vision_tokens
        image_embeds_norm = F.normalize(image_embeds.float(), dim=-1)
        q_emb_norm = F.normalize(q_emb.float(), dim=0)
        relevance = (image_embeds_norm * q_emb_norm.unsqueeze(0)).sum(dim=-1)
        relevance = torch.clamp(relevance, min=0.0)

        # ------------------------------------------------------------------
        # 2. Feature matrix for leverage / variance
        # ------------------------------------------------------------------
        if vision_tokens_clip is not None and vision_tokens_clip.shape[1] > 0:
            X = vision_tokens_clip
        else:
            X = vision_tokens

        if X.dim() != 2:
            X = X.reshape(N, -1)
        X = X.to(dtype=torch.float32, device=device)
        feature_dim = X.shape[1]

        # Per-token standard deviation (normalised)
        token_std = X.std(dim=1)
        std_min = token_std.min()
        std_max = token_std.max()
        token_std_norm = (token_std - std_min) / (std_max - std_min + 1e-8)
        beta = 0.1

        # ------------------------------------------------------------------
        # 3. Leverage scores via random projection + truncated SVD
        # ------------------------------------------------------------------
        row_norms = torch.norm(X, dim=1)
        if row_norms.max() < 1e-8:
            # Fallback: random selection when input is near-zero
            perm = torch.randperm(N, device=device)[:k]
            selected_indices = torch.sort(perm).values
            selected_tokens = vision_tokens[selected_indices]
            return selected_indices, selected_tokens

        r = min(k, min(N, feature_dim) - 1)
        if r < 1:
            r = 1
        proj_dim = max(feature_dim // 4, 64)
        torch.manual_seed(42)
        random_proj = torch.randn(feature_dim, proj_dim, device=device, dtype=torch.float32)
        random_proj = random_proj / torch.sqrt(torch.tensor(proj_dim, dtype=torch.float32, device=device))
        X_proj = X @ random_proj
        X_proj_center = X_proj - X_proj.mean(dim=0, keepdim=True)
        U_proj, _, _ = torch.svd_lowrank(X_proj_center, q=r, niter=2)
        r = U_proj.shape[1]  # actual rank returned by svd_lowrank (may be < q)
        leverage_scores = torch.norm(U_proj, dim=1)

        # ------------------------------------------------------------------
        # 4. Combined score (leverage * relevance * variance_weight)
        # ------------------------------------------------------------------
        combined_score = leverage_scores * (relevance + 1e-6) * (1.0 + beta * token_std_norm)

        # Exclude padding patches from ever being selected
        if padding_patch_indices is not None and len(padding_patch_indices) > 0:
            exclude_mask = torch.zeros(N, dtype=torch.bool, device=device)
            exclude_mask[padding_patch_indices] = True
            combined_score[exclude_mask] = float("-inf")
            relevance[exclude_mask] = float("-inf")

        # ------------------------------------------------------------------
        # 5. Anchor selection + Pivoted QR
        # ------------------------------------------------------------------
        anchor_frac = 0.2
        t = max(1, int(anchor_frac * k)) if k > 0 else 0
        t = min(t, k)

        if t == k:
            _, top_idx = torch.topk(relevance, k)
            selected_indices = top_idx.to(dtype=torch.long, device=device)
        else:
            _, anchor_topk = torch.topk(relevance, t)
            anchor_indices = anchor_topk.to(dtype=torch.long, device=device)
            mask_non_anchor = torch.ones(N, dtype=torch.bool, device=device)
            mask_non_anchor[anchor_indices] = False
            remaining_indices_all = torch.arange(N, device=device)[mask_non_anchor]
            m_prime = max(0, min(2 * (k - t), remaining_indices_all.numel()))
            if m_prime > 0:
                combined_remaining = combined_score[remaining_indices_all]
                _, top_m_remaining = torch.topk(combined_remaining, m_prime)
                top_m_prime_indices = remaining_indices_all[top_m_remaining]
            else:
                top_m_prime_indices = torch.empty(0, dtype=torch.long, device=device)
            candidate_pool = torch.cat([anchor_indices, top_m_prime_indices])
            U_cand = U_proj[candidate_pool]  # [cand_size, r]

            def _pivoted_qr_with_anchors(pts, num_anchors, num_to_select):
                M, r_dim = pts.shape
                selected = []
                for i in range(num_anchors):
                    v = pts[i].clone()
                    v_norm_sq = torch.dot(v, v)
                    if v_norm_sq < 1e-12:
                        continue
                    selected.append(i)
                    for j in range(num_anchors, M):
                        pts[j] -= torch.dot(pts[j], v) / v_norm_sq * v
                remaining = list(range(num_anchors, M))
                for _ in range(num_to_select):
                    if not remaining:
                        break
                    rem_norms = torch.norm(pts[remaining], dim=1)
                    idx_local = torch.argmax(rem_norms)
                    col = remaining[idx_local]
                    selected.append(col)
                    remaining.pop(idx_local)
                    v = pts[col].clone()
                    v_norm_sq = torch.dot(v, v)
                    if v_norm_sq < 1e-12:
                        continue
                    projections = (pts[remaining] @ v) / v_norm_sq
                    pts[remaining] -= projections.unsqueeze(1) * v
                return selected

            num_candidates = candidate_pool.shape[0]
            num_additional = k - t
            if num_additional > 0 and num_candidates > t:
                max_additional = num_candidates - t
                num_additional = min(num_additional, max_additional)
                local_selected = _pivoted_qr_with_anchors(
                    U_cand.clone(), t, num_additional
                )
                selected_indices = candidate_pool[local_selected].to(
                    dtype=torch.long, device=device
                )
            else:
                selected_indices = anchor_indices[:k]

        # ------------------------------------------------------------------
        # 6. Submodular refinement (vectorised swap evaluation)
        # ------------------------------------------------------------------
        lambda_reg = 1.0
        U_all = U_proj.to(torch.float32)  # [N, r]
        k_val = selected_indices.numel()

        if k_val > 0 and candidate_pool.numel() > k_val:
            # Build candidate set from unused tokens with highest combined_score
            unused_mask = torch.ones(N, dtype=torch.bool, device=device)
            unused_mask[selected_indices] = False
            unused_indices = torch.arange(N, device=device)[unused_mask]
            if unused_indices.numel() > 0:
                M_cand = min(k_val, unused_indices.numel())
                comb_unused = combined_score[unused_indices]
                _, top_cand = torch.topk(comb_unused, M_cand)
                candidate_indices = unused_indices[top_cand]
            else:
                candidate_indices = torch.empty(0, dtype=torch.long, device=device)

            # Pre-compute current F(S) and logdet(G)
            def _compute_logdet_from_G(G_mat):
                try:
                    L = torch.linalg.cholesky(
                        G_mat + 1e-6 * torch.eye(r, device=device, dtype=torch.float32)
                    )
                    return 2.0 * torch.sum(torch.log(torch.diag(L)))
                except RuntimeError:
                    eigvals = torch.linalg.eigvalsh(G_mat)
                    return torch.sum(torch.log(eigvals + 1e-8))

            U_S = U_all[selected_indices]  # [k_val, r]
            G = torch.eye(r, device=device, dtype=torch.float32) + U_S.t() @ U_S
            logdet_G = _compute_logdet_from_G(G)
            rel_sum_S = relevance[selected_indices].sum()
            current_F = rel_sum_S + lambda_reg * logdet_G

            # Outer loop: at most 1 pass (matching original max_iters=1)
            if candidate_indices.numel() > 0:
                # Precompute G_inv once
                G_inv = torch.linalg.inv(
                    G + 1e-6 * torch.eye(r, device=device, dtype=torch.float32)
                )
                U_cand_batch = U_all[candidate_indices]  # [M, r]
                rel_cand = relevance[candidate_indices]  # [M]
                M = candidate_indices.numel()

                improved = False
                # Traverse in the same order as the original iter_422 code:
                # sorted by selected index value, not by storage order.
                sorted_order = torch.argsort(selected_indices)
                for idx_in_S in sorted_order:
                    i = selected_indices[idx_in_S]
                    u_i = U_all[i]  # [r]
                    rel_i = relevance[i]

                    # S_minus indices
                    mask_minus = torch.ones(k_val, dtype=torch.bool, device=device)
                    mask_minus[idx_in_S] = False
                    S_minus = selected_indices[mask_minus]

                    # Vectorised Matrix Determinant Lemma for all candidates
                    v_i = G_inv @ u_i  # [r]
                    u_i_dot_v_i = torch.dot(u_i, v_i)

                    # V = G_inv @ U_cand_batch.T  => [r, M]
                    V = G_inv @ U_cand_batch.t()

                    # diag_terms[j] = u_j^T G^{-1} u_j
                    diag_terms = torch.sum(U_cand_batch * V.t(), dim=1)  # [M]

                    # cross_terms[j] = u_i^T G^{-1} u_j
                    cross_terms = u_i @ V  # [M]

                    # det(I_2 + A_j) where A_j = V_j^T G^{-1} U_j
                    det_factor = (1.0 - u_i_dot_v_i) * (1.0 + diag_terms) + cross_terms ** 2
                    det_factor = torch.clamp(det_factor, min=1e-10)

                    logdet_new = logdet_G + torch.log(det_factor)
                    rel_sum_new = rel_sum_S - rel_i + rel_cand
                    F_new = rel_sum_new + lambda_reg * logdet_new
                    gains = F_new - current_F

                    best_gain = gains.max()
                    if best_gain > 1e-6:
                        best_j_idx = gains.argmax()
                        best_j = candidate_indices[best_j_idx]

                        # Apply swap
                        selected_indices = torch.cat([S_minus, best_j.unsqueeze(0)])
                        selected_indices = selected_indices.to(dtype=torch.long, device=device)

                        # Update candidate pool
                        keep_mask = torch.ones(M, dtype=torch.bool, device=device)
                        keep_mask[best_j_idx] = False
                        candidate_indices = candidate_indices[keep_mask]
                        # Optionally add i back
                        if combined_score[i] > combined_score[candidate_indices].min():
                            if candidate_indices.numel() < M_cand:
                                candidate_indices = torch.cat([candidate_indices, i.unsqueeze(0)])
                            else:
                                comb_cand = combined_score[candidate_indices]
                                min_idx = torch.argmin(comb_cand)
                                if combined_score[i] > comb_cand[min_idx]:
                                    candidate_indices[min_idx] = i

                        # Recompute G, logdet_G, current_F for next potential iteration
                        k_val = selected_indices.numel()
                        U_S = U_all[selected_indices]
                        G = torch.eye(r, device=device, dtype=torch.float32) + U_S.t() @ U_S
                        logdet_G = _compute_logdet_from_G(G)
                        rel_sum_S = relevance[selected_indices].sum()
                        current_F = rel_sum_S + lambda_reg * logdet_G

                        if candidate_indices.numel() > 0:
                            G_inv = torch.linalg.inv(
                                G + 1e-6 * torch.eye(r, device=device, dtype=torch.float32)
                            )
                            U_cand_batch = U_all[candidate_indices]
                            rel_cand = relevance[candidate_indices]
                            M = candidate_indices.numel()

                        improved = True
                        break  # restart outer loop (matching original logic)

        # ------------------------------------------------------------------
        # 7. Dispersion refinement (vectorised, preserving F_vol constraint)
        # ------------------------------------------------------------------
        max_sim_threshold = 0.95
        max_swap_steps = 2

        selected_mask = torch.zeros(N, dtype=torch.bool, device=device)
        selected_mask[selected_indices] = True

        # Candidate pool: highest-scored tokens not currently selected
        disp_candidates = torch.arange(N, device=device)[~selected_mask]
        M_disp = min(k, disp_candidates.numel())
        if disp_candidates.numel() > 0:
            comb_disp = combined_score[disp_candidates]
            _, top_disp = torch.topk(comb_disp, M_disp)
            disp_candidates = disp_candidates[top_disp]

        # Precompute full cosine similarity matrix
        C = image_embeds_norm @ image_embeds_norm.t()  # [N, N]

        for _ in range(max_swap_steps):
            k_sel = selected_indices.numel()
            if k_sel <= 1:
                break

            sel_C = C[selected_indices][:, selected_indices]
            tri_u = torch.triu(sel_C, diagonal=1)
            current_max_sim = tri_u.max() if tri_u.numel() > 0 else torch.tensor(0.0, device=device)
            if current_max_sim <= max_sim_threshold:
                break

            # Precompute current F(S) and G_inv for this swap step
            U_S = U_all[selected_indices]
            G = torch.eye(r, device=device, dtype=torch.float32) + U_S.t() @ U_S
            logdet_G = _compute_logdet_from_G(G)
            rel_sum_S = relevance[selected_indices].sum()
            current_F = rel_sum_S + lambda_reg * logdet_G
            G_inv = torch.linalg.inv(
                G + 1e-6 * torch.eye(r, device=device, dtype=torch.float32)
            )

            best_gain = -float("inf")
            best_swap = None

            for idx_i, i in enumerate(selected_indices):
                # S_minus indices after removing i
                S_minus = torch.cat([selected_indices[:idx_i], selected_indices[idx_i + 1 :]])

                if S_minus.numel() > 0:
                    S_minus_C = C[S_minus][:, S_minus]
                    tri_u_minus = torch.triu(S_minus_C, diagonal=1)
                    base_max_sim = (
                        tri_u_minus.max() if tri_u_minus.numel() > 0 else torch.tensor(0.0, device=device)
                    )
                else:
                    base_max_sim = torch.tensor(0.0, device=device)

                # Valid replacement candidates
                valid_cand_mask = ~selected_mask[disp_candidates]
                valid_candidates = disp_candidates[valid_cand_mask]
                if valid_candidates.numel() == 0:
                    continue

                # Batch compute max_sim_new for all candidates
                if S_minus.numel() > 0:
                    cand_sims = C[valid_candidates][:, S_minus]
                    cand_max = cand_sims.max(dim=1).values
                    max_sim_new_vals = torch.maximum(base_max_sim, cand_max)
                else:
                    max_sim_new_vals = torch.full(
                        (valid_candidates.numel(),), base_max_sim.item(), device=device
                    )

                # Batch compute F_new for all candidates via Matrix Determinant Lemma
                u_i = U_all[i]
                rel_i = relevance[i]
                v_i = G_inv @ u_i
                u_i_dot_v_i = torch.dot(u_i, v_i)
                U_cand_batch = U_all[valid_candidates]
                V = G_inv @ U_cand_batch.t()
                diag_terms = torch.sum(U_cand_batch * V.t(), dim=1)
                cross_terms = u_i @ V
                det_factor = (1.0 - u_i_dot_v_i) * (1.0 + diag_terms) + cross_terms ** 2
                det_factor = torch.clamp(det_factor, min=1e-10)
                logdet_new = logdet_G + torch.log(det_factor)
                rel_sum_new = rel_sum_S - rel_i + relevance[valid_candidates]
                F_new = rel_sum_new + lambda_reg * logdet_new

                # Apply original filters and gain formula
                valid_f = F_new >= current_F - 1e-5
                valid_sim = max_sim_new_vals < current_max_sim
                gains = (current_max_sim - max_sim_new_vals) - 10.0 * torch.clamp(current_F - F_new, min=0.0)
                valid = valid_f & valid_sim & (gains > 1e-8)

                if valid.any():
                    local_best_gain, local_best_idx = gains[valid].max(dim=0)
                    if local_best_gain > best_gain:
                        best_gain = local_best_gain
                        actual_idx = valid.nonzero(as_tuple=True)[0][local_best_idx]
                        best_j = valid_candidates[actual_idx]
                        best_swap = (i, best_j)

            if best_swap is not None and best_gain > 1e-8:
                i, j = best_swap
                selected_indices = selected_indices[selected_indices != i]
                selected_indices = torch.cat([selected_indices, j.unsqueeze(0)])
                selected_mask[i] = False
                selected_mask[j] = True

                # Update dispersion candidate pool
                disp_candidates = disp_candidates[disp_candidates != j]
                if selected_mask[i]:
                    if disp_candidates.numel() < M_disp:
                        disp_candidates = torch.cat([disp_candidates, i.unsqueeze(0)])
                    else:
                        comb_disp_cand = combined_score[disp_candidates]
                        min_idx = torch.argmin(comb_disp_cand)
                        if combined_score[i] > comb_disp_cand[min_idx]:
                            disp_candidates[min_idx] = i
            else:
                break

        # Sort indices for deterministic ordering
        selected_indices = torch.sort(selected_indices).values
        selected_tokens = vision_tokens[selected_indices]
        return selected_indices, selected_tokens
