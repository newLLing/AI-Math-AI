# MMTok: Multimodal Coverage Maximization for Efficient Inference of VLMs
# Paper: https://arxiv.org/abs/2508.18264
# Copyright (c) 2025 Zoom Communications, Inc.
# Author: Anonymous
# Licensed under the Apache License, Version 2.0

"""
GOTS selector: greedy orthogonal token selection via an implicit-residual
QRCP kernel.

The kernel preserves the same greedy pivoting rule as explicit residual-matrix
orthogonalization in exact arithmetic, while avoiding the N x d residual update
at every iteration.
"""

from typing import List, Optional, Tuple

import torch

from loguru import logger as eval_logger

eval_logger.info("[MMTok] gots_selector.py loaded")


def gots_implicit_kernel(
    image_features: torch.Tensor,
    target_vision_tokens: int,
    eps: float = 1e-12,
) -> torch.Tensor:
    """Implicit-residual QRCP/GOTS selection.

    It preserves the same greedy pivoting rule as explicit residual-matrix
    orthogonalization in exact arithmetic, while avoiding the N x d residual
    update at every iteration.
    """
    N, feature_dim = image_features.shape
    K = min(target_vision_tokens, N)
    device = image_features.device

    if K <= 0 or N == 0:
        return torch.empty(0, dtype=torch.long, device=device)

    if K >= N:
        return torch.arange(N, dtype=torch.long, device=device)

    # R is no longer modified, so float32 input does not need to be cloned.
    if image_features.dtype == torch.float32:
        X = image_features.detach()
        if not X.is_contiguous():
            X = X.contiguous()
    else:
        X = image_features.detach().float().contiguous()

    selected = torch.empty(K, dtype=torch.long, device=device)

    # basis[t] stores q_t: [K, d].
    basis = torch.empty(
        (K, feature_dim),
        dtype=X.dtype,
        device=device,
    )

    # coefficients[t, j] = <x_j, q_t>: [K, N].
    # Each row is contiguous and can be used as the output of torch.mv.
    coefficients = torch.empty(
        (K, N),
        dtype=X.dtype,
        device=device,
    )

    # Avoid constructing X.square(), which would allocate an N x d tensor.
    residual_norm2 = torch.linalg.vector_norm(
        X,
        ord=2,
        dim=1,
    )
    residual_norm2.square_()

    # Temporary vector used only to reconstruct the selected residual.
    projection = torch.empty(
        feature_dim,
        dtype=X.dtype,
        device=device,
    )

    for step in range(K):
        pivot = torch.argmax(residual_norm2)
        selected[step] = pivot

        # Use the corresponding row in the preallocated basis as q.
        q = basis[step]
        q.copy_(X[pivot])

        if step > 0:
            # r_i = x_i - sum_l <x_i, q_l> q_l
            #
            # basis[:step].T: [d, step]
            # coefficients[:step, pivot]: [step]
            torch.mv(
                basis[:step].transpose(0, 1),
                coefficients[:step, pivot],
                out=projection,
            )
            q.sub_(projection)

        # Normalize with the tracked residual energy.
        #
        # Do not use sqrt(e) + eps: the subsequent energy update assumes
        # q has unit norm. Clamp the squared norm before rsqrt instead.
        pivot_norm2 = residual_norm2[pivot].clamp_min(eps)
        q.mul_(torch.rsqrt(pivot_norm2))

        # coefficients[step, j] = <x_j, q>
        dot = coefficients[step]
        torch.mv(X, q, out=dot)

        # ||r_j_new||^2 = ||r_j_old||^2 - <x_j, q>^2
        residual_norm2.addcmul_(
            dot,
            dot,
            value=-1.0,
        )

        residual_norm2[pivot] = -torch.inf

    return selected.sort().values


class GOTSAlgorithmCore:
    """Algorithm core that exposes the GOTS implicit kernel."""

    def __init__(self, mmtok_core=None):
        self.mmtok_core = mmtok_core

    @torch.inference_mode()
    def select_vision_tokens(
        self,
        image_embeds: torch.Tensor,
        image_features: torch.Tensor,
        question: str = "",
        target_vision_tokens: int = None,
        image_grid_thw: torch.Tensor = None,
        text_token_embedding: torch.Tensor = None,
    ) -> torch.Tensor:
        return gots_implicit_kernel(
            image_features=image_features,
            target_vision_tokens=target_vision_tokens,
        )

    @torch.inference_mode()
    def select_vision_tokens_batch(
        self,
        image_embeds_list,
        image_features_list,
        questions,
        target_vision_tokens_list,
        image_grid_thw_list=None,
    ):
        selected_indices_list = []

        num_samples = len(image_embeds_list)
        num_questions = len(questions)
        num_targets = len(target_vision_tokens_list)
        num_grids = (
            len(image_grid_thw_list)
            if image_grid_thw_list is not None
            else 0
        )

        default_question = questions[-1] if num_questions > 0 else ""
        default_target = target_vision_tokens_list[-1]

        for i in range(num_samples):
            emb = image_embeds_list[i]
            feat = image_features_list[i]

            question = (
                questions[i]
                if i < num_questions
                else default_question
            )

            target = (
                target_vision_tokens_list[i]
                if i < num_targets
                else default_target
            )

            grid = (
                image_grid_thw_list[i]
                if image_grid_thw_list is not None and i < num_grids
                else None
            )

            selected_indices = self.select_vision_tokens(
                image_embeds=emb,
                image_features=feat,
                question=question,
                target_vision_tokens=target,
                image_grid_thw=grid,
            )

            selected_indices_list.append(selected_indices)

        return selected_indices_list


class GOTSSelector:
    """MMTok selector registry wrapper for the GOTS algorithm."""

    def __init__(
        self,
        target_vision_tokens: int = 32,
    ):
        self.target_vision_tokens = target_vision_tokens
        self._core = GOTSAlgorithmCore(mmtok_core=None)

    @torch.inference_mode()
    def mm_coverage_selection(
        self,
        text_token_embedding: torch.Tensor,
        vision_tokens: torch.Tensor,
        vision_tokens_clip: torch.Tensor,
        tv_temp: float = 0.01,
        vv_temp: float = 0.2,
        padding_patch_indices: Optional[List[int]] = None,
        image_grid_thw: torch.Tensor = None,
    ) -> Tuple[List[int], torch.Tensor]:
        selected_indices_tensor = self._core.select_vision_tokens(
            image_embeds=vision_tokens,
            image_features=vision_tokens_clip,
            question="",
            target_vision_tokens=self.target_vision_tokens,
            text_token_embedding=text_token_embedding,
            image_grid_thw=image_grid_thw,
        )

        if padding_patch_indices is not None and len(padding_patch_indices) > 0:
            mask = torch.ones(
                vision_tokens.shape[0], dtype=torch.bool, device=vision_tokens.device
            )
            mask[padding_patch_indices] = False
            valid_mask = mask[selected_indices_tensor]
            selected_indices_tensor = selected_indices_tensor[valid_mask]
            max_k = min(self.target_vision_tokens, len(selected_indices_tensor))
            selected_indices_tensor = selected_indices_tensor[:max_k]

        selected_tokens = torch.index_select(
            vision_tokens,
            dim=0,
            index=selected_indices_tensor,
        )

        selected_indices = selected_indices_tensor.tolist()
        if not isinstance(selected_indices, list):
            selected_indices = [selected_indices]

        return selected_indices, selected_tokens
