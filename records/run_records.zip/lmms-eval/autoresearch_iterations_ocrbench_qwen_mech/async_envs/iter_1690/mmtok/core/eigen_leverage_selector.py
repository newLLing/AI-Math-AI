# MMTok: Multimodal Coverage Maximization for Efficient Inference of VLMs
# Paper: https://arxiv.org/abs/2508.18264
# Copyright (c) 2025 Zoom Communications, Inc.
# Licensed under the Apache License, Version 2.0

"""
Eigen-Leverage vision token selector (iter_086).

Core operators:
1. Gram matrix construction G = X^T X.
2. Truncated eigendecomposition via torch.linalg.eigh (stable symmetric path).
3. Effective-rank estimation (ignore near-zero eigenvalues).
4. Leverage scores = row-wise squared norms of the reconstructed left-singular
   vectors U_r = X @ V_r @ diag(1/s).
5. Direct top-k selection by leverage score.
"""

from typing import List, Optional, Tuple

import torch


class EigenLeverageSelector:
    """
    Eigen-decomposition-based leverage score selector.
    """

    def __init__(self, target_vision_tokens: int = 64):
        self.target_vision_tokens = target_vision_tokens

    def mm_coverage_selection(
        self,
        text_token_embedding: torch.Tensor,
        vision_tokens: torch.Tensor,
        vision_tokens_clip: torch.Tensor,
        tv_temp: float = 0.01,
        vv_temp: float = 0.2,
        padding_patch_indices: Optional[List[int]] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        device = vision_tokens.device
        N = vision_tokens.size(0)
        k = min(self.target_vision_tokens, N)

        if k <= 0:
            selected_indices = torch.empty(0, dtype=torch.long, device=device)
            selected_tokens = torch.empty(
                0, vision_tokens.size(1), device=device, dtype=vision_tokens.dtype
            )
            return selected_indices, selected_tokens
        elif k >= N or N == 0:
            selected_indices = torch.arange(N, device=device)
            return selected_indices, vision_tokens

        # Use vision_tokens as feature matrix
        X = vision_tokens.to(torch.float32)
        if X.abs().sum() == 0:
            selected_indices = torch.randperm(N, device=device)[:k]
            selected_indices = torch.sort(selected_indices).values
            return selected_indices, vision_tokens[selected_indices]

        # Gram matrix and eigendecomposition
        G = torch.mm(X.t(), X)
        eigvals, eigvecs = torch.linalg.eigh(G.to(torch.float32))

        # Effective rank estimation
        max_eigval = eigvals[-1] if eigvals[-1] > 0 else 1.0
        tol = 1e-5 * max_eigval
        r_usable = (eigvals > tol).sum().item()
        r = min(k, r_usable)
        if r == 0:
            selected_indices = torch.randperm(N, device=device)[:k]
            selected_indices = torch.sort(selected_indices).values
            return selected_indices, vision_tokens[selected_indices]

        # Top-r eigencomponents
        V_r = eigvecs[:, -r:]
        s = torch.sqrt(eigvals[-r:])
        s_inv = 1.0 / s

        Xproj = torch.mm(X, V_r)
        U_r = Xproj * s_inv.unsqueeze(0)

        leverage_scores = torch.sum(U_r ** 2, dim=1)

        # Exclude padding patches
        if padding_patch_indices is not None and len(padding_patch_indices) > 0:
            leverage_scores[padding_patch_indices] = float("-inf")

        selected_indices = torch.topk(leverage_scores, k, largest=True).indices
        selected_indices = torch.sort(selected_indices).values
        selected_tokens = vision_tokens[selected_indices]
        return selected_indices, selected_tokens
