# MMTok: Multimodal Coverage Maximization for Efficient Inference of VLMs
# Paper: https://arxiv.org/abs/2508.18264
# Copyright (c) 2025 Zoom Communications, Inc.
# Author: Anonymous
# Licensed under the Apache License, Version 2.0

"""
QwenSRDPPSelector: spatially regularized DPP-based vision token selection for
Qwen2.5-VL.

Combines Gram-Schmidt residual marginal gains (DPP-style diversity) with a
Gaussian spatial penalty to encourage spatial coverage across the image grid.
"""

from typing import List, Optional, Tuple

import torch


class QwenSRDPPAlgorithmCore:
    """
    Algorithm core for Qwen2.5-VL vision token selection.

    Separates the selection algorithm from the model's forward-pass plumbing,
    enabling safe AutoResearch experiments on the algorithm without risking
    the multimodal sequence post-processing logic.
    """

    def __init__(self, mmtok_core=None):
        self.mmtok_core = mmtok_core

    def select_vision_tokens(
        self,
        image_embeds: torch.Tensor,
        image_features: torch.Tensor,
        question: str = "",
        target_vision_tokens: int = None,
        image_grid_thw: torch.Tensor = None,
        text_token_embedding: torch.Tensor = None,
    ) -> torch.Tensor:
        # --- ALGORITHM CORE START ---
        # DPP-based token selection with spatial penalty (sr_dpp_select)
        # Parameters (tuned for 24x24 grid, normalized to [0,1] coordinates)
        gamma = 0.3   # spatial penalty weight
        sigma = 0.1   # spatial kernel bandwidth

        N, d_features = image_features.shape
        K = target_vision_tokens
        device = image_features.device
        # Use float32 for numerical stability in Gram-Schmidt
        feats = image_features.to(torch.float32)
        # Build spatial grid positions (2D or fallback 1D)
        H = int(N ** 0.5)
        if H * H == N:
            # perfect square grid
            if H > 1:
                y_coords = torch.arange(H, device=device, dtype=torch.float32) / (H - 1)
                x_coords = torch.arange(H, device=device, dtype=torch.float32) / (H - 1)
            else:
                y_coords = torch.zeros(1, device=device, dtype=torch.float32)
                x_coords = torch.zeros(1, device=device, dtype=torch.float32)
            grid_y, grid_x = torch.meshgrid(y_coords, x_coords, indexing='ij')
            grid_pos = torch.stack([grid_y.flatten(), grid_x.flatten()], dim=1)  # (N, 2)
        else:
            # 1D spatial arrangement (fallback)
            x_pos = torch.arange(N, device=device, dtype=torch.float32) / max(N - 1, 1)
            grid_pos = torch.stack([x_pos, x_pos], dim=1)  # both coordinates identical

        x_norm_sq = torch.sum(feats ** 2, dim=1)  # (N,)
        selected = []
        B_mat = torch.empty(d_features, 0, dtype=torch.float32, device=device)
        coef = torch.empty(N, 0, dtype=torch.float32, device=device)
        penalty = torch.zeros(N, dtype=torch.float32, device=device)

        for step in range(K):
            # 1. Residual norm squared
            if coef.shape[1] > 0:
                residual_norm_sq = x_norm_sq - coef.pow(2).sum(dim=1)
            else:
                residual_norm_sq = x_norm_sq.clone()
            residual_norm_sq = torch.clamp(residual_norm_sq, min=0.0)

            # 2. DPP marginal gain
            dpp_gain = torch.log1p(residual_norm_sq)

            # 3. Combined score with spatial penalty
            scores = dpp_gain - gamma * penalty

            # 4. Mask already selected indices
            if len(selected) > 0:
                mask_tensor = torch.tensor(selected, device=device, dtype=torch.long)
                scores[mask_tensor] = -float('inf')

            # 5. Select next token
            idx = torch.argmax(scores).item()
            selected.append(idx)

            # 6. Update spatial penalty
            dist_sq = ((grid_pos - grid_pos[idx]) ** 2).sum(dim=1)
            k_vals = torch.exp(-dist_sq / (2.0 * sigma ** 2))
            penalty = penalty + k_vals

            # 7. Update orthogonal basis and projection coefficients
            v = feats[idx]
            if B_mat.shape[1] > 0:
                c_old = B_mat.t() @ v
                v_resid = v - B_mat @ c_old
            else:
                v_resid = v
            norm_resid = torch.norm(v_resid)
            if norm_resid > 1e-8:  # threshold for float32 (increase to 1e-5 for fp16/bf16)
                q = v_resid / norm_resid
                B_mat = torch.cat([B_mat, q.unsqueeze(1)], dim=1)
                new_col = feats @ q
                if coef.shape[1] == 0:
                    coef = new_col.unsqueeze(1)
                else:
                    coef = torch.cat([coef, new_col.unsqueeze(1)], dim=1)

        selected_indices = torch.tensor(selected, device=device, dtype=torch.long)
        # --- ALGORITHM CORE END ---
        return selected_indices

    def select_vision_tokens_batch(
        self,
        image_embeds_list,
        image_features_list,
        questions,
        target_vision_tokens_list,
        image_grid_thw_list=None,
    ):
        selected_indices_list = []
        n = len(image_embeds_list)
        for i in range(n):
            emb = image_embeds_list[i]
            feat = image_features_list[i]
            q = questions[i] if i < len(questions) else questions[-1]
            tgt = (
                target_vision_tokens_list[i]
                if i < len(target_vision_tokens_list)
                else target_vision_tokens_list[-1]
            )
            grid = None
            if image_grid_thw_list is not None and i < len(image_grid_thw_list):
                grid = image_grid_thw_list[i]

            selected_indices = self.select_vision_tokens(
                emb, feat, q, target_vision_tokens=tgt, image_grid_thw=grid
            )
            selected_indices_list.append(selected_indices)

        return selected_indices_list


class QwenSRDPPSelector:
    def __init__(self, target_vision_tokens: int = 32, alpha: float = 0.5):
        self.target_vision_tokens = target_vision_tokens
        self.alpha = alpha
        self._core = QwenSRDPPAlgorithmCore(mmtok_core=None)

    def mm_coverage_selection(
        self,
        text_token_embedding: torch.Tensor,
        vision_tokens: torch.Tensor,
        vision_tokens_clip: torch.Tensor,
        tv_temp: float = 0.01,
        vv_temp: float = 0.2,
        padding_patch_indices: Optional[List[int]] = None,
    ) -> Tuple[List[int], torch.Tensor]:
        selected_indices_tensor = self._core.select_vision_tokens(
            image_embeds=vision_tokens,
            image_features=vision_tokens_clip,
            question="",
            target_vision_tokens=self.target_vision_tokens,
            text_token_embedding=text_token_embedding,
        )
        selected_indices = selected_indices_tensor.tolist()
        if not isinstance(selected_indices, list):
            selected_indices = torch.tensor([selected_indices_tensor.item()], dtype=torch.long, device=vision_tokens.device)
        selected_tokens = vision_tokens[selected_indices_tensor]
        return selected_indices, selected_tokens
