# MMTok: Multimodal Coverage Maximization for Efficient Inference of VLMs
# Paper: https://arxiv.org/abs/2508.18264
# Copyright (c) 2025 Zoom Communications, Inc.
# Licensed under the Apache License, Version 2.0

"""
Iter450 Gram-Inverse Greedy Selector (autoresearch iter_450).

A diversity-first token selector that uses an incremental Gram-matrix-inverse
update for fast greedy selection:

1. First token: largest L2 norm squared.
2. Subsequent tokens: greedily pick the token that maximises
   ||x_i||^2 - x_i^T S (I + S^T S)^{-1} S^T x_i,
   where S is the matrix of already-selected tokens.
3. Maintain (I + S S^T)^{-1} via the block-matrix inversion formula,
   avoiding O(K^2 N d) recomputation.

This approximates a determinantal point process (DPP) greedy objective
with efficient incremental updates.
"""

from typing import List, Optional, Tuple

import torch


class Iter450GramInvSelector:
    """
    Iter450 Gram-Inverse greedy vision token selector.
    """

    def __init__(self, target_vision_tokens: int = 64, sort_indices: bool = True):
        self.target_vision_tokens = target_vision_tokens
        self.sort_indices = sort_indices

    @torch.no_grad()
    def mm_coverage_selection(
        self,
        text_token_embedding: torch.Tensor,
        vision_tokens: torch.Tensor,
        vision_tokens_clip: torch.Tensor,
        tv_temp: float = 0.01,
        vv_temp: float = 0.2,
        padding_patch_indices: Optional[List[int]] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Apply Iter450 Gram-Inverse greedy selection on vision tokens.

        Args:
            text_token_embedding: Unused (interface compatibility).
            vision_tokens: [N, D] mm_projector output tokens.
            vision_tokens_clip: Unused (interface compatibility).
            tv_temp: Unused (interface compatibility).
            vv_temp: Unused (interface compatibility).
            padding_patch_indices: Optional list of indices to exclude from selection.

        Returns:
            selected_indices: [K] sorted LongTensor of selected token indices.
            selected_tokens: [K, D] selected vision tokens.
        """
        device = vision_tokens.device
        N = vision_tokens.size(0)
        k = min(self.target_vision_tokens, N)

        if k <= 0:
            selected_indices = torch.empty(0, dtype=torch.long, device=device)
            selected_tokens = torch.empty(
                0, vision_tokens.size(1), device=device, dtype=vision_tokens.dtype
            )
            return selected_indices, selected_tokens
        elif k >= N or N == 0:
            selected_indices = torch.arange(N, device=device)
            return selected_indices, vision_tokens

        X = vision_tokens
        d = X.shape[1]

        # Candidate mask excluding padding patches
        candidate_mask = torch.ones(N, dtype=torch.bool, device=device)
        if padding_patch_indices is not None and len(padding_patch_indices) > 0:
            if isinstance(padding_patch_indices, torch.Tensor):
                pad_idx = padding_patch_indices.to(device)
            else:
                pad_idx = torch.tensor(padding_patch_indices, dtype=torch.long, device=device)
            candidate_mask[pad_idx] = False

        num_eligible = candidate_mask.sum().item()

        if k >= num_eligible:
            selected_indices = torch.where(candidate_mask)[0]
            return selected_indices, vision_tokens[selected_indices]

        X_f32 = X.to(torch.float32) if X.dtype != torch.float32 else X
        norms_sq = torch.sum(X_f32 ** 2, dim=1)  # (N,)
        mask = candidate_mask.clone()
        selected = []
        S_feats = torch.empty(0, d, dtype=torch.float32, device=device)
        M_inv = None  # Gram inverse (I + S S^T)^{-1}, size (t x t)
        jitter = 1e-6  # small regularization for numerical stability

        for t in range(k):
            if t == 0:
                scores = norms_sq.clone()
            else:
                proj = X_f32 @ S_feats.T  # (N, t)
                scores = norms_sq - torch.sum(proj * (proj @ M_inv), dim=1)

            # Exclude already selected / padding tokens
            scores[~mask] = -float("inf")
            best_idx = torch.argmax(scores).item()
            selected.append(best_idx)
            mask[best_idx] = False

            # Grow S_feats
            new_feat = X_f32[best_idx:best_idx + 1]  # (1, d)
            S_feats = torch.cat([S_feats, new_feat], dim=0)  # (t+1, d)

            # Incremental update of M_inv
            if t == 0:
                s = new_feat[0]  # (d,)
                M_val = 1.0 + jitter + torch.dot(s, s)
                M_inv = (1.0 / M_val).unsqueeze(-1).unsqueeze(-1)  # (1, 1)
            else:
                s = new_feat[0]  # (d,)
                # S_feats now has t+1 rows; previous M_inv corresponds to first t rows
                b = S_feats[:-1] @ s.unsqueeze(-1)  # (t, 1)
                c = 1.0 + jitter + torch.dot(s, s)  # scalar
                u = M_inv @ b  # (t, 1)
                k_val = c - (b.t() @ u).squeeze()  # scalar

                # Assemble M_inv_new using block inversion formula
                top_left = M_inv + (1.0 / k_val) * (u @ u.t())
                top_right = -(1.0 / k_val) * u
                bottom_left = -(1.0 / k_val) * u.t()
                bottom_right = (1.0 / k_val).unsqueeze(-1).unsqueeze(-1)

                M_inv = torch.cat(
                    [torch.cat([top_left, top_right], dim=1),
                     torch.cat([bottom_left, bottom_right], dim=1)], dim=0
                )

        selected_indices = torch.tensor(selected, dtype=torch.long, device=device)
        if self.sort_indices:
            selected_indices = torch.sort(selected_indices).values
        selected_tokens = vision_tokens[selected_indices]
        return selected_indices, selected_tokens
