
import torch
import torch.nn.functional as F
from typing import List, Optional, Tuple
import math

from loguru import logger as eval_logger
eval_logger.info("[MMTok] autoresearch_v35_c0_selector.py loaded")


@torch.jit.script
def greedy_orthogonal_selection_jit(
    R: torch.Tensor,
    K: int,
) -> torch.Tensor:
    """
    JIT-fused greedy determinant-maximization via incremental orthogonalization.

    Equivalent to repeatedly picking the row with largest residual norm and
    projecting all rows onto the orthogonal complement of that direction.
    Squared norms are updated incrementally to avoid a full (R*R).sum() each
    iteration.

    Args:
        R: [N, D] vision feature matrix (float32).
        K: Number of tokens to select (0 <= K <= N).

    Returns:
        selected: [K] sorted Long indices of selected rows.
    """
    N = R.size(0)
    device = R.device
    eps = 1e-8

    selected = torch.zeros(K, dtype=torch.long, device=device)
    available = torch.ones(N, dtype=torch.bool, device=device)

    # Incrementally maintained squared L2 norms of the residual rows.
    norm2 = torch.sum(R * R, dim=1)
    neg_inf = float("-inf")

    for step in range(K):
        # Exclude already-selected rows from argmax.
        masked_norm2 = norm2.masked_fill(~available, neg_inf)

        i = torch.argmax(masked_norm2)
        available[i] = False
        selected[step] = i

        # New orthonormal basis vector: q = R[i] / ||R[i]||
        norm_i = torch.sqrt(norm2[i].clamp_min(0.0) + eps)
        q = R[i] / norm_i

        # Projection coefficients of all rows onto q.
        dot = torch.matmul(R, q.unsqueeze(1)).squeeze(1)

        # Orthogonalize every row: R <- R - (R q) q^T
        R = R - dot.unsqueeze(1) * q.unsqueeze(0)

        # Update squared norms incrementally: ||R'||^2 = ||R||^2 - (R·q)^2
        norm2 = norm2 - dot * dot
        norm2 = torch.clamp(norm2, min=0.0)

    return selected.sort()[0]


class QwenAlgorithmCoreV35:
    """
    Algorithm core for Qwen2.5-VL vision token selection (v35).

    Same greedy determinant-maximization as v34 (no positional augmentation),
    but the selection loop is JIT-compiled and uses incremental norm updates
    to reduce Python/GPU-kernel launch overhead.
    """

    def __init__(self, mmtok_core=None):
        self.mmtok_core = mmtok_core

    def select_vision_tokens(
        self,
        image_embeds: torch.Tensor,
        image_features: torch.Tensor,
        question: str = "",
        target_vision_tokens: int = None,
        image_grid_thw: torch.Tensor = None,
        text_token_embedding: torch.Tensor = None,
    ) -> torch.Tensor:
        # --- ALGORITHM CORE START ---
        N = image_features.size(0)
        K = target_vision_tokens
        device = image_features.device

        # Boundary cases
        if K <= 0 or N == 0:
            selected_indices = torch.empty(0, dtype=torch.long, device=device)
        elif K >= N:
            selected_indices = torch.arange(N, dtype=torch.long, device=device)
        else:
            R = image_features.to(torch.float32)
            selected_indices = greedy_orthogonal_selection_jit(R, K)
        # --- ALGORITHM CORE END ---
        return selected_indices

    def select_vision_tokens_batch(
        self,
        image_embeds_list,
        image_features_list,
        questions,
        target_vision_tokens_list,
        image_grid_thw_list=None,
    ):
        selected_indices_list = []
        n = len(image_embeds_list)
        for i in range(n):
            emb = image_embeds_list[i]
            feat = image_features_list[i]
            q = questions[i] if i < len(questions) else questions[-1]
            tgt = (
                target_vision_tokens_list[i]
                if i < len(target_vision_tokens_list)
                else target_vision_tokens_list[-1]
            )
            grid = None
            if image_grid_thw_list is not None and i < len(image_grid_thw_list):
                grid = image_grid_thw_list[i]

            selected_indices = self.select_vision_tokens(
                emb, feat, q, target_vision_tokens=tgt, image_grid_thw=grid
            )
            selected_indices_list.append(selected_indices)

        return selected_indices_list


class AutoResearchSelectorV350:
    def __init__(self, target_vision_tokens: int = 32, alpha: float = 0.5):
        self.target_vision_tokens = target_vision_tokens
        self.alpha = alpha
        self._core = QwenAlgorithmCoreV35(mmtok_core=None)

    def mm_coverage_selection(
        self,
        text_token_embedding: torch.Tensor,
        vision_tokens: torch.Tensor,
        vision_tokens_clip: torch.Tensor,
        tv_temp: float = 0.01,
        vv_temp: float = 0.2,
        padding_patch_indices: Optional[List[int]] = None,
        image_grid_thw: torch.Tensor = None,
    ) -> Tuple[List[int], torch.Tensor]:
        selected_indices_tensor = self._core.select_vision_tokens(
            image_embeds=vision_tokens,
            image_features=vision_tokens_clip,
            question="",
            target_vision_tokens=self.target_vision_tokens,
            text_token_embedding=text_token_embedding,
            image_grid_thw=image_grid_thw,
        )
        selected_indices = selected_indices_tensor.tolist()
        if not isinstance(selected_indices, list):
            selected_indices = [selected_indices]
        selected_tokens = vision_tokens[selected_indices_tensor]
        return selected_indices, selected_tokens
