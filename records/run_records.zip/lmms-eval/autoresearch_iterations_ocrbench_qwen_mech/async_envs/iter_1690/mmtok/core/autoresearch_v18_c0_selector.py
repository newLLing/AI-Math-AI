
import math
from typing import List, Optional, Tuple

import torch
import torch.nn.functional as F
from loguru import logger as eval_logger

eval_logger.info("[MMTok] autoresearch_v18_c0_selector.py loaded")


class QwenAlgorithmCoreV18:
    """
    Hybrid vision-token selector:

    1. Select a small set of MMTok-style safety anchors using
       text-to-vision and vision-to-vision coverage.
    2. Initialize QR deflation with those anchors.
    3. Use QR-volume greedy selection to fill the remaining budget.

    anchor_ratio=0.0 exactly recovers the pure QR-volume selector.
    """

    def __init__(self, mmtok_core=None):
        self.mmtok_core = mmtok_core
        self._warned_text_dim_mismatch = False

    @staticmethod
    def _flatten_token_tensor(
        x: Optional[torch.Tensor],
    ) -> Optional[torch.Tensor]:
        """Convert [..., D] token tensors to [num_tokens, D]."""
        if x is None or x.numel() == 0:
            return None
        if x.dim() == 1:
            return x.unsqueeze(0)
        return x.reshape(-1, x.shape[-1])

    @staticmethod
    def _get_valid_indices(
        num_tokens: int,
        device: torch.device,
        padding_patch_indices: Optional[List[int]],
    ) -> torch.Tensor:
        valid_mask = torch.ones(
            num_tokens,
            dtype=torch.bool,
            device=device,
        )

        if padding_patch_indices:
            padding = torch.as_tensor(
                padding_patch_indices,
                dtype=torch.long,
                device=device,
            )
            padding = padding[
                (padding >= 0) & (padding < num_tokens)
            ]
            if padding.numel() > 0:
                valid_mask[padding.unique()] = False

        return torch.nonzero(
            valid_mask,
            as_tuple=False,
        ).flatten()

    def _select_coverage_anchors(
        self,
        image_embeds: torch.Tensor,
        image_features: torch.Tensor,
        text_token_embedding: Optional[torch.Tensor],
        num_anchors: int,
        alpha: float,
        tv_temp: float,
        vv_temp: float,
    ) -> List[int]:
        """
        Greedy submodular coverage on the valid-token subset.

        Returns local indices in [0, M), where M is the number of valid
        visual tokens.

        Text coverage:
            each text token is covered by its best selected visual token.

        Visual coverage:
            each visual token is represented by its best selected anchor.
        """
        M = image_features.shape[0]

        if num_anchors <= 0 or M == 0:
            return []

        num_anchors = min(num_anchors, M)
        alpha = float(max(0.0, min(1.0, alpha)))
        tv_temp = max(float(tv_temp), 1e-6)
        vv_temp = max(float(vv_temp), 1e-6)

        # ------------------------------------------------------------
        # Vision-to-vision coverage in pre-projector feature space.
        #
        # Rows: candidate anchor tokens.
        # Cols: visual tokens that need to be represented.
        # ------------------------------------------------------------
        clip_tokens = F.normalize(
            torch.nan_to_num(image_features.float()),
            p=2,
            dim=-1,
            eps=1e-6,
        )

        vv_logits = (
            clip_tokens
            @ clip_tokens.transpose(0, 1)
        )  # [M, M]

        # For every target token, normalize over candidate anchors.
        vv_coverage = torch.softmax(
            vv_logits / vv_temp,
            dim=0,
        )

        current_vv = torch.zeros(
            M,
            dtype=torch.float32,
            device=image_features.device,
        )

        # ------------------------------------------------------------
        # Text-to-vision coverage in post-projector feature space.
        #
        # Rows: candidate visual tokens.
        # Cols: text tokens that need to be covered.
        # ------------------------------------------------------------
        tv_coverage = None
        current_tv = None

        text_tokens = self._flatten_token_tensor(
            text_token_embedding
        )

        if text_tokens is not None:
            if text_tokens.shape[-1] == image_embeds.shape[-1]:
                vision_tokens = F.normalize(
                    torch.nan_to_num(image_embeds.float()),
                    p=2,
                    dim=-1,
                    eps=1e-6,
                )

                text_tokens = F.normalize(
                    torch.nan_to_num(
                        text_tokens.float()
                    ).to(image_embeds.device),
                    p=2,
                    dim=-1,
                    eps=1e-6,
                )

                tv_logits = (
                    vision_tokens
                    @ text_tokens.transpose(0, 1)
                )  # [M, T]

                # For every text token, normalize over visual candidates.
                tv_coverage = torch.softmax(
                    tv_logits / tv_temp,
                    dim=0,
                )

                current_tv = torch.zeros(
                    tv_coverage.shape[1],
                    dtype=torch.float32,
                    device=image_embeds.device,
                )

            elif not self._warned_text_dim_mismatch:
                eval_logger.warning(
                    "[MMTok-v18] text/image embedding dimensions "
                    "do not match: "
                    f"text={text_tokens.shape[-1]}, "
                    f"vision={image_embeds.shape[-1]}. "
                    "Safety anchors will use visual coverage only."
                )
                self._warned_text_dim_mismatch = True

        selected: List[int] = []

        selected_mask = torch.zeros(
            M,
            dtype=torch.bool,
            device=image_features.device,
        )

        for _ in range(num_anchors):
            # Mean marginal gain keeps the two terms comparable.
            gain_vv = torch.clamp(
                vv_coverage - current_vv.unsqueeze(0),
                min=0.0,
            ).mean(dim=1)

            if tv_coverage is not None:
                gain_tv = torch.clamp(
                    tv_coverage - current_tv.unsqueeze(0),
                    min=0.0,
                ).mean(dim=1)

                score = (
                    alpha * gain_tv
                    + (1.0 - alpha) * gain_vv
                )
            else:
                score = gain_vv

            score = score.masked_fill(
                selected_mask,
                -torch.inf,
            )

            idx = int(torch.argmax(score).item())

            selected.append(idx)
            selected_mask[idx] = True

            current_vv = torch.maximum(
                current_vv,
                vv_coverage[idx],
            )

            if tv_coverage is not None:
                current_tv = torch.maximum(
                    current_tv,
                    tv_coverage[idx],
                )

        return selected

    @staticmethod
    def _deflate_once(
        residual_features: torch.Tensor,
        selected_idx: int,
        eps: float,
    ) -> torch.Tensor:
        """
        Project all feature rows onto the orthogonal complement of the
        selected residual direction.
        """
        v = residual_features[selected_idx]
        norm_sq = torch.dot(v, v)

        if (
            not torch.isfinite(norm_sq)
            or norm_sq <= eps
        ):
            return residual_features

        q = v * torch.rsqrt(norm_sq + eps)
        projection = residual_features @ q

        return (
            residual_features
            - projection.unsqueeze(1) * q.unsqueeze(0)
        )

    def select_vision_tokens(
        self,
        image_embeds: torch.Tensor,
        image_features: torch.Tensor,
        question: str = "",
        target_vision_tokens: Optional[int] = None,
        image_grid_thw: Optional[torch.Tensor] = None,
        text_token_embedding: Optional[torch.Tensor] = None,
        anchor_ratio: float = 0.125,
        alpha: float = 0.5,
        tv_temp: float = 0.01,
        vv_temp: float = 0.2,
        padding_patch_indices: Optional[List[int]] = None,
    ) -> torch.Tensor:
        del question, image_grid_thw

        if target_vision_tokens is None:
            raise ValueError(
                "target_vision_tokens must be provided."
            )

        if (
            image_embeds.dim() != 2
            or image_features.dim() != 2
        ):
            raise ValueError(
                "image_embeds and image_features must both be "
                "2-D tensors, but got "
                f"{tuple(image_embeds.shape)} and "
                f"{tuple(image_features.shape)}."
            )

        if image_embeds.shape[0] != image_features.shape[0]:
            raise ValueError(
                "image_embeds and image_features must have the "
                "same token count, but got "
                f"{image_embeds.shape[0]} and "
                f"{image_features.shape[0]}."
            )

        device = image_embeds.device
        N = image_embeds.shape[0]
        K = int(target_vision_tokens)

        if K <= 0 or N == 0:
            return torch.empty(
                0,
                dtype=torch.long,
                device=device,
            )

        valid_indices = self._get_valid_indices(
            num_tokens=N,
            device=device,
            padding_patch_indices=padding_patch_indices,
        )

        M = int(valid_indices.numel())

        if M == 0:
            return torch.empty(
                0,
                dtype=torch.long,
                device=device,
            )

        K = min(K, M)

        if K == M:
            return valid_indices

        # Work only on valid, non-padding tokens.
        valid_embeds = image_embeds.index_select(
            0,
            valid_indices,
        )

        valid_features = image_features.index_select(
            0,
            valid_indices,
        )

        ratio = max(
            0.0,
            min(1.0, float(anchor_ratio)),
        )

        num_anchors = (
            min(K, int(math.ceil(K * ratio)))
            if ratio > 0.0
            else 0
        )

        # Stage 1: MMTok-style safety anchors.
        selected_local = self._select_coverage_anchors(
            image_embeds=valid_embeds,
            image_features=valid_features,
            text_token_embedding=text_token_embedding,
            num_anchors=num_anchors,
            alpha=alpha,
            tv_temp=tv_temp,
            vv_temp=vv_temp,
        )

        # Stage 2: QR-volume continuation conditioned on anchors.
        residual = torch.nan_to_num(
            valid_features.float()
        ).clone()

        selected_mask = torch.zeros(
            M,
            dtype=torch.bool,
            device=device,
        )

        eps = 1e-12

        for idx in selected_local:
            selected_mask[idx] = True
            residual = self._deflate_once(
                residual,
                idx,
                eps,
            )

        while len(selected_local) < K:
            residual_norms = residual.square().sum(
                dim=1
            )

            residual_norms = residual_norms.masked_fill(
                selected_mask,
                -torch.inf,
            )

            idx = int(
                torch.argmax(residual_norms).item()
            )

            selected_local.append(idx)
            selected_mask[idx] = True

            residual = self._deflate_once(
                residual,
                idx,
                eps,
            )

        selected_local_tensor = torch.tensor(
            selected_local,
            dtype=torch.long,
            device=device,
        )

        # Map local valid-token indices back to original indices.
        return valid_indices.index_select(
            0,
            selected_local_tensor,
        )

    def select_vision_tokens_batch(
        self,
        image_embeds_list,
        image_features_list,
        questions,
        target_vision_tokens_list,
        image_grid_thw_list=None,
        text_token_embedding_list=None,
        padding_patch_indices_list=None,
        anchor_ratio: float = 0.125,
        alpha: float = 0.5,
        tv_temp: float = 0.01,
        vv_temp: float = 0.2,
    ):
        selected_indices_list = []
        n = len(image_embeds_list)

        for i in range(n):
            emb = image_embeds_list[i]
            feat = image_features_list[i]

            q = (
                questions[i]
                if i < len(questions)
                else questions[-1]
            )

            tgt = (
                target_vision_tokens_list[i]
                if i < len(target_vision_tokens_list)
                else target_vision_tokens_list[-1]
            )

            grid = None
            if (
                image_grid_thw_list is not None
                and i < len(image_grid_thw_list)
            ):
                grid = image_grid_thw_list[i]

            text_emb = None
            if (
                text_token_embedding_list is not None
                and i < len(text_token_embedding_list)
            ):
                text_emb = text_token_embedding_list[i]

            padding = None
            if (
                padding_patch_indices_list is not None
                and i < len(padding_patch_indices_list)
            ):
                padding = padding_patch_indices_list[i]

            selected_indices = self.select_vision_tokens(
                image_embeds=emb,
                image_features=feat,
                question=q,
                target_vision_tokens=tgt,
                image_grid_thw=grid,
                text_token_embedding=text_emb,
                anchor_ratio=anchor_ratio,
                alpha=alpha,
                tv_temp=tv_temp,
                vv_temp=vv_temp,
                padding_patch_indices=padding,
            )

            selected_indices_list.append(
                selected_indices
            )

        return selected_indices_list


class AutoResearchSelectorV180:
    """
    Recommended first setting:
        anchor_ratio = 0.125

    Ablations:
        anchor_ratio = 0.0   -> pure v17 QR selector
        anchor_ratio = 0.125 -> 1/8 safety anchors
        anchor_ratio = 0.25  -> 1/4 safety anchors
    """

    def __init__(
        self,
        target_vision_tokens: int = 32,
        alpha: float = 0.5,
        anchor_ratio: float = 0.125,
    ):
        self.target_vision_tokens = int(
            target_vision_tokens
        )
        self.alpha = float(alpha)
        self.anchor_ratio = float(anchor_ratio)

        self._core = QwenAlgorithmCoreV18(
            mmtok_core=None
        )

    def mm_coverage_selection(
        self,
        text_token_embedding: torch.Tensor,
        vision_tokens: torch.Tensor,
        vision_tokens_clip: torch.Tensor,
        tv_temp: float = 0.01,
        vv_temp: float = 0.2,
        padding_patch_indices: Optional[List[int]] = None,
    ) -> Tuple[List[int], torch.Tensor]:
        selected_indices_tensor = (
            self._core.select_vision_tokens(
                image_embeds=vision_tokens,
                image_features=vision_tokens_clip,
                question="",
                target_vision_tokens=(
                    self.target_vision_tokens
                ),
                text_token_embedding=(
                    text_token_embedding
                ),
                anchor_ratio=self.anchor_ratio,
                alpha=self.alpha,
                tv_temp=tv_temp,
                vv_temp=vv_temp,
                padding_patch_indices=(
                    padding_patch_indices
                ),
            )
        )

        selected_indices = (
            selected_indices_tensor.tolist()
        )

        selected_tokens = vision_tokens.index_select(
            0,
            selected_indices_tensor,
        )

        return selected_indices, selected_tokens


# Backward-compatible aliases. Existing registries that import the old
# class names can use this file without further code changes.
QwenAlgorithmCoreV11 = QwenAlgorithmCoreV18
AutoResearchSelectorV170 = AutoResearchSelectorV180
