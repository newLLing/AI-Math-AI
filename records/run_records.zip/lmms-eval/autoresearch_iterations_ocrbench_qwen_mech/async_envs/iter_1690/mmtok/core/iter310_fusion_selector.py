# MMTok: Fusion vision token selector (from iter_310)
# Combines randomized low-rank PCA leverage scores + query relevance + pivoted QR.

from typing import Optional, List, Tuple

import torch
import torch.nn.functional as F


class Iter310FusionSelector:
    """
    Fusion vision token selector combining:
    1. Randomized low-rank PCA for approximate leverage scores.
    2. Query relevance via cosine similarity.
    3. Pivoted QR (volume-maximising) selection on top candidates.
    """

    def __init__(self, target_vision_tokens: int = 64):
        self.target_vision_tokens = target_vision_tokens

    def mm_coverage_selection(
        self,
        text_token_embedding: torch.Tensor,
        vision_tokens: torch.Tensor,
        vision_tokens_clip: torch.Tensor,
        tv_temp: float = 0.01,
        vv_temp: float = 0.2,
        padding_patch_indices: Optional[List[int]] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        device = vision_tokens.device
        N = vision_tokens.size(0)
        k = min(self.target_vision_tokens, N)

        if k <= 0:
            selected_indices = torch.empty(0, dtype=torch.long, device=device)
            selected_tokens = torch.empty(0, vision_tokens.size(1), device=device, dtype=vision_tokens.dtype)
            return selected_indices, selected_tokens
        elif k >= N or N == 0:
            selected_indices = torch.arange(N, device=device)
            return selected_indices, vision_tokens

        # 1. Compute question embedding q from text tokens
        if text_token_embedding is not None and text_token_embedding.numel() > 0:
            q_emb = text_token_embedding.mean(dim=0)
            q_emb = F.normalize(q_emb.float(), p=2, dim=0)
        else:
            q_emb = torch.ones(vision_tokens.size(1), device=device, dtype=torch.float32)
            q_emb = F.normalize(q_emb, p=2, dim=0)

        # 2. Query relevance (cosine similarity)
        image_embeds_norm = F.normalize(vision_tokens.float(), dim=-1)
        relevance = (image_embeds_norm * q_emb.unsqueeze(0)).sum(dim=-1)
        relevance = torch.clamp(relevance, min=0)

        # Choose feature matrix for leverage computation
        if vision_tokens_clip is not None and vision_tokens_clip.shape[1] > 0:
            X = vision_tokens_clip
        else:
            X = vision_tokens

        X = X.to(dtype=torch.float32, device=device)
        feature_dim = X.shape[1]

        # Handle padding exclusion
        excluded_mask = torch.zeros(N, dtype=torch.bool, device=device)
        if padding_patch_indices is not None and len(padding_patch_indices) > 0:
            excluded_mask[padding_patch_indices] = True

        # Edge case: near-zero features -> fallback to random
        row_norms = torch.norm(X, dim=1)
        if row_norms.max() < 1e-8:
            perm = torch.randperm(N, device=device)[:k]
            selected_indices = perm.to(dtype=torch.long)
            selected_tokens = vision_tokens[selected_indices]
            return selected_indices, selected_tokens

        # ===== FUSION: Randomized low-rank PCA for leverage scores =====
        r = min(k, min(N, feature_dim) - 1)
        if r < 1:
            r = 1

        proj_dim = max(feature_dim // 4, 64)
        torch.manual_seed(42)
        random_proj = torch.randn(feature_dim, proj_dim, device=device, dtype=torch.float32)
        random_proj = random_proj / torch.sqrt(torch.tensor(proj_dim, dtype=torch.float32, device=device))
        X_proj = X @ random_proj
        X_proj_center = X_proj - X_proj.mean(dim=0, keepdim=True)

        U_proj, S_proj, _ = torch.svd_lowrank(X_proj_center, q=r, niter=2)
        leverage_scores = torch.norm(U_proj, dim=1)

        # Combine with query relevance
        combined_score = leverage_scores * (relevance + 1e-6)

        # Apply padding exclusion so padding patches are never selected
        if padding_patch_indices is not None and len(padding_patch_indices) > 0:
            combined_score[padding_patch_indices] = -float("inf")

        # Keep top m = 2*k candidates
        m = min(N, max(int(2 * k), k))
        _, top_idx = torch.topk(combined_score, m)

        # Sub-space of top-m candidates
        U_sub = U_proj[top_idx]

        # Pivoted QR (volume-maximising) selection — vectorized inner loop
        def pivoted_qr_selection(pts, num_select, dev):
            m_s, r_s = pts.shape
            if num_select >= m_s:
                return torch.arange(m_s, device=dev)
            work = pts.to(torch.float32).clone()
            selected_mask = torch.zeros(m_s, dtype=torch.bool, device=dev)
            norms = torch.norm(work, dim=1)
            selected_list = []
            for i in range(num_select):
                norms_masked = norms.clone()
                norms_masked[selected_mask] = -float("inf")
                col = torch.argmax(norms_masked).item()
                selected_mask[col] = True
                selected_list.append(col)
                v = work[col]
                v_norm_sq = torch.dot(v, v)
                if v_norm_sq < 1e-12:
                    continue
                # Vectorized orthogonalization over ALL rows, then zero out already-selected rows
                projections = (work @ v) / v_norm_sq
                projections[selected_mask] = 0.0
                work -= projections.unsqueeze(1) * v
                norms = torch.norm(work, dim=1)
            return torch.tensor(selected_list, device=dev)

        sub_selected = pivoted_qr_selection(U_sub, k, device)
        selected_indices = top_idx[sub_selected].to(dtype=torch.long, device=device)
        # ===== END FUSION =====

        selected_indices = torch.sort(selected_indices).values
        selected_tokens = vision_tokens[selected_indices]
        return selected_indices, selected_tokens
