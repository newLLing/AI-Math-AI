
import torch
import torch.nn.functional as F
from typing import List, Optional, Tuple
import math

from loguru import logger as eval_logger
eval_logger.info("[MMTok] autoresearch_v33_c0_selector.py loaded")


class LLaVAAlgorithmCoreV11:
    """
    Algorithm core for Qwen2.5-VL vision token selection (v33).

    Separates the selection algorithm from the model's forward-pass plumbing,
    enabling safe AutoResearch experiments on the algorithm without risking
    the multimodal sequence post-processing logic.
    """

    def __init__(self, mmtok_core=None):
        self.mmtok_core = mmtok_core

    def select_vision_tokens(
        self,
        image_embeds: torch.Tensor,
        image_features: torch.Tensor,
        question: str = "",
        target_vision_tokens: int = None,
        image_grid_thw: torch.Tensor = None,
        text_token_embedding: torch.Tensor = None,
    ) -> torch.Tensor:
        # --- ALGORITHM CORE START ---
        N = image_features.shape[0]
        k = target_vision_tokens
        lambda_val = 0.1
        dtype = image_features.dtype
        device = image_features.device

        # Compute neighbour lists via grid
        if image_grid_thw is not None:
            if image_grid_thw.ndim == 1:
                image_grid_thw = image_grid_thw.unsqueeze(0)
            t, h, w = image_grid_thw[0].tolist()
            if t != 1 or h * w != N:
                # Fallback to factorisation if grid mismatch
                w = int(N ** 0.5)
                while N % w != 0:
                    w -= 1
                h = N // w
        else:
            # Fallback factorisation
            w = int(N ** 0.5)
            while N % w != 0:
                w -= 1
            h = N // w

        # neighbour indices
        neighbours = []
        for i in range(N):
            r = i // w
            c = i % w
            cand = []
            for dr in [-1, 0, 1]:
                for dc in [-1, 0, 1]:
                    if dr == 0 and dc == 0:
                        continue
                    nr, nc = r + dr, c + dc
                    if 0 <= nr < h and 0 <= nc < w:
                        cand.append(nr * w + nc)
            neighbours.append(torch.tensor(cand, dtype=torch.long, device=device))

        # Precompute local instability l_i using image_embeds (projected)
        E = image_embeds.to(torch.float32)
        l = torch.zeros(N, device=device, dtype=torch.float32)
        for i in range(N):
            nb = neighbours[i]
            if nb.numel() > 0:
                diff = E[i] - E[nb]
                l[i] = diff.pow(2).sum(dim=-1).mean()
        l = l.to(dtype)  # back to model dtype for score mixing

        # Orthogonal matching pursuit in image_features (CLIP space)
        F = image_features  # (N, d)
        F32 = F.to(torch.float32)
        Q = torch.empty(0, F.shape[1], device=device, dtype=dtype)  # (r, d) in model dtype for storage
        available = torch.ones(N, dtype=torch.bool, device=device)
        selected = []

        for _ in range(k):
            # Compute residuals in float32 for stability
            if Q.shape[0] == 0:
                residual = F32.pow(2).sum(dim=1)  # (N,)
            else:
                Q32 = Q.to(torch.float32)
                proj = F32 @ Q32.t()  # (N, r)
                residual = F32.pow(2).sum(dim=1) - proj.pow(2).sum(dim=1)

            score = residual - lambda_val * l.to(torch.float32)
            score[~available] = -float('inf')
            i_star = torch.argmax(score).item()
            selected.append(i_star)
            available[i_star] = False

            # Update Q with Gram-Schmidt in float32, then convert back to model dtype
            v = F[i_star]  # model dtype
            v_float = v.to(torch.float32)
            if Q.shape[0] == 0:
                q_new_float = v_float / v_float.norm()
            else:
                Q_float = Q.to(torch.float32)
                v_res = v_float - Q_float.t() @ (Q_float @ v_float)
                v_norm = v_res.norm()
                if v_norm < 1e-12:
                    v_res = v_res + torch.randn_like(v_res) * 1e-6
                    v_res = v_res / v_res.norm()
                else:
                    v_res = v_res / v_norm
                q_new_float = v_res
            q_new = q_new_float.to(dtype)
            Q = torch.cat([Q, q_new.unsqueeze(0)], dim=0)

        selected_indices = torch.tensor(selected, dtype=torch.long, device=device)
        selected_indices = torch.sort(selected_indices).values
        # --- ALGORITHM CORE END ---
        return selected_indices


    def select_vision_tokens_batch(
        self,
        image_embeds_list,
        image_features_list,
        questions,
        target_vision_tokens_list,
        image_grid_thw_list=None,
    ):
        selected_indices_list = []
        n = len(image_embeds_list)
        for i in range(n):
            emb = image_embeds_list[i]
            feat = image_features_list[i]
            q = questions[i] if i < len(questions) else questions[-1]
            tgt = (
                target_vision_tokens_list[i]
                if i < len(target_vision_tokens_list)
                else target_vision_tokens_list[-1]
            )
            grid = None
            if image_grid_thw_list is not None and i < len(image_grid_thw_list):
                grid = image_grid_thw_list[i]
            selected_indices = self.select_vision_tokens(
                emb, feat, q, target_vision_tokens=tgt, image_grid_thw=grid
            )
            selected_indices_list.append(selected_indices)
        return selected_indices_list


class AutoResearchSelectorV330:
    def __init__(self, target_vision_tokens: int = 32, alpha: float = 0.5):
        self.target_vision_tokens = target_vision_tokens
        self.alpha = alpha
        self._core = LLaVAAlgorithmCoreV11(mmtok_core=None)

    def mm_coverage_selection(
        self,
        text_token_embedding: torch.Tensor,
        vision_tokens: torch.Tensor,
        vision_tokens_clip: torch.Tensor,
        tv_temp: float = 0.01,
        vv_temp: float = 0.2,
        padding_patch_indices: Optional[List[int]] = None,
    ) -> Tuple[List[int], torch.Tensor]:
        selected_indices_tensor = self._core.select_vision_tokens(
            image_embeds=vision_tokens,
            image_features=vision_tokens_clip,
            question="",
            target_vision_tokens=self.target_vision_tokens,
            text_token_embedding=text_token_embedding,
        )
        selected_indices = selected_indices_tensor.tolist()
        if not isinstance(selected_indices, list):
            selected_indices = [selected_indices]
        selected_tokens = vision_tokens[selected_indices_tensor]
        return selected_indices, selected_tokens




