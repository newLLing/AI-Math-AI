# MMTok: Multimodal Coverage Maximization for Efficient Inference of VLMs
# Paper: https://arxiv.org/abs/2508.18264
# Copyright (c) 2025 Zoom Communications, Inc.
# Author: Anonymous
# Licensed under the Apache License, Version 2.0

"""
MMTok core: subset selection of vision tokens under the coverage criterion.

Formulates selection as maximum coverage: a subset of vision tokens is chosen
to cover text tokens (question/keywords) and the original vision token set
simultaneously. Uses mm_coverage_selection (JIT kernel + optional padding exclusion).
"""

import os

import torch
from loguru import logger as eval_logger

from .divprune_selector import DivPruneSelector
from .eigen_leverage_selector import EigenLeverageSelector
from .gauss_southwell_selector import GaussSouthwellSelector
from .gauss_southwell_v2_selector import GaussSouthwellV2Selector
from .gauss_southwell_v3_selector import GaussSouthwellV3Selector
from .geometry_fps_qr_selector import GeometryFPSQRSelector
from .graph_er_selector import GraphERSelector
from .iter310_fusion_selector import Iter310FusionSelector
from .iter310_fusion_denoised_selector import Iter310FusionDenoisedSelector
from .nahs_dls_selector import NAHSDLSSelector
from .sfl_ts_selector import SFLTSSelector
from .gram_schmidt_dpp_selector import GramSchmidtDPPSelector
from .iter317_fusion_selector import Iter317FusionSelector
from .iter450_gram_inv_selector import Iter450GramInvSelector
from .pca_leverage_selector import PCALeverageSelector
from .qr_rank_gs_selector import QRRankGSSelector
from .rank_svd_gs_selector import RankSVDGSSelector
from .semantic_selector import SemanticTokenSelector
from .semantic_selector_eager import SemanticTokenSelectorEager
from .std_weighted_selector import StdWeightedSelector
from .svd_leverage_selector import SVDLeverageSelector
from .text_processor import VQATextProcessor
from .autoresearch_selector import AutoResearchSelector
from .autoresearch_selector_llava_wrapper import AutoResearchSelectorLLaVA
from .autoresearch_v17_c0_selector import AutoResearchSelectorV170
from .autoresearch_v18_c0_selector import AutoResearchSelectorV180
from .qwen_maha_spatial_selector import QwenMahaSpatialSelector
from .qwen_morse_density_selector import QwenMorseDensitySelector
from .qwen_sr_dpp_selector import QwenSRDPPSelector
from .qwen_rp_dpp_selector import QwenRPDPPSelector
from .autoresearch_v33_c0_selector import AutoResearchSelectorV330
from .autoresearch_v35_c0_selector import AutoResearchSelectorV350
from .autoresearch_v38_c0_selector import AutoResearchSelectorV380
from .gots_selector import GOTSSelector
from .gots_jit_selector import GOTSSelectorJIT
from .gots_optimized import GOTSSelectorOptimized
from .autoresearch_v28_c0_selector import AutoResearchSelectorV280
from .autoresearch_v28_c0_ablation_selector import (
    AutoResearchSelectorV28NoOrthogonal,
    AutoResearchSelectorV28NoSpatial,
)
try:
    from transformers import (AutoModelForImageTextToText, AutoProcessor,
                              AutoTokenizer)
except ImportError:
    eval_logger.error("Install transformers: pip install transformers")
    raise


class MMTokCore:
    """
    MMTok core: coverage-based subset selection of vision tokens.

    Uses both vision and text (question/keywords) to select informative
    vision tokens; mm_coverage_selection solves the maximum coverage formulation.
    """

    def __init__(
        self,
        target_vision_tokens=64,
        alpha=0.5,
        softmax_tv_temperature=0.02,
        softmax_vv_temperature=0.2,
        device="cuda",
        remove_padding_indices=False,
        selector_type="coverage",
        **kwargs,
    ):
        self.device = device
        self.target_vision_tokens = target_vision_tokens
        self.alpha = alpha
        self.softmax_tv_temperature = softmax_tv_temperature
        self.softmax_vv_temperature = softmax_vv_temperature
        self.remove_padding_indices = remove_padding_indices
        self.selector_type = selector_type
        self.extra_kwargs = kwargs
        self._init_processors()
        eval_logger.info(
            f"[MMTok] target_vision_tokens={self.target_vision_tokens}, selector_type={self.selector_type}"
        )


    def _init_processors(self):
        """Initialize token selector and text processor."""
        if self.selector_type == "svd_leverage":
            self.token_selector = SVDLeverageSelector(
                target_vision_tokens=self.target_vision_tokens,
            )
        elif self.selector_type == "autoresearch":
            self.token_selector = AutoResearchSelector(
                target_vision_tokens=self.target_vision_tokens,
            )
        elif self.selector_type == "autoresearch_llava":
            self.token_selector = AutoResearchSelectorLLaVA(
                target_vision_tokens=self.target_vision_tokens,
            )

        elif self.selector_type == "pca_leverage":
            self.token_selector = PCALeverageSelector(
                target_vision_tokens=self.target_vision_tokens,
            )
        elif self.selector_type == "nahs_dls":
            self.token_selector = NAHSDLSSelector(
                target_vision_tokens=self.target_vision_tokens,
                alpha_0=self.extra_kwargs.get("alpha_0", 0.6),
            )
        elif self.selector_type == "sfl_ts":
            self.token_selector = SFLTSSelector(
                target_vision_tokens=self.target_vision_tokens,
            )
        elif self.selector_type == "gram_schmidt_dpp":
            self.token_selector = GramSchmidtDPPSelector(
                target_vision_tokens=self.target_vision_tokens,
            )
        elif self.selector_type == "iter317_fusion":
            self.token_selector = Iter317FusionSelector(
                target_vision_tokens=self.target_vision_tokens,
                use_random_proj=self.extra_kwargs.get("use_random_proj", True),
                proj_dim=self.extra_kwargs.get("proj_dim", None),
                svd_rank_ratio=self.extra_kwargs.get("svd_rank_ratio", 0.2),
                svd_oversampling=self.extra_kwargs.get("svd_oversampling", 5),
                power_iterations=self.extra_kwargs.get("power_iterations", 1),
                leverage_weight=self.extra_kwargs.get("leverage_weight", 0.3),
                alpha=self.extra_kwargs.get("alpha", 0.3),
            )
        elif self.selector_type == "iter450_gram_inv":
            self.token_selector = Iter450GramInvSelector(
                target_vision_tokens=self.target_vision_tokens,
            )
        elif self.selector_type == "iter450_gram_inv_v2":
            self.token_selector = Iter450GramInvSelector(
                target_vision_tokens=self.target_vision_tokens,
                sort_indices=False,
            )
        elif self.selector_type == "gauss_southwell":
            self.token_selector = GaussSouthwellSelector(
                target_vision_tokens=self.target_vision_tokens,
            )
        elif self.selector_type == "gauss_southwell_v2":
            self.token_selector = GaussSouthwellV2Selector(
                target_vision_tokens=self.target_vision_tokens,
            )
        elif self.selector_type == "gauss_southwell_v3":
            self.token_selector = GaussSouthwellV3Selector(
                target_vision_tokens=self.target_vision_tokens,
            )
        elif self.selector_type == "iter310_fusion":
            self.token_selector = Iter310FusionSelector(
                target_vision_tokens=self.target_vision_tokens,
            )
        elif self.selector_type == "iter310_fusion_denoised":
            self.token_selector = Iter310FusionDenoisedSelector(
                target_vision_tokens=self.target_vision_tokens,
            )
        elif self.selector_type == "std_weighted":
            self.token_selector = StdWeightedSelector(
                target_vision_tokens=self.target_vision_tokens,
            )
        elif self.selector_type == "rank_svd_gs":
            self.token_selector = RankSVDGSSelector(
                target_vision_tokens=self.target_vision_tokens,
            )
        elif self.selector_type == "geometry_fps_qr":
            self.token_selector = GeometryFPSQRSelector(
                target_vision_tokens=self.target_vision_tokens,
            )
        elif self.selector_type == "qr_rank_gs":
            self.token_selector = QRRankGSSelector(
                target_vision_tokens=self.target_vision_tokens,
            )
        elif self.selector_type == "eigen_leverage":
            self.token_selector = EigenLeverageSelector(
                target_vision_tokens=self.target_vision_tokens,
            )
        elif self.selector_type == "graph_er":
            self.token_selector = GraphERSelector(
                target_vision_tokens=self.target_vision_tokens,
            )
        elif self.selector_type == "divprune":
            self.token_selector = DivPruneSelector(
                target_vision_tokens=self.target_vision_tokens,
            )
        elif self.selector_type == "coverage":
            self.token_selector = SemanticTokenSelector(
                target_vision_tokens=self.target_vision_tokens,
                alpha=self.alpha,
            )
        elif self.selector_type == "semantic_eager":
            self.token_selector = SemanticTokenSelectorEager(
                target_vision_tokens=self.target_vision_tokens,
                alpha=self.alpha,
            )
            eval_logger.info(f"[MMTok] Using SemanticTokenSelectorEager (semantic_selector_eager)")
        elif self.selector_type == "autoresearch_v17_c0":
            self.token_selector = AutoResearchSelectorV170(
                target_vision_tokens=self.target_vision_tokens,
            )
            eval_logger.info(f"[MMTok] Using AutoResearchSelectorV170 (autoresearch_v17_c0_selector)")
        elif self.selector_type == "autoresearch_v28_c0":
            self.token_selector = AutoResearchSelectorV280(
                target_vision_tokens=self.target_vision_tokens,
            )
            eval_logger.info(f"[MMTok] Using AutoResearchSelectorV280 (autoresearch_v28_c0_selector)")
        elif self.selector_type == "autoresearch_v28_c0_no_spatial":
            self.token_selector = AutoResearchSelectorV28NoSpatial(
                target_vision_tokens=self.target_vision_tokens,
            )
            eval_logger.info(f"[MMTok] Using AutoResearchSelectorV28NoSpatial (autoresearch_v28_c0_ablation_selector)")
        elif self.selector_type == "autoresearch_v28_c0_no_orthogonal":
            self.token_selector = AutoResearchSelectorV28NoOrthogonal(
                target_vision_tokens=self.target_vision_tokens,
            )
            eval_logger.info(f"[MMTok] Using AutoResearchSelectorV28NoOrthogonal (autoresearch_v28_c0_ablation_selector)")
        elif self.selector_type == "autoresearch_v18_c0":
            self.token_selector = AutoResearchSelectorV180(
                target_vision_tokens=self.target_vision_tokens,
            )
            eval_logger.info(f"[MMTok] Using AutoResearchSelectorV180 (autoresearch_v18_c0_selector)")
        elif self.selector_type == "qwen_maha_spatial":
            self.token_selector = QwenMahaSpatialSelector(
                target_vision_tokens=self.target_vision_tokens,
            )
            eval_logger.info(f"[MMTok] Using QwenMahaSpatialSelector (qwen_maha_spatial_selector)")
        elif self.selector_type == "qwen_morse_density":
            self.token_selector = QwenMorseDensitySelector(
                target_vision_tokens=self.target_vision_tokens,
            )
            eval_logger.info(f"[MMTok] Using QwenMorseDensitySelector (qwen_morse_density_selector)")
        elif self.selector_type == "qwen_sr_dpp":
            self.token_selector = QwenSRDPPSelector(
                target_vision_tokens=self.target_vision_tokens,
            )
            eval_logger.info(f"[MMTok] Using QwenSRDPPSelector (qwen_sr_dpp_selector)")
        elif self.selector_type == "qwen_rp_dpp":
            self.token_selector = QwenRPDPPSelector(
                target_vision_tokens=self.target_vision_tokens,
            )
            eval_logger.info(f"[MMTok] Using QwenRPDPPSelector (qwen_rp_dpp_selector)")
        elif self.selector_type == "autoresearch_v33_c0":
            self.token_selector = AutoResearchSelectorV330(
                target_vision_tokens=self.target_vision_tokens,
            )
            eval_logger.info(f"[MMTok] Using AutoResearchSelectorV330 (autoresearch_v33_c0_selector)")
        elif self.selector_type == "autoresearch_v35_c0":
            self.token_selector = AutoResearchSelectorV350(
                target_vision_tokens=self.target_vision_tokens,
            )
            eval_logger.info(f"[MMTok] Using AutoResearchSelectorV350 (autoresearch_v35_c0_selector)")
        elif self.selector_type == "autoresearch_v38_c0":
            self.token_selector = AutoResearchSelectorV380(
                target_vision_tokens=self.target_vision_tokens,
            )
            eval_logger.info(f"[MMTok] Using AutoResearchSelectorV380 (autoresearch_v38_c0_selector)")
        elif self.selector_type == "gots":
            self.token_selector = GOTSSelector(
                target_vision_tokens=self.target_vision_tokens,
            )
            eval_logger.info(f"[MMTok] Using GOTSSelector (gots_selector)")
        elif self.selector_type == "gots_jit":
            self.token_selector = GOTSSelectorJIT(
                target_vision_tokens=self.target_vision_tokens,
            )
            eval_logger.info(f"[MMTok] Using GOTSSelectorJIT (gots_jit_selector)")
        elif self.selector_type == "gots_optimized":
            self.token_selector = GOTSSelectorOptimized(
                target_vision_tokens=self.target_vision_tokens,
            )
            eval_logger.info(f"[MMTok] Using GOTSSelectorOptimized (gots_optimized)")
        else:
            raise ValueError(f"Unknown selector_type: {self.selector_type}")
        self.text_processor = VQATextProcessor(device=self.device)


    def _encode_text_with_token_pooling(self, text: str):
        """
        Encode text (question/keywords) into text token embeddings for coverage.
        Uses LLaVA embed_tokens; batch size must be 1. No BOS.
        """
        words = text.split()
        if getattr(self._language_tokenizer, "is_fast", False):
            enc = self._language_tokenizer(
                words, is_split_into_words=True, return_tensors="pt", padding=True, truncation=True
            )
        else:
            # Slow tokenizers do not support `is_split_into_words`; pass the raw text
            # to avoid "Keyword arguments {'is_split_into_words': True} not recognized."
            enc = self._language_tokenizer(
                text, return_tensors="pt", padding=True, truncation=True
            )
        input_ids = enc["input_ids"].to(self.device)  # [1, T]
        with torch.no_grad():
            tok_emb = self._main_model_embed_tokens(input_ids)[0]  # [T, D]
        start_idx = 0
        if input_ids.shape[1] > 1 and input_ids[0, 0].item() == self._language_tokenizer.bos_token_id:
            start_idx = 1
        return tok_emb[start_idx:]  # [num_words, hidden_dim]

    def apply_selection(self, mm_projector_features, clip_features, images, question_text, text_embeds=None, padding_patch_indices=None):
        """
        Apply coverage-based subset selection: select vision tokens that cover
        text tokens (question) and the vision token set (multimodal coverage).

        Args:
            mm_projector_features: [batch_size, num_tokens, hidden_dim] (output space)
            clip_features: [batch_size, num_tokens, hidden_dim] (for similarity; CLS stripped if present)
            images: Input images
            question_text: Question string (used to obtain text token embedding)

        Returns:
            selected_features: Selected subset of mm_projector features
            selected_indices: Indices of selected vision tokens
        """
        vision_feat = mm_projector_features
        vision_feat_clip = clip_features
        if vision_feat_clip is not None and vision_feat_clip.shape[1] - vision_feat.shape[1] == 1:
            vision_feat_clip = vision_feat_clip[:, 1:, :]

        text_for_coverage = self.text_processor.extract_keywords_simple(question_text)
        text_token_embedding = self._encode_text_with_token_pooling(text_for_coverage)

        selected_features, selected_indices = self.select_vision_tokens(
            vision_features=vision_feat,
            vision_features_clip=vision_feat_clip,
            text_token_embedding=text_token_embedding,
            padding_patch_indices_list=padding_patch_indices,
        )
        return selected_features, selected_indices

    def select_vision_tokens(
        self,
        vision_features: torch.Tensor,
        vision_features_clip: torch.Tensor,
        text_token_embedding: torch.Tensor,
        padding_patch_indices_list: list = None,
    ) -> torch.Tensor:
        """
        Subset selection under maximum coverage: greedy selection of vision tokens
        to cover text tokens (question) and the vision token set.

        Args:
            vision_features: [batch_size, num_tokens, hidden_dim] (mm_projector output, used as selected features)
            vision_features_clip: [batch_size, num_tokens, hidden_dim] (CLIP space for vision–vision coverage/diversity)
            text_token_embedding: Text token embedding (question/keywords) for text–vision coverage
            padding_patch_indices_list: Optional per-image padding patch indices to exclude from selection

        Returns:
            selected_tokens_batch: [batch_size, target_vision_tokens, hidden_dim] selected subset
            selected_indices_list: Per-batch selected indices
        """
        if vision_features.dim() == 2:
            vision_features = vision_features.unsqueeze(0)
        if vision_features_clip.dim() == 2:
            vision_features_clip = vision_features_clip.unsqueeze(0)
        batch_size, num_tokens, hidden_dim = vision_features.shape

        if num_tokens <= self.target_vision_tokens:
            return vision_features, [torch.arange(num_tokens, device=vision_features.device) for _ in range(batch_size)]

        selected_tokens_list = []
        selected_indices_list = []

        for batch_idx in range(batch_size):
            vision_tokens = vision_features[batch_idx]
            vision_tokens_clip = vision_features_clip[batch_idx]
            if padding_patch_indices_list is not None and len(padding_patch_indices_list) > 0:
                padding_patch_indices = padding_patch_indices_list[batch_idx]
            else:
                padding_patch_indices = None

            selected_indices, selected_tokens = self.token_selector.mm_coverage_selection(
                text_token_embedding=text_token_embedding,
                vision_tokens=vision_tokens,
                vision_tokens_clip=vision_tokens_clip,
                tv_temp=self.softmax_tv_temperature,
                vv_temp=self.softmax_vv_temperature,
                padding_patch_indices=padding_patch_indices,
            )
            selected_tokens_list.append(selected_tokens)
            selected_indices_list.append(selected_indices)

        selected_tokens_batch = torch.stack(selected_tokens_list, dim=0)

        return selected_tokens_batch, selected_indices_list

    def apply_selection_preprocess_qwen(self, image_embeds, image_features, question_text, target_vision_tokens=None, image_grid_thw=None):
        """
        Coverage-based subset selection for Qwen2.5-VL: select vision tokens
        to cover text (question only, or question+answer if provided) and vision set. Single-sample path.

        Args:
            image_embeds: [num_image_tokens, hidden_dim] mm_projector output
            image_features: CLIP features for vision–vision coverage
            question_text: Question string
            answer_text: Optional answer text (for compatibility; when no scout, use question only)
            target_vision_tokens: Target subset size (uses self.token_selector.target_vision_tokens if None)
            image_grid_thw: [num_images, 3] grid shape (temporal, height, width) for each image (optional)

        Returns:
            selected_indices: Indices of selected vision tokens
            selected_features: Selected subset of image features (single sample)
        """
        if target_vision_tokens is not None:
            self.token_selector.target_vision_tokens = target_vision_tokens
            self.target_vision_tokens = target_vision_tokens

        text_for_embedding = f"Question: {question_text}"
        if getattr(self, "clean_text", False):
            text_for_embedding = self.text_processor.extract_keywords_simple(text_for_embedding)

        text_token_embedding = self._encode_text_with_token_pooling(text_for_embedding)
        selected_features, selected_indices = self.select_vision_tokens(
            vision_features=image_embeds,
            vision_features_clip=image_features,
            text_token_embedding=text_token_embedding,
        )
        # selected_indices is a list of tensors, extract the first one
        selected_indices_item = selected_indices[0] if isinstance(selected_indices, list) else selected_indices
        selected_features_item = selected_features[0]
        return selected_indices_item, selected_features_item
