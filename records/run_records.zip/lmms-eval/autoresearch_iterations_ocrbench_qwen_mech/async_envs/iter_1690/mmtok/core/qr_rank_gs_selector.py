# MMTok: Multimodal Coverage Maximization for Efficient Inference of VLMs
# Paper: https://arxiv.org/abs/2508.18264
# Copyright (c) 2025 Zoom Communications, Inc.
# Licensed under the Apache License, Version 2.0

"""
QR-Rank-GS vision token selector (iter_280).

Core operators:
1. Rank-weighted relevance: emphasis on top-ranked tokens.
2. QR leverage scores: spectral importance computed via torch.linalg.qr
   (stable replacement for SVD, using the Q matrix row norms).
3. Gauss-Southwell greedy selection with cosine-diversity penalty.
"""

from typing import List, Optional, Tuple

import torch
import torch.nn.functional as F


class QRRankGSSelector:
    """
    QR leverage + rank-weighted relevance + Gauss-Southwell selector.
    """

    def __init__(self, target_vision_tokens: int = 64):
        self.target_vision_tokens = target_vision_tokens

    def mm_coverage_selection(
        self,
        text_token_embedding: torch.Tensor,
        vision_tokens: torch.Tensor,
        vision_tokens_clip: torch.Tensor,
        tv_temp: float = 0.01,
        vv_temp: float = 0.2,
        padding_patch_indices: Optional[List[int]] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        device = vision_tokens.device
        N = vision_tokens.size(0)
        k = min(self.target_vision_tokens, N)

        if k <= 0:
            selected_indices = torch.empty(0, dtype=torch.long, device=device)
            selected_tokens = torch.empty(
                0, vision_tokens.size(1), device=device, dtype=vision_tokens.dtype
            )
            return selected_indices, selected_tokens
        elif k >= N or N == 0:
            selected_indices = torch.arange(N, device=device)
            return selected_indices, vision_tokens

        # 1. Query embedding & relevance
        if text_token_embedding is not None and text_token_embedding.numel() > 0:
            q_emb = text_token_embedding.mean(dim=0)
        else:
            q_emb = vision_tokens.mean(dim=0)

        X_norm = F.normalize(vision_tokens.float(), p=2, dim=1)
        q = F.normalize(q_emb.float(), p=2, dim=0)
        r_raw = torch.matmul(X_norm, q)

        # Rank-weighted relevance
        ranks = torch.argsort(torch.argsort(r_raw, descending=True))
        weight = (float(N) - ranks.float()) / float(N)
        r_weighted = r_raw * weight

        # 2. Spectral importance via QR leverage scores
        X_f32 = X_norm.detach().to(torch.float32)
        try:
            Q_mat, _ = torch.linalg.qr(X_f32, mode='reduced')
            leverage = torch.sum(Q_mat ** 2, dim=1)
        except RuntimeError:
            X_pert = X_f32 + 1e-8 * torch.randn_like(X_f32)
            Q_mat, _ = torch.linalg.qr(X_pert.to(torch.float32), mode='reduced')
            leverage = torch.sum(Q_mat ** 2, dim=1)

        if leverage.max() > 1e-8:
            s_norm = leverage / leverage.max()
        else:
            s_norm = leverage.clone()

        # Scale spectral scores to match r_weighted magnitude
        mean_r = r_weighted.mean()
        mean_s = s_norm.mean().to(r_weighted.dtype) + 1e-8
        s_scaled = s_norm.to(r_weighted.dtype) * (mean_r / mean_s)

        # 3. Fused score
        alpha = 0.5
        r = (1.0 - alpha) * r_weighted + alpha * s_scaled

        # Exclude padding patches
        if padding_patch_indices is not None and len(padding_patch_indices) > 0:
            exclude_mask = torch.zeros(N, dtype=torch.bool, device=device)
            exclude_mask[padding_patch_indices] = True
            r[exclude_mask] = float("-inf")

        # 4. Gauss-Southwell greedy selection
        lambda_ = 0.5
        selected_mask = torch.zeros(N, dtype=torch.bool, device=device)
        d = vision_tokens.shape[1]
        M = torch.zeros(d, device=device, dtype=vision_tokens.dtype)

        if r.max() - r.min() < 1e-8:
            first_idx = torch.argmax(torch.norm(vision_tokens, dim=1))
        else:
            first_idx = torch.argmax(r)

        selected_mask[first_idx] = True
        selected_indices_list = [first_idx.item()]
        M = M + X_norm[first_idx]

        for step in range(1, k):
            M_mean = M / step
            scores = r - lambda_ * torch.matmul(X_norm, M_mean)
            scores[selected_mask] = float("-inf")
            j = torch.argmax(scores)
            selected_mask[j] = True
            selected_indices_list.append(j.item())
            M = M + X_norm[j]

        selected_indices = torch.tensor(selected_indices_list, dtype=torch.long, device=device)
        selected_indices = torch.sort(selected_indices).values
        selected_tokens = vision_tokens[selected_indices]
        return selected_indices, selected_tokens
