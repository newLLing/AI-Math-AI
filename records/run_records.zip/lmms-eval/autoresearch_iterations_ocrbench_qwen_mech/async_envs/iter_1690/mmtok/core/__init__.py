# MMTok: Multimodal Coverage Maximization for Efficient Inference of VLMs
# Paper: https://arxiv.org/abs/2508.18264
# Copyright (c) 2025 Zoom Communications, Inc.
# Author: Anonymous
# Licensed under the Apache License, Version 2.0

"""
MMTok core: coverage-based subset selection, token selector, and text processing.
"""

from .divprune_selector import DivPruneSelector
from .eigen_leverage_selector import EigenLeverageSelector
from .gauss_southwell_selector import GaussSouthwellSelector
from .gauss_southwell_v2_selector import GaussSouthwellV2Selector
from .gauss_southwell_v3_selector import GaussSouthwellV3Selector
from .geometry_fps_qr_selector import GeometryFPSQRSelector
from .graph_er_selector import GraphERSelector
from .mmtok_core import MMTokCore
from .nahs_dls_selector import NAHSDLSSelector
from .sfl_ts_selector import SFLTSSelector
from .gram_schmidt_dpp_selector import GramSchmidtDPPSelector
from .iter317_fusion_selector import Iter317FusionSelector
from .iter450_gram_inv_selector import Iter450GramInvSelector
from .pca_leverage_selector import PCALeverageSelector
from .qr_rank_gs_selector import QRRankGSSelector
from .rank_svd_gs_selector import RankSVDGSSelector
from .svd_leverage_selector import SVDLeverageSelector
from .text_processor import VQATextProcessor
from .autoresearch_selector import AutoResearchSelector
from .autoresearch_selector_llava_wrapper import AutoResearchSelectorLLaVA
from .qwen_custom_selector import QwenCustomSelector
from .semantic_selector import SemanticTokenSelector, greedy_merged_jit_kernel
from .autoresearch_v17_c0_selector import AutoResearchSelectorV170
from .autoresearch_v18_c0_selector import AutoResearchSelectorV180
from .qwen_maha_spatial_selector import QwenMahaSpatialAlgorithmCore, QwenMahaSpatialSelector
from .qwen_morse_density_selector import QwenMorseDensityAlgorithmCore, QwenMorseDensitySelector
from .qwen_sr_dpp_selector import QwenSRDPPAlgorithmCore, QwenSRDPPSelector
from .qwen_rp_dpp_selector import QwenRPDPPAlgorithmCore, QwenRPDPPSelector
from .autoresearch_v33_c0_selector import AutoResearchSelectorV330
from .autoresearch_v35_c0_selector import AutoResearchSelectorV350
from .autoresearch_v38_c0_selector import AutoResearchSelectorV380
from .gots_optimized import GOTSSelectorOptimized
from .autoresearch_v28_c0_selector import AutoResearchSelectorV280
from .autoresearch_v28_c0_ablation_selector import (
    AutoResearchSelectorV28NoOrthogonal,
    AutoResearchSelectorV28NoSpatial,
)
__all__ = ["DivPruneSelector", "EigenLeverageSelector", "GaussSouthwellSelector", "GaussSouthwellV2Selector", "GaussSouthwellV3Selector",
           "GeometryFPSQRSelector", "GraphERSelector", "MMTokCore", "NAHSDLSSelector", "PCALeverageSelector",
           "QRRankGSSelector", "RankSVDGSSelector", "SFLTSSelector", "GramSchmidtDPPSelector",
           "Iter317FusionSelector", "Iter450GramInvSelector", "SVDLeverageSelector", "VQATextProcessor",
           "SemanticTokenSelector", "greedy_merged_jit_kernel", "AutoResearchSelector",
           "AutoResearchSelectorLLaVA", "QwenCustomSelector", "QwenMahaSpatialAlgorithmCore",
           "QwenMahaSpatialSelector", "QwenMorseDensityAlgorithmCore", "QwenMorseDensitySelector",
           "QwenSRDPPAlgorithmCore", "QwenSRDPPSelector",
           "QwenRPDPPAlgorithmCore", "QwenRPDPPSelector",
           "AutoResearchSelectorV28NoSpatial", "AutoResearchSelectorV28NoOrthogonal",
           "AutoResearchSelectorV350", "AutoResearchSelectorV380",
           "GOTSSelectorOptimized"]
