# MMTok: Fusion vision token selector with spatial denoising (from iter_310)
# Two-stage design: 2x2 spatial pooling for coarse candidate filtering,
# then pivoted QR on original features for fine selection.

from typing import Optional, List, Tuple

import torch
import torch.nn.functional as F


class Iter310FusionDenoisedSelector:
    """
    Fusion vision token selector with spatial denoising for LLaVA.
    Stage 1: pool 24x24 patch grid to 12x12 super-patches, compute leverage on
             denoised features to select promising 2x2 blocks.
    Stage 2: expand selected blocks back to original tokens and run pivoted QR.
    """

    def __init__(self, target_vision_tokens: int = 64):
        self.target_vision_tokens = target_vision_tokens

    def mm_coverage_selection(
        self,
        text_token_embedding: torch.Tensor,
        vision_tokens: torch.Tensor,
        vision_tokens_clip: torch.Tensor,
        tv_temp: float = 0.01,
        vv_temp: float = 0.2,
        padding_patch_indices: Optional[List[int]] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        device = vision_tokens.device
        N = vision_tokens.size(0)
        k = min(self.target_vision_tokens, N)

        if k <= 0:
            selected_indices = torch.empty(0, dtype=torch.long, device=device)
            selected_tokens = torch.empty(0, vision_tokens.size(1), device=device, dtype=vision_tokens.dtype)
            return selected_indices, selected_tokens
        elif k >= N or N == 0:
            selected_indices = torch.arange(N, device=device)
            return selected_indices, vision_tokens

        # 1. Compute question embedding q from text tokens
        if text_token_embedding is not None and text_token_embedding.numel() > 0:
            q_emb = text_token_embedding.mean(dim=0)
            q_emb = F.normalize(q_emb.float(), p=2, dim=0)
        else:
            q_emb = torch.ones(vision_tokens.size(1), device=device, dtype=torch.float32)
            q_emb = F.normalize(q_emb, p=2, dim=0)

        # 2. Query relevance (cosine similarity) on ORIGINAL tokens
        image_embeds_norm = F.normalize(vision_tokens.float(), dim=-1)
        relevance = (image_embeds_norm * q_emb.unsqueeze(0)).sum(dim=-1)
        relevance = torch.clamp(relevance, min=0)

        # Choose feature matrix for leverage computation
        if vision_tokens_clip is not None and vision_tokens_clip.shape[1] > 0:
            X_orig = vision_tokens_clip
        else:
            X_orig = vision_tokens

        X_orig = X_orig.to(dtype=torch.float32, device=device)
        feature_dim = X_orig.shape[1]

        # Edge case: near-zero features -> fallback to random
        row_norms = torch.norm(X_orig, dim=1)
        if row_norms.max() < 1e-8:
            perm = torch.randperm(N, device=device)[:k]
            selected_indices = perm.to(dtype=torch.long)
            selected_tokens = vision_tokens[selected_indices]
            return selected_indices, selected_tokens

        # Check if we can use spatial pooling (N must be a perfect square, e.g. 24x24=576)
        H = int(N ** 0.5)
        use_spatial_pooling = (H * H == N)

        if use_spatial_pooling:
            W = H
            # ---- Stage 1: Spatial denoising via 2x2 average pooling ----
            x_spatial = X_orig.reshape(H, W, feature_dim).permute(2, 0, 1).unsqueeze(0)  # [1, D, H, W]
            x_pooled = F.avg_pool2d(x_spatial, kernel_size=2, stride=2)  # [1, D, H//2, W//2]
            X_pooled = x_pooled.squeeze(0).permute(1, 2, 0).reshape(-1, feature_dim)  # [N_pooled, D]
            N_pooled = X_pooled.shape[0]  # 144 for H=W=24

            # Pool relevance to super-patch level
            rel_spatial = relevance.reshape(1, 1, H, W)
            rel_pooled = F.avg_pool2d(rel_spatial, kernel_size=2, stride=2).reshape(-1)  # [N_pooled]

            # ---- Leverage score on POOLED (denoised) features ----
            r = min(k, min(N_pooled, feature_dim) - 1)
            if r < 1:
                r = 1
            proj_dim = max(feature_dim // 4, 64)
            torch.manual_seed(42)
            random_proj = torch.randn(feature_dim, proj_dim, device=device, dtype=torch.float32)
            random_proj = random_proj / torch.sqrt(torch.tensor(proj_dim, dtype=torch.float32, device=device))
            X_proj = X_pooled @ random_proj
            X_proj_center = X_proj - X_proj.mean(dim=0, keepdim=True)
            U_proj_pooled, _, _ = torch.svd_lowrank(X_proj_center, q=r, niter=2)
            leverage_scores_pooled = torch.norm(U_proj_pooled, dim=1)  # [N_pooled]

            # Combined score on POOLED space
            combined_score_pooled = leverage_scores_pooled * (rel_pooled + 1e-6)

            # Exclude padding at pooled level
            if padding_patch_indices is not None and len(padding_patch_indices) > 0:
                padding_mask = torch.zeros(N, dtype=torch.bool, device=device)
                padding_mask[padding_patch_indices] = True
                padding_mask_spatial = padding_mask.reshape(H, W).float().unsqueeze(0).unsqueeze(0)  # [1,1,H,W]
                padding_pooled = (F.max_pool2d(padding_mask_spatial, kernel_size=2, stride=2).squeeze() > 0).reshape(-1)
                combined_score_pooled[padding_pooled] = -float("inf")

            # Select top 2k POOLED super-patches
            m_pooled = min(N_pooled, max(int(2 * k), k))
            _, top_pooled_idx = torch.topk(combined_score_pooled, m_pooled)

            # ---- Stage 2: Expand to ORIGINAL candidate indices ----
            candidate_indices = []
            for p_idx in top_pooled_idx:
                i = (p_idx // (W // 2)).item()
                j = (p_idx % (W // 2)).item()
                for dh in range(2):
                    for dw in range(2):
                        orig_idx = (2 * i + dh) * W + (2 * j + dw)
                        if orig_idx < N:
                            candidate_indices.append(orig_idx)
            candidate_indices = torch.tensor(candidate_indices, device=device, dtype=torch.long)

            # Deduplicate
            candidate_indices = torch.unique(candidate_indices)

            # Filter padding from candidates
            pad_mask = None
            if padding_patch_indices is not None and len(padding_patch_indices) > 0:
                pad_mask = torch.zeros(N, dtype=torch.bool, device=device)
                pad_mask[padding_patch_indices] = True
                candidate_indices = candidate_indices[~pad_mask[candidate_indices]]

            # Fallback if too few candidates
            if candidate_indices.numel() < k:
                all_valid = torch.arange(N, device=device)
                if padding_patch_indices is not None and len(padding_patch_indices) > 0:
                    all_valid = all_valid[~pad_mask[all_valid]]
                candidate_indices = all_valid

            # Pivoted QR on ORIGINAL features of candidates
            U_candidates = X_orig[candidate_indices]
        else:
            # Fallback: original non-spatial path (same as iter310_fusion)
            r = min(k, min(N, feature_dim) - 1)
            if r < 1:
                r = 1
            proj_dim = max(feature_dim // 4, 64)
            torch.manual_seed(42)
            random_proj = torch.randn(feature_dim, proj_dim, device=device, dtype=torch.float32)
            random_proj = random_proj / torch.sqrt(torch.tensor(proj_dim, dtype=torch.float32, device=device))
            X_proj = X_orig @ random_proj
            X_proj_center = X_proj - X_proj.mean(dim=0, keepdim=True)
            U_proj, _, _ = torch.svd_lowrank(X_proj_center, q=r, niter=2)
            leverage_scores = torch.norm(U_proj, dim=1)

            combined_score = leverage_scores * (relevance + 1e-6)
            if padding_patch_indices is not None and len(padding_patch_indices) > 0:
                combined_score[padding_patch_indices] = -float("inf")

            m = min(N, max(int(2 * k), k))
            _, top_idx = torch.topk(combined_score, m)
            U_candidates = U_proj[top_idx]
            candidate_indices = top_idx  # In fallback, candidates are just top_idx

        # ---- Pivoted QR (vectorized inner loop) ----
        def pivoted_qr_selection(pts, num_select, dev):
            m_s, r_s = pts.shape
            if num_select >= m_s:
                return torch.arange(m_s, device=dev)
            work = pts.to(torch.float32).clone()
            selected_mask = torch.zeros(m_s, dtype=torch.bool, device=dev)
            norms = torch.norm(work, dim=1)
            selected_list = []
            for i in range(num_select):
                norms_masked = norms.clone()
                norms_masked[selected_mask] = -float("inf")
                col = torch.argmax(norms_masked).item()
                selected_mask[col] = True
                selected_list.append(col)
                v = work[col]
                v_norm_sq = torch.dot(v, v)
                if v_norm_sq < 1e-12:
                    continue
                projections = (work @ v) / v_norm_sq
                projections[selected_mask] = 0.0
                work -= projections.unsqueeze(1) * v
                norms = torch.norm(work, dim=1)
            return torch.tensor(selected_list, device=dev)

        sub_selected = pivoted_qr_selection(U_candidates, min(k, candidate_indices.numel()), device)
        selected_indices = candidate_indices[sub_selected].to(dtype=torch.long, device=device)
        selected_indices = torch.sort(selected_indices).values
        selected_tokens = vision_tokens[selected_indices]
        return selected_indices, selected_tokens
