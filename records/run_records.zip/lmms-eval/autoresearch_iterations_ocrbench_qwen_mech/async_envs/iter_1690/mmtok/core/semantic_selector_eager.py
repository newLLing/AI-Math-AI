# MMTok: Multimodal Coverage Maximization for Efficient Inference of VLMs
# Paper: https://arxiv.org/abs/2508.18264
# Copyright (c) 2025 Zoom Communications, Inc.
# Author: Anonymous
# Licensed under the Apache License, Version 2.0

"""
MMTok subset selection under maximum coverage (eager/non-JIT version).

Selects a subset of vision tokens to cover (i) text tokens (P: text-vision)
and (ii) the vision token set (Q: vision-vision diversity). Greedy selection
solves the maximum coverage formulation.

This module is an algorithmically identical, non-JIT counterpart of
semantic_selector.py. It keeps only the eager PyTorch path and avoids
@torch.jit.script so that it can run in environments where TorchScript/JIT
is unavailable or undesirable.
"""
from typing import List, Optional, Tuple

import torch
import torch.nn.functional as F
from loguru import logger as eval_logger


class SemanticTokenSelectorEager:
    """
    Coverage-based subset selection of vision tokens (eager/non-JIT).

    Greedy selection to cover text tokens (P) and the vision token set (Q);
    score = coverage_gain(P) + alpha * coverage_gain(Q). This is the same
    algorithm as SemanticTokenSelector in semantic_selector.py, but without
    the TorchScript JIT kernel.
    """

    def __init__(
        self,
        target_vision_tokens: int = 32,
        alpha: float = 0.5,
    ):
        self.target_vision_tokens = target_vision_tokens
        self.alpha: float = alpha

    @staticmethod
    def _l2_normalize(x: torch.Tensor) -> torch.Tensor:
        return x / x.norm(dim=-1, keepdim=True).clamp(min=1e-8)

    def mm_coverage_selection(
        self,
        text_token_embedding: torch.Tensor,
        vision_tokens: torch.Tensor,
        vision_tokens_clip: torch.Tensor,
        tv_temp: float = 0.01,
        vv_temp: float = 0.2,
        padding_patch_indices: Optional[List[int]] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Greedy maximum-coverage subset selection (eager PyTorch only).

        Combined = [P; Q*alpha]: cover text tokens (P) and vision tokens (Q).
        Optional padding exclusion via padding_patch_indices.

        Returns:
            selected_indices: [k_max] Long, sorted indices of selected vision tokens.
            selected_tokens: [k_max, feature_dim] selected vision tokens.
        """
        device = vision_tokens.device
        x_norm = self._l2_normalize(vision_tokens).float()
        x_clip_norm = self._l2_normalize(vision_tokens_clip).float()
        z_norm = self._l2_normalize(text_token_embedding).float()

        P = z_norm @ x_norm.T                       # text-vision coverage [m, n]
        Q = x_clip_norm @ x_clip_norm.T             # vision-vision coverage [n, n]
        m, n = P.shape
        inv_tv_temp = 1.0 / tv_temp
        inv_vv_temp = 1.0 / vv_temp
        P = F.softmax(P * inv_tv_temp, dim=1) / m
        Q = F.softmax(Q * inv_vv_temp, dim=1) / n
        k_max = min(self.target_vision_tokens, n)
        alpha = getattr(self, "alpha", 0.5)
        Q_weighted = Q * alpha
        Combined = torch.cat([P, Q_weighted], dim=0)  # [m+n, n]

        if padding_patch_indices is not None:
            exclude_indices = torch.tensor(
                padding_patch_indices, device=device, dtype=torch.long
            )
        else:
            exclude_indices = torch.empty(0, dtype=torch.long, device=device)

        # Eager greedy maximum-coverage selection (no JIT).
        best_Combined = torch.zeros(m + n, device=device, dtype=torch.float32)
        score_mask = torch.zeros(n, device=device, dtype=torch.float32)
        if exclude_indices.numel() > 0:
            score_mask[exclude_indices] = float("-inf")

        selected_indices = torch.empty(k_max, dtype=torch.long, device=device)
        neg_inf = float("-inf")
        for i in range(k_max):
            delta = (Combined - best_Combined.unsqueeze(1)).clamp_min_(0).sum(dim=0)
            delta.add_(score_mask)
            best_idx = torch.argmax(delta)
            selected_indices[i] = best_idx
            torch.maximum(best_Combined, Combined[:, best_idx], out=best_Combined)
            score_mask[best_idx] = neg_inf

        selected_indices, _ = selected_indices.sort()
        selected_tokens = vision_tokens[selected_indices]
        return selected_indices, selected_tokens
