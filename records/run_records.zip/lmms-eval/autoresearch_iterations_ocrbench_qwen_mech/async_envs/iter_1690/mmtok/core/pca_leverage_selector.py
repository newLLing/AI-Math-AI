# MMTok: Multimodal Coverage Maximization for Efficient Inference of VLMs
# Paper: https://arxiv.org/abs/2508.18264
# Copyright (c) 2025 Zoom Communications, Inc.
# Licensed under the Apache License, Version 2.0

"""
PCA leverage score vision token selector.

Uses torch.pca_lowrank (centered truncated SVD) to compute leverage scores
for each vision token, then deterministically selects the top-k tokens.
Falls back to random selection when input rows are all-zero / constant.
"""

from typing import Optional, List, Tuple

import torch


class PCALeverageSelector:
    """
    PCA low-rank decomposition + leverage score vision token selector.

    Chooses the feature matrix as vision_tokens_clip (CLIP features) when
    available and non-empty, otherwise falls back to vision_tokens.
    Handles all-zero / constant rows by falling back to random selection.
    """

    def __init__(self, target_vision_tokens: int = 64):
        self.target_vision_tokens = target_vision_tokens

    def mm_coverage_selection(
        self,
        text_token_embedding: torch.Tensor,
        vision_tokens: torch.Tensor,
        vision_tokens_clip: torch.Tensor,
        tv_temp: float = 0.01,
        vv_temp: float = 0.2,
        padding_patch_indices: Optional[List[int]] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        PCA-based leverage score vision token selection.

        Args:
            text_token_embedding: Unused (interface compatibility).
            vision_tokens: [N, D] mm_projector output tokens (fallback features).
            vision_tokens_clip: [N, D] CLIP output tokens (primary features for PCA).
            tv_temp: Unused (interface compatibility).
            vv_temp: Unused (interface compatibility).
            padding_patch_indices: Unused (interface compatibility).

        Returns:
            selected_indices: [K] sorted LongTensor of selected token indices.
            selected_tokens: [K, D] selected vision tokens (from vision_tokens).
        """
        device = vision_tokens.device
        N = vision_tokens.size(0)
        k = min(self.target_vision_tokens, N)

        if k <= 0:
            selected_indices = torch.empty(0, dtype=torch.long, device=device)
            selected_tokens = torch.empty(
                0, vision_tokens.size(1), device=device, dtype=vision_tokens.dtype
            )
            return selected_indices, selected_tokens
        elif k >= N or N == 0:
            selected_indices = torch.arange(N, device=device)
            return selected_indices, vision_tokens

        # Choose feature matrix: use vision_tokens_clip if available and non-empty, else vision_tokens
        if vision_tokens_clip is not None and vision_tokens_clip.shape[1] > 0:
            X = vision_tokens_clip
        else:
            X = vision_tokens

        # Ensure 2D
        if X.dim() != 2:
            X = X.reshape(N, -1)

        X = X.to(dtype=torch.float32, device=device)

        # Handle all-zero or constant rows – fallback to random selection
        row_norms = torch.norm(X, dim=1)
        if row_norms.max() < 1e-8:
            perm = torch.randperm(N, device=device)[:k]
            selected_indices = perm.to(dtype=torch.long)
            selected_tokens = vision_tokens[selected_indices]
            return selected_indices, selected_tokens

        # Rank r = min(k, min(N, F) - 1), but at least 1
        F = X.shape[1]
        r = min(k, min(N, F) - 1)
        if r < 1:
            r = 1

        # Truncated (randomised) PCA/SVD – O(N*F*r)
        U, S, V = torch.pca_lowrank(X, q=r, center=True)  # U: [N, r]

        # Leverage scores: squared row norms of U
        scores = torch.sum(U ** 2, dim=1)  # [N]

        # Select the k tokens with largest scores
        _, selected_indices = torch.topk(scores, k, largest=True)
        selected_indices = selected_indices.to(dtype=torch.long, device=device)

        # Sort indices for deterministic ordering
        selected_indices = torch.sort(selected_indices).values

        selected_tokens = vision_tokens[selected_indices]
        return selected_indices, selected_tokens
