# MMTok: Multimodal Coverage Maximization for Efficient Inference of VLMs
# Paper: https://arxiv.org/abs/2508.18264
# Copyright (c) 2025 Zoom Communications, Inc.
# Licensed under the Apache License, Version 2.0

"""
Gram-Schmidt DPP Greedy Selector (iter_118).

A diversity-first token selector that uses Gram-Schmidt orthogonalisation:
1. First token: farthest from the centroid (L2 on unit-sphere).
2. Subsequent tokens: greedily pick the token with the largest residual
   after projecting onto the span of already-selected tokens.
3. Maintain an orthonormal basis Q via modified Gram-Schmidt.

This approximates a determinantal point process (DPP) greedy objective
and favours geometrically diverse tokens.
"""

from typing import List, Optional, Tuple

import torch


class GramSchmidtDPPSelector:
    """
    Gram-Schmidt DPP greedy vision token selector.
    """

    def __init__(self, target_vision_tokens: int = 64):
        self.target_vision_tokens = target_vision_tokens

    @torch.no_grad()
    def mm_coverage_selection(
        self,
        text_token_embedding: torch.Tensor,
        vision_tokens: torch.Tensor,
        vision_tokens_clip: torch.Tensor,
        tv_temp: float = 0.01,
        vv_temp: float = 0.2,
        padding_patch_indices: Optional[List[int]] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Apply Gram-Schmidt DPP greedy selection on vision tokens.

        Args:
            text_token_embedding: Unused (interface compatibility).
            vision_tokens: [N, D] mm_projector output tokens.
            vision_tokens_clip: Unused (interface compatibility).
            tv_temp: Unused (interface compatibility).
            vv_temp: Unused (interface compatibility).
            padding_patch_indices: Optional list of indices to exclude from selection.

        Returns:
            selected_indices: [K] sorted LongTensor of selected token indices.
            selected_tokens: [K, D] selected vision tokens.
        """
        device = vision_tokens.device
        N = vision_tokens.size(0)
        k = min(self.target_vision_tokens, N)

        if k <= 0:
            selected_indices = torch.empty(0, dtype=torch.long, device=device)
            selected_tokens = torch.empty(
                0, vision_tokens.size(1), device=device, dtype=vision_tokens.dtype
            )
            return selected_indices, selected_tokens
        elif k >= N or N == 0:
            selected_indices = torch.arange(N, device=device)
            return selected_indices, vision_tokens

        X = vision_tokens
        d = X.shape[1]
        dtype = X.dtype

        eps = 1e-8
        norms = torch.norm(X, dim=1, keepdim=True) + eps
        X_unit = X / norms  # [N, d], unit length

        selected = []
        Q = torch.empty(0, d, device=device, dtype=dtype)  # orthonormal basis

        # Exclude padding patches
        if padding_patch_indices is not None and len(padding_patch_indices) > 0:
            exclude_mask = torch.zeros(N, dtype=torch.bool, device=device)
            exclude_mask[padding_patch_indices] = True
        else:
            exclude_mask = None

        for step in range(k):
            if len(selected) == 0:
                centroid = torch.mean(X_unit, dim=0, keepdim=True)  # [1, d]
                dist_to_centroid = torch.sum((X_unit - centroid) ** 2, dim=1)  # [N]
                score = dist_to_centroid
            else:
                coeff = torch.matmul(X_unit, Q.T)  # [N, k]
                residual = 1.0 - torch.sum(coeff ** 2, dim=1)  # [N]
                score = residual

            if exclude_mask is not None:
                score = score.clone()
                score[exclude_mask] = -float("inf")
            if len(selected) > 0:
                score = score.clone()
                score[torch.tensor(selected, dtype=torch.long, device=device)] = -float("inf")

            i = torch.argmax(score).item()
            selected.append(i)

            # Update orthonormal basis Q (modified Gram-Schmidt)
            x = X_unit[i]  # [d]
            if Q.shape[0] > 0:
                proj = torch.matmul(Q, x)  # [k]
                r = x - torch.matmul(proj, Q)  # [d]
                r_norm = torch.norm(r) + 1e-12
                if r_norm > 1e-8:
                    q_new = r / r_norm
                    Q = torch.cat([Q, q_new.unsqueeze(0)], dim=0)
            else:
                r_norm = torch.norm(x) + 1e-12
                Q = x.unsqueeze(0) / r_norm

        selected_indices = torch.tensor(selected, dtype=torch.long, device=device)
        selected_indices = torch.sort(selected_indices).values
        selected_tokens = vision_tokens[selected_indices]
        return selected_indices, selected_tokens
