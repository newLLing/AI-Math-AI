# MMTok: Multimodal Coverage Maximization for Efficient Inference of VLMs
# Paper: https://arxiv.org/abs/2508.18264
# Copyright (c) 2025 Zoom Communications, Inc.
# Author: Anonymous
# Licensed under the Apache License, Version 2.0

"""
GOTS-JIT selector: greedy orthogonal token selection via an implicit-residual
QRCP kernel compiled with TorchScript.

This preserves the same greedy pivoting rule as the reference GOTS selector
(`gots_selector.py`) but moves the per-iteration loop into compiled TorchScript
to reduce Python dispatch overhead.
"""

from typing import List, Optional, Tuple

import torch

from loguru import logger as eval_logger

from .gots_selector import GOTSAlgorithmCore


eval_logger.info("[MMTok] gots_jit_selector.py loaded")


@torch.jit.script
def gots_jit_kernel(
    image_features: torch.Tensor,
    target_vision_tokens: int,
    eps: float = 1e-12,
) -> torch.Tensor:
    """TorchScript-compiled implicit-residual QRCP/GOTS selection.

    It preserves the same greedy pivoting rule as `gots_implicit_kernel` in
    `gots_selector.py`, while running the iterative loop inside compiled
    TorchScript to avoid Python interpreter overhead.
    """
    N, feature_dim = image_features.shape
    K = target_vision_tokens
    if K > N:
        K = N
    device = image_features.device

    if K <= 0 or N == 0:
        return torch.empty(0, dtype=torch.long, device=device)

    if K >= N:
        return torch.arange(N, dtype=torch.long, device=device)

    X = image_features.detach()
    if X.dtype != torch.float32:
        X = X.float()
    if not X.is_contiguous():
        X = X.contiguous()

    selected = torch.empty(K, dtype=torch.long, device=device)

    # basis[t] stores q_t: [K, d].
    basis = torch.empty(
        (K, feature_dim),
        dtype=torch.float32,
        device=device,
    )

    # coefficients[t, j] = <x_j, q_t>: [K, N].
    coefficients = torch.empty(
        (K, N),
        dtype=torch.float32,
        device=device,
    )

    # Avoid allocating an N x d tensor; compute squared norms directly.
    residual_norm2 = (X * X).sum(dim=1)

    # Temporary vector used only to reconstruct the selected residual.
    projection = torch.empty(
        feature_dim,
        dtype=torch.float32,
        device=device,
    )

    neg_inf = float('-inf')

    for step in range(K):
        pivot = torch.argmax(residual_norm2)
        selected[step] = pivot

        # Use the corresponding row in the preallocated basis as q.
        q = basis[step]
        q.copy_(X[pivot])

        if step > 0:
            # r_i = x_i - sum_l <x_i, q_l> q_l
            # basis[:step].T: [d, step]
            # coefficients[:step, pivot]: [step]
            torch.mv(
                basis[:step].transpose(0, 1),
                coefficients[:step, pivot],
                out=projection,
            )
            q.sub_(projection)

        # Normalize with the tracked residual energy.
        pivot_norm2 = residual_norm2[pivot]
        pivot_norm2 = torch.clamp_min(pivot_norm2, eps)
        q.mul_(torch.rsqrt(pivot_norm2))

        # coefficients[step, j] = <x_j, q>
        dot = coefficients[step]
        torch.mv(X, q, out=dot)

        # ||r_j_new||^2 = ||r_j_old||^2 - <x_j, q>^2
        residual_norm2.addcmul_(dot, dot, value=-1.0)
        residual_norm2[pivot] = neg_inf

    sorted_selected, _ = torch.sort(selected)
    return sorted_selected


class GOTSSelectorJIT:
    """MMTok selector registry wrapper for the JIT-compiled GOTS algorithm."""

    def __init__(
        self,
        target_vision_tokens: int = 32,
    ):
        self.target_vision_tokens = target_vision_tokens
        self._core = GOTSAlgorithmCore(mmtok_core=None)

    @torch.inference_mode()
    def mm_coverage_selection(
        self,
        text_token_embedding: torch.Tensor,
        vision_tokens: torch.Tensor,
        vision_tokens_clip: torch.Tensor,
        tv_temp: float = 0.01,
        vv_temp: float = 0.2,
        padding_patch_indices: Optional[List[int]] = None,
        image_grid_thw: torch.Tensor = None,
    ) -> Tuple[List[int], torch.Tensor]:
        selected_indices_tensor = gots_jit_kernel(
            image_features=vision_tokens_clip,
            target_vision_tokens=self.target_vision_tokens,
        )

        if padding_patch_indices is not None and len(padding_patch_indices) > 0:
            mask = torch.ones(
                vision_tokens.shape[0], dtype=torch.bool, device=vision_tokens.device
            )
            mask[padding_patch_indices] = False
            valid_mask = mask[selected_indices_tensor]
            selected_indices_tensor = selected_indices_tensor[valid_mask]
            max_k = min(self.target_vision_tokens, len(selected_indices_tensor))
            selected_indices_tensor = selected_indices_tensor[:max_k]

        selected_tokens = torch.index_select(
            vision_tokens,
            dim=0,
            index=selected_indices_tensor,
        )

        selected_indices = selected_indices_tensor.tolist()
        if not isinstance(selected_indices, list):
            selected_indices = [selected_indices]

        return selected_indices, selected_tokens
