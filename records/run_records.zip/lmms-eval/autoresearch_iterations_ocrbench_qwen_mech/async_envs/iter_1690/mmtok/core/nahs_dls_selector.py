# MMTok: Multimodal Coverage Maximization for Efficient Inference of VLMs
# Paper: https://arxiv.org/abs/2508.18264
# Copyright (c) 2025 Zoom Communications, Inc.
# Licensed under the Apache License, Version 2.0

"""
NAHS-DLS: Norm-guided Adaptive Hybrid Selection with Distance-based Leverage Score.

A two-stage vision token selector:
1. Norm-guided initialization: select the token with the highest L2 norm.
2. Adaptive hybrid selection: iteratively score candidates by a weighted combination
   of normalized norm and normalized minimum distance to already-selected tokens.
   The weight alpha_t decays over iterations.
"""

from typing import Optional, List, Tuple

import torch


class NAHSDLSSelector:
    """
    Norm-guided Adaptive Hybrid Selection with Distance-based Leverage Score.

    Selects vision tokens using a hybrid of norm magnitude and diversity (distance).
    """

    def __init__(self, target_vision_tokens: int = 64, alpha_0: float = 0.7):
        self.target_vision_tokens = target_vision_tokens
        self.alpha_0 = alpha_0

    def mm_coverage_selection(
        self,
        text_token_embedding: torch.Tensor,
        vision_tokens: torch.Tensor,
        vision_tokens_clip: torch.Tensor,
        tv_temp: float = 0.01,
        vv_temp: float = 0.2,
        padding_patch_indices: Optional[List[int]] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Apply NAHS-DLS selection on vision tokens.

        Args:
            text_token_embedding: Unused (interface compatibility).
            vision_tokens: [N, D] mm_projector output tokens.
            vision_tokens_clip: Unused (interface compatibility).
            tv_temp: Unused (interface compatibility).
            vv_temp: Unused (interface compatibility).
            padding_patch_indices: Unused (interface compatibility).

        Returns:
            selected_indices: [K] sorted LongTensor of selected token indices.
            selected_tokens: [K, D] selected vision tokens.
        """
        device = vision_tokens.device
        N = vision_tokens.size(0)
        k = min(self.target_vision_tokens, N)

        if k <= 0:
            selected_indices = torch.empty(0, dtype=torch.long, device=device)
            selected_tokens = torch.empty(
                0, vision_tokens.size(1), device=device, dtype=vision_tokens.dtype
            )
            return selected_indices, selected_tokens
        elif k >= N or N == 0:
            selected_indices = torch.arange(N, device=device)
            return selected_indices, vision_tokens

        X = vision_tokens
        norms = torch.norm(X, p=2, dim=1)
        candidate_mask = torch.ones(N, dtype=torch.bool, device=device)
        selected = []

        # Stage 1: Norm-guided initialization
        first_idx = torch.argmax(norms).item()
        selected.append(first_idx)
        candidate_mask[first_idx] = False

        # Stage 2: Adaptive hybrid selection
        if k > 1:
            for t in range(1, k):
                alpha_t = self.alpha_0 * (1.0 - t / k)
                beta_t = 1.0 - alpha_t

                cand_X = X[candidate_mask]
                sel_X = X[~candidate_mask]
                cand_norms = norms[candidate_mask]
                cand_indices = torch.where(candidate_mask)[0]

                dists = torch.cdist(cand_X, sel_X, p=2)
                min_dists = torch.min(dists, dim=1).values

                norm_max = torch.max(cand_norms)
                dist_max = torch.max(min_dists)
                norm_score = cand_norms / (norm_max + 1e-8)
                dist_score = min_dists / (dist_max + 1e-8)

                scores = alpha_t * norm_score + beta_t * dist_score
                sorted_idx = torch.argsort(scores, descending=True)
                best_local = sorted_idx[0].item()
                global_idx = cand_indices[best_local].item()

                selected.append(global_idx)
                candidate_mask[global_idx] = False

        selected_indices = torch.tensor(selected, dtype=torch.long, device=device)
        selected_indices = torch.sort(selected_indices).values
        selected_tokens = vision_tokens[selected_indices]
        return selected_indices, selected_tokens
