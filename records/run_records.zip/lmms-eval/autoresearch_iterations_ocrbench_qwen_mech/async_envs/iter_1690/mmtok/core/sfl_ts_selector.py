# MMTok: Multimodal Coverage Maximization for Efficient Inference of VLMs
# Paper: https://arxiv.org/abs/2508.18264
# Copyright (c) 2025 Zoom Communications, Inc.
# Licensed under the Apache License, Version 2.0

"""
SFL-TS: Submodular Facility Location Token Selection (iter_035).

A greedy coverage maximisation selector:
1. L2-normalise vision tokens.
2. Pre-compute full cosine-similarity matrix S = X_norm @ X_norm.T.
3. Greedily select k tokens that maximise the facility-location coverage
   F(S) = sum_i max_{j in S} s_{ij}.

The greedy algorithm achieves a (1-1/e) approximation guarantee for this
monotone submodular objective.
"""

from typing import List, Optional, Tuple

import torch
import torch.nn.functional as F


class SFLTSSelector:
    """
    Submodular Facility Location Token Selection.

    Vectorised implementation: pre-computes the full N×N similarity matrix
    and updates marginal gains in O(k N) per step (k steps total).
    """

    def __init__(self, target_vision_tokens: int = 64):
        self.target_vision_tokens = target_vision_tokens

    @torch.no_grad()
    def mm_coverage_selection(
        self,
        text_token_embedding: torch.Tensor,
        vision_tokens: torch.Tensor,
        vision_tokens_clip: torch.Tensor,
        tv_temp: float = 0.01,
        vv_temp: float = 0.2,
        padding_patch_indices: Optional[List[int]] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Apply SFL-TS selection on vision tokens.

        Args:
            text_token_embedding: Unused (interface compatibility).
            vision_tokens: [N, D] mm_projector output tokens.
            vision_tokens_clip: Unused (interface compatibility).
            tv_temp: Unused (interface compatibility).
            vv_temp: Unused (interface compatibility).
            padding_patch_indices: Optional list of indices to exclude from selection.

        Returns:
            selected_indices: [K] sorted LongTensor of selected token indices.
            selected_tokens: [K, D] selected vision tokens.
        """
        device = vision_tokens.device
        N = vision_tokens.size(0)
        k = min(self.target_vision_tokens, N)

        if k <= 0:
            selected_indices = torch.empty(0, dtype=torch.long, device=device)
            selected_tokens = torch.empty(
                0, vision_tokens.size(1), device=device, dtype=vision_tokens.dtype
            )
            return selected_indices, selected_tokens
        elif k >= N or N == 0:
            selected_indices = torch.arange(N, device=device)
            return selected_indices, vision_tokens

        X = vision_tokens
        dtype = X.dtype

        # 1. L2 normalisation
        X_norm = F.normalize(X, dim=1)  # [N, D]

        # 2. Pre-compute full similarity matrix (vectorised greedy)
        S = torch.matmul(X_norm, X_norm.T)  # [N, N]

        # Exclude padding patches by setting their similarities to -inf
        if padding_patch_indices is not None and len(padding_patch_indices) > 0:
            S[:, padding_patch_indices] = -1.0
            S[padding_patch_indices, :] = -1.0

        # 3. Greedy coverage maximisation
        selected_mask = torch.zeros(N, dtype=torch.bool, device=device)
        m = torch.full((N,), -1.0, device=device, dtype=dtype)  # current max similarity per token

        for _ in range(k):
            # Marginal gain for each candidate j:
            # gain(j) = sum_i max(0, S[i,j] - m[i])
            gains = torch.clamp(S - m.unsqueeze(1), min=0).sum(dim=0)  # [N]
            gains[selected_mask] = -torch.inf

            j_star = torch.argmax(gains).item()
            selected_mask[j_star] = True
            m = torch.maximum(m, S[:, j_star])

        selected_indices = torch.arange(N, device=device)[selected_mask]
        selected_indices = torch.sort(selected_indices).values
        selected_tokens = vision_tokens[selected_indices]
        return selected_indices, selected_tokens
