# MMTok: Multimodal Coverage Maximization for Efficient Inference of VLMs
# Paper: https://arxiv.org/abs/2508.18264
# Copyright (c) 2025 Zoom Communications, Inc.
# Licensed under the Apache License, Version 2.0

"""
Iter317 Fusion Selector.

Combines:
1. z-score normalisation for numerical stability.
2. Random projection to reduce dimensionality.
3. Question relevance via projected text embeddings.
4. Structural importance via power-iterated randomized SVD (leverage scores).
5. Greedy diversity loop balancing relevance and cumulative L2 distance.
"""

from typing import List, Optional, Tuple

import torch


class Iter317FusionSelector:
    """
    Fusion selector (iter_317): z-score norm + random proj + power-SVD leverage
    + query relevance + greedy diversity.
    """

    def __init__(
        self,
        target_vision_tokens: int = 64,
        use_random_proj: bool = True,
        proj_dim: Optional[int] = None,
        svd_rank_ratio: float = 0.2,
        svd_oversampling: int = 5,
        power_iterations: int = 1,
        leverage_weight: float = 0.3,
        alpha: float = 0.3,
    ):
        self.target_vision_tokens = target_vision_tokens
        self.use_random_proj = use_random_proj
        self.proj_dim = proj_dim
        self.svd_rank_ratio = svd_rank_ratio
        self.svd_oversampling = svd_oversampling
        self.power_iterations = power_iterations
        self.leverage_weight = leverage_weight
        self.alpha = alpha

    @torch.no_grad()
    def mm_coverage_selection(
        self,
        text_token_embedding: torch.Tensor,
        vision_tokens: torch.Tensor,
        vision_tokens_clip: torch.Tensor,
        tv_temp: float = 0.01,
        vv_temp: float = 0.2,
        padding_patch_indices: Optional[List[int]] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Apply iter_317 fusion selection on vision tokens.

        Args:
            text_token_embedding: [T, D] text token embeddings (question/keywords).
            vision_tokens: [N, D] mm_projector output tokens.
            vision_tokens_clip: Unused (interface compatibility).
            tv_temp: Unused (interface compatibility).
            vv_temp: Unused (interface compatibility).
            padding_patch_indices: Optional list of indices to exclude from selection.

        Returns:
            selected_indices: [K] sorted LongTensor of selected token indices.
            selected_tokens: [K, D] selected vision tokens.
        """
        device = vision_tokens.device
        N = vision_tokens.size(0)
        k = min(self.target_vision_tokens, N)

        if k <= 0:
            selected_indices = torch.empty(0, dtype=torch.long, device=device)
            selected_tokens = torch.empty(
                0, vision_tokens.size(1), device=device, dtype=vision_tokens.dtype
            )
            return selected_indices, selected_tokens
        elif k >= N or N == 0:
            selected_indices = torch.arange(N, device=device)
            return selected_indices, vision_tokens

        # ------------------------------------------------------------------
        # 1. z-score normalisation (internal computation only)
        # ------------------------------------------------------------------
        X = vision_tokens.to(torch.float32)
        X_mean = X.mean(dim=0, keepdim=True)
        X_std = X.std(dim=0, keepdim=True) + 1e-8
        X = (X - X_mean) / X_std  # [N, D]
        D = X.shape[1]

        # ------------------------------------------------------------------
        # 2. Random projection
        # ------------------------------------------------------------------
        if self.use_random_proj:
            proj_dim = self.proj_dim
            if proj_dim is None:
                proj_dim = min(D, max(64, D // 2))
            W = torch.randn(D, proj_dim, device=device, dtype=torch.float32)
            W = W / torch.norm(W, dim=0, keepdim=True)
            X_proj = X @ W  # [N, proj_dim]
            W_ref = W
        else:
            X_proj = X
            W_ref = None
            proj_dim = D

        # ------------------------------------------------------------------
        # 3. Question relevance
        # ------------------------------------------------------------------
        relevance = torch.zeros(N, device=device, dtype=torch.float32)
        if text_token_embedding is not None and text_token_embedding.numel() > 0:
            q_emb = text_token_embedding.mean(dim=0, keepdim=True).to(torch.float32)  # [1, D]
            if W_ref is not None:
                q_proj = q_emb @ W_ref  # [1, proj_dim]
            else:
                q_proj = q_emb
            relevance = (X_proj * q_proj).sum(dim=1)  # [N]

        # ------------------------------------------------------------------
        # 4. Structural importance: power-iterated randomized SVD
        # ------------------------------------------------------------------
        target_rank = max(1, min(proj_dim, int(self.svd_rank_ratio * k)))
        oversampling = min(self.svd_oversampling, proj_dim - target_rank)
        rank_r = target_rank + oversampling
        rank_r = max(1, min(rank_r, proj_dim))

        P = torch.randn(proj_dim, rank_r, device=device, dtype=torch.float32)
        Y = X_proj @ P  # [N, rank_r]
        for _ in range(self.power_iterations):
            Y = X_proj @ (X_proj.t() @ Y)
        Q, _ = torch.linalg.qr(Y.to(torch.float32))  # [N, rank_r]
        B = Q.t() @ X_proj  # [rank_r, proj_dim]
        U_B, _, _ = torch.linalg.svd(B.to(torch.float32), full_matrices=False)
        U_small = U_B[:, :target_rank]  # [rank_r, target_rank]
        U_x = Q @ U_small  # [N, target_rank]
        structure_score = (U_x ** 2).sum(dim=1)  # [N]

        # Normalise structure_score to match mean abs magnitude of relevance
        if relevance.abs().mean() > 1e-6:
            structure_score = structure_score * (
                relevance.abs().mean() / (structure_score.mean() + 1e-8)
            )

        gamma = self.leverage_weight
        relevance_combined = (1.0 - gamma) * relevance + gamma * structure_score

        # ------------------------------------------------------------------
        # 5. Greedy diversity selection
        # ------------------------------------------------------------------
        if relevance_combined.std() > 1e-6:
            first_idx = torch.argmax(relevance_combined).item()
        else:
            first_idx = torch.argmax((X ** 2).sum(dim=1)).item()

        selected = [first_idx]
        selected_mask = torch.zeros(N, dtype=torch.bool, device=device)
        selected_mask[first_idx] = True

        # Exclude padding patches
        if padding_patch_indices is not None and len(padding_patch_indices) > 0:
            selected_mask[padding_patch_indices] = True

        alpha = self.alpha
        diff = X - X[first_idx].unsqueeze(0)
        cum_dist = (diff ** 2).sum(dim=1)  # [N]

        for _ in range(1, k):
            score = alpha * relevance_combined + (1.0 - alpha) * cum_dist
            score.masked_fill_(selected_mask, float("-inf"))
            next_idx = torch.argmax(score).item()
            selected.append(next_idx)
            selected_mask[next_idx] = True
            diff = X - X[next_idx].unsqueeze(0)
            cum_dist += (diff ** 2).sum(dim=1)

        selected_indices = torch.tensor(selected, dtype=torch.long, device=device)
        selected_indices = torch.sort(selected_indices).values
        selected_tokens = vision_tokens[selected_indices]
        return selected_indices, selected_tokens
