# MMTok: Gauss-Southwell vision token selector v3
# (stable adaptive lambda via power iteration + spectral anchor via randomized SVD)

from typing import Optional, List, Tuple

import torch
import torch.nn.functional as F


class GaussSouthwellV3Selector:
    """
    Improved Gauss-Southwell greedy vision token selector (v3).

    Improvements over baseline:
    1. Stable adaptive lambda: estimated via power iteration instead of
       direct matrix norm, safer for mixed-precision tensors.
    2. Spectral anchor initialization: first token chosen by randomized SVD
       (projection onto the dominant right singular vector), yielding a
       semantically salient and well-conditioned starting point.
    """

    def __init__(self, target_vision_tokens: int = 64):
        self.target_vision_tokens = target_vision_tokens

    def mm_coverage_selection(
        self,
        text_token_embedding: torch.Tensor,
        vision_tokens: torch.Tensor,
        vision_tokens_clip: torch.Tensor,
        tv_temp: float = 0.01,
        vv_temp: float = 0.2,
        padding_patch_indices: Optional[List[int]] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Gauss-Southwell-based vision token selection (v3).

        Args:
            text_token_embedding: [T, D] text token embeddings (question/keywords).
            vision_tokens: [N, D] mm_projector output tokens.
            vision_tokens_clip: Unused (interface compatibility).
            tv_temp: Unused (interface compatibility).
            vv_temp: Unused (interface compatibility).
            padding_patch_indices: Optional list of indices to exclude from selection.

        Returns:
            selected_indices: [K] sorted LongTensor of selected token indices.
            selected_tokens: [K, D] selected vision tokens.
        """
        device = vision_tokens.device
        N = vision_tokens.size(0)
        k = min(self.target_vision_tokens, N)

        if k <= 0:
            selected_indices = torch.empty(0, dtype=torch.long, device=device)
            selected_tokens = torch.empty(0, vision_tokens.size(1), device=device, dtype=vision_tokens.dtype)
            return selected_indices, selected_tokens
        elif k >= N or N == 0:
            selected_indices = torch.arange(N, device=device)
            return selected_indices, vision_tokens

        # 1. Compute question embedding q from text tokens
        if text_token_embedding is not None and text_token_embedding.numel() > 0:
            q_raw = text_token_embedding.mean(dim=0)  # [D]
            q = F.normalize(q_raw, p=2, dim=0)  # [D]
        else:
            q = torch.ones(vision_tokens.size(1), device=device, dtype=vision_tokens.dtype)
            q = F.normalize(q, p=2, dim=0)

        # 2. Normalize image embeddings and compute relevance scores
        X_norm = F.normalize(vision_tokens, p=2, dim=1)  # [N, D]
        r = torch.matmul(X_norm, q)  # [N]

        # Handle padding exclusion
        excluded_mask = torch.zeros(N, dtype=torch.bool, device=device)
        if padding_patch_indices is not None and len(padding_patch_indices) > 0:
            excluded_mask[padding_patch_indices] = True

        # --- ADAPTIVE LAMBDA with stable power iteration ---
        X_norm_f32 = X_norm.to(torch.float32)  # [N, D] in fp32
        d = X_norm_f32.size(1)
        max_iter = 5
        v = torch.randn(d, device=X_norm_f32.device, dtype=torch.float32)
        v = v / torch.norm(v, p=2)
        for _ in range(max_iter):
            Av = X_norm_f32 @ v
            v_new = X_norm_f32.T @ Av
            norm_v_new = torch.norm(v_new, p=2)
            if norm_v_new > 1e-12:
                v = v_new / norm_v_new
            else:
                break
        Av_final = X_norm_f32 @ v
        sigma_max = torch.norm(Av_final, p=2).clamp(min=1e-8)
        max_eigenvalue = sigma_max ** 2
        lambda_ = 1.0 - 1.0 / (max_eigenvalue + 1e-8)
        lambda_ = torch.clamp(lambda_, 0.0, 1.0).item()
        # --- END STABLE LAMBDA ---

        # === Spectral anchor via randomized SVD (float32 for mixed-precision safety) ===
        p = min(d, 10)
        Omega = torch.randn(d, p, device=device, dtype=torch.float32)
        X_norm_f32_svd = X_norm.to(torch.float32)
        Y = X_norm_f32_svd @ Omega  # [N, p], float32
        Q, _ = torch.linalg.qr(Y, mode='reduced')  # [N, p], float32
        B = Q.t() @ X_norm_f32_svd  # [p, d], float32
        U_B, S_B, Vh_B = torch.linalg.svd(B, full_matrices=False)
        v1 = Vh_B[0]  # [d], float32
        proj = X_norm_f32_svd @ v1  # [N], float32
        abs_proj = torch.abs(proj)
        abs_proj[excluded_mask] = -float("inf")

        if abs_proj.max().item() == -float("inf"):
            first_idx = 0
        else:
            first_idx = torch.argmax(abs_proj).item()
        # =========================================

        # 3. Prepare selection mask and mean accumulator
        selected_mask = torch.zeros(N, dtype=torch.bool, device=device)
        D = vision_tokens.size(1)
        M = torch.zeros(D, device=device, dtype=vision_tokens.dtype)

        selected_mask[first_idx] = True
        selected_indices_list = [first_idx]
        M = M + X_norm[first_idx]

        # 4. Greedy Gauss-Southwell loop
        for step in range(1, k):
            M_mean = M / step
            scores = r - lambda_ * torch.matmul(X_norm, M_mean)
            scores[selected_mask] = -float('inf')
            scores[excluded_mask] = -float('inf')
            j = torch.argmax(scores)
            selected_mask[j] = True
            selected_indices_list.append(j.item())
            M = M + X_norm[j]

        selected_indices = torch.tensor(selected_indices_list, dtype=torch.long, device=device)
        selected_indices = torch.sort(selected_indices).values
        selected_tokens = vision_tokens[selected_indices]
        return selected_indices, selected_tokens
