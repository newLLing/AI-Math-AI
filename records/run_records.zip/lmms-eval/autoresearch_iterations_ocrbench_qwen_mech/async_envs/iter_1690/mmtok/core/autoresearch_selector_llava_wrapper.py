import torch
from typing import List, Optional, Tuple

from .autoresearch_selector_llava import LLaVAAlgorithmCore


class AutoResearchSelectorLLaVA:
    def __init__(self, target_vision_tokens: int = 32, alpha: float = 0.5):
        self.target_vision_tokens = target_vision_tokens
        self.alpha = alpha
        self._core = LLaVAAlgorithmCore(mmtok_core=None)

    def mm_coverage_selection(
        self,
        text_token_embedding: torch.Tensor,
        vision_tokens: torch.Tensor,
        vision_tokens_clip: torch.Tensor,
        tv_temp: float = 0.01,
        vv_temp: float = 0.2,
        padding_patch_indices: Optional[List[int]] = None,
    ) -> Tuple[List[int], torch.Tensor]:
        selected_indices_tensor = self._core.select_vision_tokens(
            image_embeds=vision_tokens,
            image_features=vision_tokens_clip,
            question="",
            target_vision_tokens=self.target_vision_tokens,
            text_token_embedding=text_token_embedding,
        )
        selected_indices_tensor, _ = selected_indices_tensor.sort()
        selected_indices = selected_indices_tensor.tolist()
        if not isinstance(selected_indices, list):
            selected_indices = torch.tensor([selected_indices_tensor.item()], dtype=torch.long, device=vision_tokens.device)
        selected_tokens = vision_tokens[selected_indices_tensor]
        return selected_indices, selected_tokens
