# MMTok: Multimodal Coverage Maximization for Efficient Inference of VLMs
# Paper: https://arxiv.org/abs/2508.18264
# Copyright (c) 2025 Zoom Communications, Inc.
# Licensed under the Apache License, Version 2.0

"""
DCT Smoothing Selector.

Query-aware vision token selection via 2D DCT low-pass filtering:
1. Compute cosine similarity between vision tokens and mean-pooled text query.
2. For each image, reshape similarity map to 2D spatial grid (from image_grid_thw).
3. Apply 2D orthogonal DCT, keep a low-frequency square region, then inverse DCT.
4. Select top-K tokens globally from the smoothed scores.

If image_grid_thw is unavailable, falls back to raw semantic top-K.
"""

import math
from typing import List, Optional, Tuple

import torch
import torch.nn.functional as F


def _get_orthogonal_dct_matrix(N: int, device: torch.device, dtype: torch.dtype = torch.float32) -> torch.Tensor:
    """Generate N x N orthogonal DCT-II matrix."""
    i = torch.arange(N, device=device).float()
    j = torch.arange(N, device=device).float()
    D = torch.cos((j.unsqueeze(1) + 0.5) * math.pi * i / N)
    c0 = torch.ones(N, device=device) / math.sqrt(N)
    c_rest = math.sqrt(2.0 / N) * torch.ones(N - 1, device=device)
    scale = torch.cat([c0[:1], c_rest])
    D = D * scale.unsqueeze(0)
    D = D.to(dtype)
    return D


def _nearest_square_grid(num: int) -> Tuple[int, int]:
    """Find the closest 2D grid factorization for a given number."""
    for d in range(int(math.isqrt(num)), 0, -1):
        if num % d == 0:
            return d, num // d
    return 1, num


class DCTSmoothingSelector:
    """
    DCT-based spatial smoothing vision token selector.
    """

    def __init__(
        self,
        target_vision_tokens: int = 64,
        sort_indices: bool = False,
    ):
        self.target_vision_tokens = target_vision_tokens
        self.sort_indices = sort_indices

    @torch.no_grad()
    def mm_coverage_selection(
        self,
        text_token_embedding: torch.Tensor,
        vision_tokens: torch.Tensor,
        vision_tokens_clip: torch.Tensor,
        tv_temp: float = 0.01,
        vv_temp: float = 0.2,
        padding_patch_indices: Optional[List[int]] = None,
        **kwargs,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Apply DCT smoothing selection on vision tokens.

        Args:
            text_token_embedding: [L, D] text token embeddings (question/keywords).
            vision_tokens: [N, D] mm_projector output tokens.
            vision_tokens_clip: Unused (interface compatibility).
            tv_temp: Unused (interface compatibility).
            vv_temp: Unused (interface compatibility).
            padding_patch_indices: Optional list of indices to exclude from selection.
            **kwargs: May contain ``image_grid_thw`` of shape [num_images, 3].

        Returns:
            selected_indices: [K] LongTensor of selected token indices.
            selected_tokens: [K, D] selected vision tokens.
        """
        device = vision_tokens.device
        N = vision_tokens.size(0)
        K = min(self.target_vision_tokens, N)

        if K <= 0:
            selected_indices = torch.empty(0, dtype=torch.long, device=device)
            selected_tokens = torch.empty(0, vision_tokens.size(1), device=device, dtype=vision_tokens.dtype)
            return selected_indices, selected_tokens
        elif K >= N or N == 0:
            selected_indices = torch.arange(N, device=device)
            return selected_indices, vision_tokens

        # Candidate mask excluding padding patches
        candidate_mask = torch.ones(N, dtype=torch.bool, device=device)
        if padding_patch_indices is not None and len(padding_patch_indices) > 0:
            if isinstance(padding_patch_indices, torch.Tensor):
                pad_idx = padding_patch_indices.to(device)
            else:
                pad_idx = torch.tensor(padding_patch_indices, dtype=torch.long, device=device)
            candidate_mask[pad_idx] = False

        num_eligible = candidate_mask.sum().item()
        if K >= num_eligible:
            selected_indices = torch.where(candidate_mask)[0]
            return selected_indices, vision_tokens[selected_indices]

        K = min(K, num_eligible)

        # ---------- 1. Query embedding and cosine similarity ----------
        if text_token_embedding is not None and text_token_embedding.numel() > 0:
            q_mean = text_token_embedding.float().mean(dim=0)  # [D]
        else:
            q_mean = torch.zeros(vision_tokens.size(1), device=device, dtype=torch.float32)

        q_norm = q_mean / (q_mean.norm() + 1e-12)
        v_norm = vision_tokens.float() / (vision_tokens.float().norm(dim=1, keepdim=True) + 1e-12)
        w_all = torch.mm(v_norm, q_norm.unsqueeze(-1)).squeeze(-1)  # [N]

        # ---------- 2. Retrieve or infer grid shapes ----------
        image_grid_thw = kwargs.get("image_grid_thw", None)

        all_smooth = []
        offsets = []
        start_idx = 0

        if image_grid_thw is not None and len(image_grid_thw) > 0:
            for i in range(image_grid_thw.shape[0]):
                t, h, w = image_grid_thw[i].tolist()
                n_tokens = t * h * w
                end_idx = start_idx + n_tokens
                if end_idx > N:
                    n_tokens = N - start_idx
                    end_idx = N
                    if n_tokens <= 0:
                        break

                img_tokens = vision_tokens[start_idx:end_idx]
                v_norm_img = img_tokens.float() / (img_tokens.float().norm(dim=1, keepdim=True) + 1e-12)
                w_img = torch.mm(v_norm_img, q_norm.unsqueeze(-1)).squeeze(-1)  # [n_tokens]

                if t == 1 and h > 1 and w > 1:
                    w_2d = w_img.view(h, w).float()
                    D_h = _get_orthogonal_dct_matrix(h, device, dtype=torch.float32)
                    D_w = _get_orthogonal_dct_matrix(w, device, dtype=torch.float32)
                    W_dct = D_h @ w_2d @ D_w.t()

                    radius = max(1, int(math.ceil(math.sqrt(n_tokens))))
                    r_h = min(h, radius)
                    r_w = min(w, radius)
                    Y_low = torch.zeros_like(W_dct)
                    Y_low[:r_h, :r_w] = W_dct[:r_h, :r_w]

                    w_smooth_2d = D_h.t() @ Y_low @ D_w
                    w_smooth_img = w_smooth_2d.contiguous().view(-1).to(w_img.dtype)
                else:
                    w_smooth_img = w_img.to(w_img.dtype)

                all_smooth.append(w_smooth_img)
                offsets.append(start_idx)
                start_idx = end_idx
                if start_idx >= N:
                    break
        else:
            # Fallback: treat all tokens as a single image; try to infer 2D grid
            h = int(N ** 0.5)
            if h * h == N:
                spatial_shape = (h, h)
            else:
                H, W = _nearest_square_grid(N)
                if H >= 2 and W >= 2 and max(H, W) / max(min(H, W), 1) <= 4:
                    spatial_shape = (H, W)
                else:
                    spatial_shape = None

            if spatial_shape is not None:
                H, W = spatial_shape
                w_2d = w_all.view(H, W).float()
                D_h = _get_orthogonal_dct_matrix(H, device, dtype=torch.float32)
                D_w = _get_orthogonal_dct_matrix(W, device, dtype=torch.float32)
                W_dct = D_h @ w_2d @ D_w.t()
                radius = max(1, int(math.ceil(math.sqrt(N))))
                r_h = min(H, radius)
                r_w = min(W, radius)
                Y_low = torch.zeros_like(W_dct)
                Y_low[:r_h, :r_w] = W_dct[:r_h, :r_w]
                w_smooth_all = (D_h.t() @ Y_low @ D_w).contiguous().view(-1).to(w_all.dtype)
            else:
                w_smooth_all = w_all.to(w_all.dtype)

            all_smooth.append(w_smooth_all)
            offsets.append(0)

        # ---------- 3. Global top-K selection ----------
        if not all_smooth:
            selected_indices = torch.arange(N, device=device)
            return selected_indices, vision_tokens[selected_indices]

        w_smooth_cat = torch.cat(all_smooth, dim=0)  # [M] where M <= N

        # Build global index mapping
        global_indices_list = []
        for off, seg in zip(offsets, all_smooth):
            n_seg = seg.numel()
            global_indices_list.append(torch.arange(off, off + n_seg, device=device))
        global_indices_cat = torch.cat(global_indices_list, dim=0)  # [M]

        # Exclude padding from top-K by masking their scores to -inf
        full_scores = torch.full((N,), float("-inf"), device=device, dtype=w_smooth_cat.dtype)
        full_scores[global_indices_cat] = w_smooth_cat
        full_scores = full_scores.masked_fill(~candidate_mask, float("-inf"))

        _, selected_indices = torch.topk(full_scores, K)
        if self.sort_indices:
            selected_indices = torch.sort(selected_indices).values
        selected_tokens = vision_tokens[selected_indices]
        return selected_indices, selected_tokens
