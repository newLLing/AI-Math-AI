# MMTok: Multimodal Coverage Maximization for Efficient Inference of VLMs
# Paper: https://arxiv.org/abs/2508.18264
# Copyright (c) 2025 Zoom Communications, Inc.
# Licensed under the Apache License, Version 2.0

"""
QA-SpaDiS Selector.

Question-Answer Spatial Diversity Selection (QA-SpaDiS) greedy selector:
1. Compute per-token semantic relevance via cosine similarity to the text query,
   min-max normalised to [0, 1].
2. Build 2D grid positions for spatial topology.
3. Greedily select tokens maximising a weighted sum of semantic relevance and
   spatial diversity (minimum Euclidean distance to already-selected tokens).
"""

import math
from typing import List, Optional, Tuple

import torch
import torch.nn.functional as F


class QASpaDiSSelector:
    """
    QA-SpaDiS greedy vision token selector.

    Selects vision tokens by greedily maximising a score that balances
    query relevance against spatial diversity to already-selected tokens.
    """

    def __init__(
        self,
        target_vision_tokens: int = 64,
        alpha: float = 1.0,
        beta: float = 0.5,
        sort_indices: bool = True,
    ):
        self.target_vision_tokens = target_vision_tokens
        self.alpha = alpha
        self.beta = beta
        self.sort_indices = sort_indices

    @torch.no_grad()
    def mm_coverage_selection(
        self,
        text_token_embedding: torch.Tensor,
        vision_tokens: torch.Tensor,
        vision_tokens_clip: torch.Tensor,
        tv_temp: float = 0.01,
        vv_temp: float = 0.2,
        padding_patch_indices: Optional[List[int]] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Apply QA-SpaDiS greedy selection on vision tokens.

        Args:
            text_token_embedding: [L, D] text token embeddings (question/keywords).
            vision_tokens: [N, D] mm_projector output tokens.
            vision_tokens_clip: Unused (interface compatibility).
            tv_temp: Unused (interface compatibility).
            vv_temp: Unused (interface compatibility).
            padding_patch_indices: Optional list of indices to exclude from selection.

        Returns:
            selected_indices: [K] LongTensor of selected token indices.
            selected_tokens: [K, D] selected vision tokens.
        """
        device = vision_tokens.device
        N = vision_tokens.size(0)
        k = min(self.target_vision_tokens, N)

        if k <= 0:
            selected_indices = torch.empty(0, dtype=torch.long, device=device)
            selected_tokens = torch.empty(
                0, vision_tokens.size(1), device=device, dtype=vision_tokens.dtype
            )
            return selected_indices, selected_tokens
        elif k >= N or N == 0:
            selected_indices = torch.arange(N, device=device)
            return selected_indices, vision_tokens

        # Candidate mask excluding padding patches
        candidate_mask = torch.ones(N, dtype=torch.bool, device=device)
        if padding_patch_indices is not None and len(padding_patch_indices) > 0:
            if isinstance(padding_patch_indices, torch.Tensor):
                pad_idx = padding_patch_indices.to(device)
            else:
                pad_idx = torch.tensor(padding_patch_indices, dtype=torch.long, device=device)
            candidate_mask[pad_idx] = False

        num_eligible = candidate_mask.sum().item()
        if k >= num_eligible:
            selected_indices = torch.where(candidate_mask)[0]
            return selected_indices, vision_tokens[selected_indices]

        # ---------- 1. Text query embedding ----------
        if text_token_embedding is not None and text_token_embedding.numel() > 0:
            q_emb = text_token_embedding.mean(dim=0).to(vision_tokens.dtype)
        else:
            q_emb = torch.zeros(
                vision_tokens.size(1), device=device, dtype=vision_tokens.dtype
            )

        # ---------- 2. Semantic similarity ----------
        vision_norm = F.normalize(vision_tokens, p=2, dim=-1)
        q_norm = F.normalize(q_emb, p=2, dim=0).unsqueeze(0)  # [1, D]
        sim = (vision_norm @ q_norm.T).squeeze(-1)  # [N]

        # Min-max normalise to [0, 1]
        sim_min = sim.min()
        sim_max = sim.max()
        eps = 1e-8
        if sim_max - sim_min < eps:
            sim_norm = torch.ones_like(sim)
        else:
            sim_norm = (sim - sim_min) / (sim_max - sim_min)

        # Mask out padding from similarity consideration (they won't be selected anyway)
        sim_norm = sim_norm.masked_fill(~candidate_mask, float("-inf"))

        # ---------- 3. Spatial topology ----------
        H = int(math.sqrt(N))
        W = (N + H - 1) // H
        if H * W < N:
            H += 1
        rows = torch.arange(H, device=device).unsqueeze(1).expand(H, W).reshape(-1)[:N]
        cols = torch.arange(W, device=device).unsqueeze(0).expand(H, W).reshape(-1)[:N]
        pos = torch.stack([rows, cols], dim=-1).float()  # [N, 2]
        max_dist = math.sqrt((H - 1) ** 2 + (W - 1) ** 2) + eps

        # ---------- 4. Greedy selection (QA-SpaDiS) ----------
        selected = []
        is_remaining = candidate_mask.clone()

        # Initial selection: highest similarity among eligible tokens
        first_idx = sim_norm.argmax().item()
        selected.append(first_idx)
        is_remaining[first_idx] = False

        # Distance to the first selected point
        d_min = torch.norm(pos - pos[first_idx].unsqueeze(0), dim=1)

        for _ in range(1, k):
            cands = torch.where(is_remaining)[0]
            if cands.numel() == 0:
                break

            s_cand = sim_norm[cands]
            # Replace -inf with a very negative number for score computation
            s_cand_valid = s_cand.clone()
            s_cand_valid[s_cand_valid == float("-inf")] = -1e9

            div_cand = d_min[cands] / max_dist
            score = self.alpha * s_cand_valid + self.beta * div_cand

            best_local = score.argmax()
            best_idx = cands[best_local].item()

            selected.append(best_idx)
            is_remaining[best_idx] = False

            # Update d_min with the new selected token
            dist_to_best = torch.norm(pos - pos[best_idx].unsqueeze(0), dim=1)
            d_min = torch.minimum(d_min, dist_to_best)

        selected_indices = torch.tensor(selected, dtype=torch.long, device=device)
        if self.sort_indices:
            selected_indices = torch.sort(selected_indices).values
        selected_tokens = vision_tokens[selected_indices]
        return selected_indices, selected_tokens
