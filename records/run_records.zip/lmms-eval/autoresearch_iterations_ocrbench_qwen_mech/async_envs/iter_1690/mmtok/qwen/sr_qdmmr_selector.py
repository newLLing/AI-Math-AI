# MMTok: Multimodal Coverage Maximization for Efficient Inference of VLMs
# Paper: https://arxiv.org/abs/2508.18264
# Copyright (c) 2025 Zoom Communications, Inc.
# Licensed under the Apache License, Version 2.0

"""
SR-QDMMR Selector: Spatially-Regularized Query-Driven Greedy Maximum Marginal Relevance.

A query-driven MMR vision token selector that balances semantic relevance with
spatial diversity:
1. Compute per-token semantic relevance via cosine similarity to the mean-pooled
   text query embedding.
2. Greedily select tokens. The first token has the highest relevance.
3. Subsequent tokens maximise: α * relevance − β * max_spatial_similarity,
   where max_spatial_similarity is the maximum Gaussian RBF kernel value to any
   already-selected token (computed over normalised 2D spatial coordinates).
"""

import math
from typing import List, Optional, Tuple

import torch
import torch.nn.functional as F


class SRQDMMRSelector:
    """
    Spatially-Regularized Query-Driven Greedy Maximum Marginal Relevance selector.
    """

    def __init__(
        self,
        target_vision_tokens: int = 64,
        alpha: float = 1.0,
        beta: float = 0.5,
        spatial_sigma: float = 0.2,
        sort_indices: bool = True,
    ):
        self.target_vision_tokens = target_vision_tokens
        self.alpha = alpha
        self.beta = beta
        self.spatial_sigma = spatial_sigma
        self.sort_indices = sort_indices

    @torch.no_grad()
    def mm_coverage_selection(
        self,
        text_token_embedding: torch.Tensor,
        vision_tokens: torch.Tensor,
        vision_tokens_clip: torch.Tensor,
        tv_temp: float = 0.01,
        vv_temp: float = 0.2,
        padding_patch_indices: Optional[List[int]] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Apply SR-QDMMR selection on vision tokens.

        Args:
            text_token_embedding: [L, D] text token embeddings (question/keywords).
            vision_tokens: [N, D] mm_projector output tokens.
            vision_tokens_clip: Unused (interface compatibility).
            tv_temp: Unused (interface compatibility).
            vv_temp: Unused (interface compatibility).
            padding_patch_indices: Optional list of indices to exclude from selection.

        Returns:
            selected_indices: [K] LongTensor of selected token indices.
            selected_tokens: [K, D] selected vision tokens.
        """
        device = vision_tokens.device
        N = vision_tokens.size(0)
        k = min(self.target_vision_tokens, N)

        if k <= 0:
            selected_indices = torch.empty(0, dtype=torch.long, device=device)
            selected_tokens = torch.empty(
                0, vision_tokens.size(1), device=device, dtype=vision_tokens.dtype
            )
            return selected_indices, selected_tokens
        elif k >= N or N == 0:
            selected_indices = torch.arange(N, device=device)
            return selected_indices, vision_tokens

        # Candidate mask excluding padding patches
        candidate_mask = torch.ones(N, dtype=torch.bool, device=device)
        if padding_patch_indices is not None and len(padding_patch_indices) > 0:
            if isinstance(padding_patch_indices, torch.Tensor):
                pad_idx = padding_patch_indices.to(device)
            else:
                pad_idx = torch.tensor(padding_patch_indices, dtype=torch.long, device=device)
            candidate_mask[pad_idx] = False

        num_eligible = candidate_mask.sum().item()
        if k >= num_eligible:
            selected_indices = torch.where(candidate_mask)[0]
            return selected_indices, vision_tokens[selected_indices]

        # ---------- 1. Build query embedding and compute relevance ----------
        if text_token_embedding is not None and text_token_embedding.numel() > 0:
            q_emb = text_token_embedding.mean(dim=0)  # [D]
        else:
            q_emb = torch.zeros(vision_tokens.size(1), device=device, dtype=vision_tokens.dtype)

        vis_norm = F.normalize(vision_tokens, p=2, dim=-1)
        q_norm = F.normalize(q_emb, p=2, dim=-1)
        relevance = (vis_norm * q_norm).sum(dim=-1)  # [N]

        # ---------- 2. Build spatial coordinates ----------
        h = int(math.sqrt(N))
        if h * h == N:
            w = h
            grid_y, grid_x = torch.meshgrid(
                torch.arange(h, device=device),
                torch.arange(w, device=device),
                indexing="ij",
            )
            coords = torch.stack([grid_x.flatten(), grid_y.flatten()], dim=-1).float()  # [N, 2]
            max_coord = max(h - 1, w - 1)
            if max_coord > 0:
                coords = coords / max_coord
        else:
            # Fallback: 1-D linear coordinate
            coords = torch.arange(N, device=device, dtype=torch.float).unsqueeze(-1)  # [N, 1]
            if N > 1:
                coords = coords / (N - 1)

        # ---------- 3. Pre-compute pairwise squared distances ----------
        gamma = 1.0 / (2.0 * self.spatial_sigma ** 2)
        dist_sq = torch.cdist(coords.unsqueeze(0), coords.unsqueeze(0)).squeeze(0).pow(2)  # [N, N]

        # ---------- 4. Greedy MMR selection ----------
        selected_idx_list = []
        is_selected = torch.zeros(N, dtype=torch.bool, device=device)

        for i in range(k):
            if i == 0:
                scores = relevance.clone()
                scores = scores.masked_fill(~candidate_mask, float("-inf"))
                best_idx = torch.argmax(scores).item()
            else:
                unselected_mask = ~is_selected
                unselected_indices = torch.where(unselected_mask & candidate_mask)[0]  # [M]

                if unselected_indices.numel() == 0:
                    break

                prev_tensor = torch.tensor(selected_idx_list, dtype=torch.long, device=device)
                d_sq_sel = dist_sq[
                    unselected_indices.unsqueeze(1), prev_tensor.unsqueeze(0)
                ]  # [M, i]
                kernel_vals = torch.exp(-gamma * d_sq_sel)
                max_spatial_sim = torch.max(kernel_vals, dim=1).values  # [M]

                remain_relevance = relevance[unselected_indices]
                scores = self.alpha * remain_relevance - self.beta * max_spatial_sim
                best_local_idx = torch.argmax(scores).item()
                best_idx = unselected_indices[best_local_idx].item()

            selected_idx_list.append(best_idx)
            is_selected[best_idx] = True

        selected_indices = torch.tensor(selected_idx_list, dtype=torch.long, device=device)
        if self.sort_indices:
            selected_indices = torch.sort(selected_indices).values
        selected_tokens = vision_tokens[selected_indices]
        return selected_indices, selected_tokens
