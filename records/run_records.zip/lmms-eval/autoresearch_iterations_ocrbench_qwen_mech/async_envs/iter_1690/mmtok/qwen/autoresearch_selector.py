import torch
import torch.nn.functional as F
from typing import List, Optional, Tuple
from loguru import logger as eval_logger


class AutoResearchSelector:
    """
    Improved greedy subset selector that avoids per-token dilution.

    The baseline normalizes the coverage matrices by the number of text/vision tokens,
    which dilutes the contribution of critical tokens and flattens the gain landscape.
    This version removes that division, preserving the raw strengths so that the
    greedy step can prioritize truly informative vision tokens.
    """

    def __init__(self, target_vision_tokens: int = 32, alpha: float = 0.5):
        self.target_vision_tokens = target_vision_tokens
        self.alpha = alpha

    @staticmethod
    def _l2_normalize(x: torch.Tensor) -> torch.Tensor:
        return x / x.norm(dim=-1, keepdim=True).clamp(min=1e-8)

    def mm_coverage_selection(
        self,
        text_token_embedding: torch.Tensor,
        vision_tokens: torch.Tensor,
        vision_tokens_clip: torch.Tensor,
        tv_temp: float = 0.01,
        vv_temp: float = 0.2,
        padding_patch_indices: Optional[List[int]] = None,
    ) -> Tuple[List[int], torch.Tensor]:
        device = vision_tokens.device
        z_norm = self._l2_normalize(text_token_embedding).float()
        x_norm = self._l2_normalize(vision_tokens).float()
        x_clip_norm = self._l2_normalize(vision_tokens_clip).float()

        # Text-vision coverage
        P = z_norm @ x_norm.T
        # Vision-vision coverage
        Q = x_clip_norm @ x_clip_norm.T

        # Avoid dilution: no division by the number of text/vision tokens
        P = F.softmax(P / tv_temp, dim=1)
        Q = F.softmax(Q / vv_temp, dim=1)

        n = vision_tokens.shape[0]
        m = text_token_embedding.shape[0]
        k_max = min(self.target_vision_tokens, n)
        alpha = self.alpha

        Q_weighted = Q * alpha
        Combined = torch.cat([P, Q_weighted], dim=0)          # [m + n, n]

        best_Combined = torch.zeros(m + n, device=device, dtype=torch.float32)
        score_mask = torch.zeros(n, device=device, dtype=torch.float32)
        if padding_patch_indices is not None:
            exclude = torch.tensor(padding_patch_indices, device=device, dtype=torch.long)
            score_mask[exclude] = float("-inf")

        selected_indices = torch.empty(k_max, dtype=torch.long, device=device)
        neg_inf = float("-inf")

        for i in range(k_max):
            delta = (Combined - best_Combined.unsqueeze(1)).clamp_min(0).sum(dim=0)
            delta += score_mask
            best_idx = torch.argmax(delta)
            selected_indices[i] = best_idx
            best_Combined = torch.maximum(best_Combined, Combined[:, best_idx])
            score_mask[best_idx] = neg_inf

        selected_indices, _ = selected_indices.sort()
        selected_tokens = vision_tokens[selected_indices]
        return selected_indices.tolist(), selected_tokens