from typing import List, Optional, Tuple

import torch
import torch.nn.functional as F
from loguru import logger as eval_logger


class AutoResearchSelectorV10:
    """
    Coverage‑based vision token selector with smoothed text‑vision softmax
    (tv_temp default = 0.07) to encourage broader coverage of text tokens.
    """

    def __init__(self, target_vision_tokens: int = 32, alpha: float = 0.5):
        self.target_vision_tokens = target_vision_tokens
        self.alpha = alpha

    @staticmethod
    def _l2_normalize(x: torch.Tensor) -> torch.Tensor:
        return x / x.norm(dim=-1, keepdim=True).clamp(min=1e-8)

    def mm_coverage_selection(
        self,
        text_token_embedding: torch.Tensor,
        vision_tokens: torch.Tensor,
        vision_tokens_clip: torch.Tensor,
        tv_temp: float = 0.07,  # ← key change: smoother assignment
        vv_temp: float = 0.2,
        padding_patch_indices: Optional[List[int]] = None,
    ) -> Tuple[List[int], torch.Tensor]:
        device = vision_tokens.device

        x_norm = self._l2_normalize(vision_tokens).float()
        x_clip_norm = self._l2_normalize(vision_tokens_clip).float()
        z_norm = self._l2_normalize(text_token_embedding).float()

        m, d = z_norm.shape
        n = x_norm.shape[0]

        # Text–vision coverage matrix P (m x n)
        P = z_norm @ x_norm.T
        # Vision–vision diversity matrix Q (n x n)
        Q = x_clip_norm @ x_clip_norm.T

        P = F.softmax(P / tv_temp, dim=1) / m
        Q = F.softmax(Q / vv_temp, dim=1) / n

        Q_weighted = Q * self.alpha
        Combined = torch.cat([P, Q_weighted], dim=0)  # [m+n, n]

        k_max = min(self.target_vision_tokens, n)

        # Exclusion mask (padding patches)
        if padding_patch_indices is not None:
            exclude_indices = torch.tensor(padding_patch_indices, device=device, dtype=torch.long)
        else:
            exclude_indices = torch.empty(0, dtype=torch.long, device=device)

        score_mask = torch.zeros(n, device=device, dtype=Combined.dtype)
        if exclude_indices.numel() > 0:
            score_mask[exclude_indices] = float("-inf")

        best_combined = torch.zeros(m + n, device=device, dtype=Combined.dtype)
        selected_indices = torch.empty(k_max, dtype=torch.long, device=device)

        for i in range(k_max):
            delta = (Combined - best_combined.unsqueeze(1)).clamp_min_(0).sum(dim=0)
            delta.add_(score_mask)
            best_idx = torch.argmax(delta)
            selected_indices[i] = best_idx
            best_combined = torch.maximum(best_combined, Combined[:, best_idx])
            score_mask[best_idx] = float("-inf")

        selected_indices, _ = selected_indices.sort()
        selected_tokens = vision_tokens[selected_indices]
        return selected_indices.tolist(), selected_tokens