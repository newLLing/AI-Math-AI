# MMTok: Multimodal Coverage Maximization for Efficient Inference of VLMs
# Paper: https://arxiv.org/abs/2508.18264
# Copyright (c) 2025 Zoom Communications, Inc.
# Author: Anonymous
# Licensed under the Apache License, Version 2.0

"""
MMTok core: subset selection of vision tokens under the coverage criterion.

Formulates selection as maximum coverage: a subset of vision tokens is chosen
to cover text tokens (question/keywords) and the original vision token set
simultaneously. Uses mm_coverage_selection (JIT kernel + optional padding exclusion).
"""

import os

import torch
from loguru import logger as eval_logger

from .gram_inv_selector import Iter450GramInvSelector
from .map_selector import MAPKernelSelector
from .blockwise_max_selector import BlockwiseMaxSelector
from .dpp_greedy_selector import DPPGreedySelector
from .grid_region_selector import GridRegionSelector
from .qa_spadis_selector import QASpaDiSSelector
from .hilbert_window_selector import HilbertWindowSelector
from .nahs_dls_selector import NAHSDLSSelector
from .semantic_selector import SemanticTokenSelector
from .spatial_constrained_selector import SpatialConstrainedSelector
from .spatial_semantic_selector import SpatialSemanticSelector
from .spatial_smoothing_selector import SpatialSmoothingSelector
from .spatial_kmeans_selector import SpatialKMeansSelector
from .sr_qdmmr_selector import SRQDMMRSelector
from .dct_smoothing_selector import DCTSmoothingSelector
from .text_processor import VQATextProcessor
from mmtok.core.gots_selector import GOTSSelector
from .autoresearch_v3_c0_selector import AutoResearchSelectorV30
from .autoresearch_v1_c0_selector import AutoResearchSelectorV10
from .autoresearch_v2_c0_selector import AutoResearchSelectorV20
from mmtok.core.autoresearch_selector import AutoResearchSelector

try:
    from transformers import (AutoModelForImageTextToText, AutoProcessor,
                              AutoTokenizer)
except ImportError:
    eval_logger.error("Install transformers: pip install transformers")
    raise


class MMTokCore:
    """
    MMTok core: coverage-based subset selection of vision tokens.

    Uses both vision and text (question/keywords) to select informative
    vision tokens; mm_coverage_selection solves the maximum coverage formulation.
    """

    def __init__(
        self,
        target_vision_tokens=64,
        alpha=0.5,
        softmax_tv_temperature=0.02,
        softmax_vv_temperature=0.2,
        device="cuda",
        remove_padding_indices=False,
        selector_type="semantic",
        **kwargs,
    ):
        self.device = device
        self.target_vision_tokens = target_vision_tokens
        self.alpha = alpha
        self.softmax_tv_temperature = softmax_tv_temperature
        self.softmax_vv_temperature = softmax_vv_temperature
        self.remove_padding_indices = remove_padding_indices
        self.selector_type = selector_type
        self.extra_kwargs = kwargs
        self._init_processors()
        eval_logger.info(
            f"[MMTok] target_vision_tokens={self.target_vision_tokens}"
        )


    def _init_processors(self):
        """Initialize token selector and text processor."""
        if self.selector_type == "iter450":
            self.token_selector = Iter450GramInvSelector(
                target_vision_tokens=self.target_vision_tokens,
            )
            eval_logger.info(f"[MMTok] Using Iter450GramInvSelector (gram_inv_selector)")
        elif self.selector_type == "nahs_dls":
            alpha_0 = self.extra_kwargs.get("alpha_0", 0.7)
            self.token_selector = NAHSDLSSelector(
                target_vision_tokens=self.target_vision_tokens,
                alpha_0=alpha_0,
            )
            eval_logger.info(f"[MMTok] Using NAHSDLSSelector (nahs_dls_selector)")
        elif self.selector_type == "map_kernel":
            gamma = self.extra_kwargs.get("gamma", 0.1)
            beta = self.extra_kwargs.get("beta", 0.1)
            self.token_selector = MAPKernelSelector(
                target_vision_tokens=self.target_vision_tokens,
                gamma=gamma,
                beta=beta,
            )
            eval_logger.info(f"[MMTok] Using MAPKernelSelector (map_selector)")
        elif self.selector_type == "spatial_semantic":
            alpha = self.extra_kwargs.get("alpha", 0.3)
            beta = self.extra_kwargs.get("beta", 1.0)
            self.token_selector = SpatialSemanticSelector(
                target_vision_tokens=self.target_vision_tokens,
                alpha=alpha,
                beta=beta,
            )
            eval_logger.info(f"[MMTok] Using SpatialSemanticSelector (spatial_semantic_selector)")
        elif self.selector_type == "sr_qdmmr":
            alpha = self.extra_kwargs.get("alpha", 1.0)
            beta = self.extra_kwargs.get("beta", 0.5)
            spatial_sigma = self.extra_kwargs.get("spatial_sigma", 0.2)
            self.token_selector = SRQDMMRSelector(
                target_vision_tokens=self.target_vision_tokens,
                alpha=alpha,
                beta=beta,
                spatial_sigma=spatial_sigma,
            )
            eval_logger.info(f"[MMTok] Using SRQDMMRSelector (sr_qdmmr_selector)")
        elif self.selector_type == "spatial_constrained":
            delta = self.extra_kwargs.get("delta", None)
            self.token_selector = SpatialConstrainedSelector(
                target_vision_tokens=self.target_vision_tokens,
                delta=delta,
            )
            eval_logger.info(f"[MMTok] Using SpatialConstrainedSelector (spatial_constrained_selector)")
        elif self.selector_type == "grid_region":
            alpha = self.extra_kwargs.get("alpha", 1.0)
            beta = self.extra_kwargs.get("beta", 0.5)
            self.token_selector = GridRegionSelector(
                target_vision_tokens=self.target_vision_tokens,
                alpha=alpha,
                beta=beta,
            )
            eval_logger.info(f"[MMTok] Using GridRegionSelector (grid_region_selector)")
        elif self.selector_type == "spatial_smoothing":
            T_steps = self.extra_kwargs.get("T_steps", 3)
            lamb = self.extra_kwargs.get("lamb", 0.5)
            self.token_selector = SpatialSmoothingSelector(
                target_vision_tokens=self.target_vision_tokens,
                T_steps=T_steps,
                lamb=lamb,
            )
            eval_logger.info(f"[MMTok] Using SpatialSmoothingSelector (spatial_smoothing_selector)")
        elif self.selector_type == "dpp_greedy":
            tau = self.extra_kwargs.get("tau", 0.1)
            sigma = self.extra_kwargs.get("sigma", 0.5)
            delta_param = self.extra_kwargs.get("delta_param", 0.3)
            eps_jitter = self.extra_kwargs.get("eps_jitter", 1e-6)
            self.token_selector = DPPGreedySelector(
                target_vision_tokens=self.target_vision_tokens,
                tau=tau,
                sigma=sigma,
                delta_param=delta_param,
                eps_jitter=eps_jitter,
            )
            eval_logger.info(f"[MMTok] Using DPPGreedySelector (dpp_greedy_selector)")
        elif self.selector_type == "blockwise_max":
            self.token_selector = BlockwiseMaxSelector(
                target_vision_tokens=self.target_vision_tokens,
            )
            eval_logger.info(f"[MMTok] Using BlockwiseMaxSelector (blockwise_max_selector)")
        elif self.selector_type == "hilbert_window":
            self.token_selector = HilbertWindowSelector(
                target_vision_tokens=self.target_vision_tokens,
            )
            eval_logger.info(f"[MMTok] Using HilbertWindowSelector (hilbert_window_selector)")
        elif self.selector_type == "qa_spadis":
            alpha = self.extra_kwargs.get("alpha", 1.0)
            beta = self.extra_kwargs.get("beta", 0.5)
            self.token_selector = QASpaDiSSelector(
                target_vision_tokens=self.target_vision_tokens,
                alpha=alpha,
                beta=beta,
            )
            eval_logger.info(f"[MMTok] Using QASpaDiSSelector (qa_spadis_selector)")
        elif self.selector_type == "spatial_kmeans":
            self.token_selector = SpatialKMeansSelector(
                target_vision_tokens=self.target_vision_tokens,
            )
            eval_logger.info(f"[MMTok] Using SpatialKMeansSelector (spatial_kmeans_selector)")
        elif self.selector_type == "dct_smoothing":
            self.token_selector = DCTSmoothingSelector(
                target_vision_tokens=self.target_vision_tokens,
            )
            eval_logger.info(f"[MMTok] Using DCTSmoothingSelector (dct_smoothing_selector)")
        elif self.selector_type == "autoresearch_v2_c0":
            self.token_selector = AutoResearchSelectorV20(
                target_vision_tokens=self.target_vision_tokens,
            )
            eval_logger.info(f"[MMTok] Using AutoResearchSelectorV20 (autoresearch_v2_c0_selector)")
        elif self.selector_type == "autoresearch_v1_c0":
            self.token_selector = AutoResearchSelectorV10(
                target_vision_tokens=self.target_vision_tokens,
            )
            eval_logger.info(f"[MMTok] Using AutoResearchSelectorV10 (autoresearch_v1_c0_selector)")
        elif self.selector_type == "autoresearch_v3_c0":
            self.token_selector = AutoResearchSelectorV30(
                target_vision_tokens=self.target_vision_tokens,
            )
            eval_logger.info(f"[MMTok] Using AutoResearchSelectorV30 (autoresearch_v3_c0_selector)")
        elif self.selector_type == "autoresearch":
            self.token_selector = AutoResearchSelector(
                target_vision_tokens=self.target_vision_tokens,
            )
            eval_logger.info(f"[MMTok] Using AutoResearchSelector (autoresearch_selector)")
        elif self.selector_type == "gots":
            self.token_selector = GOTSSelector(
                target_vision_tokens=self.target_vision_tokens,
            )
            eval_logger.info(f"[MMTok] Using GOTSSelector (gots_selector)")
        else:
            self.token_selector = SemanticTokenSelector(
                target_vision_tokens=self.target_vision_tokens,
                alpha=self.alpha,
            )
            eval_logger.info(f"[MMTok] Using SemanticTokenSelector (semantic_selector)")
        self.text_processor = VQATextProcessor(device=self.device)


    def _encode_text_with_token_pooling(self, text: str):
        """
        Encode text (question/keywords) into text token embeddings for coverage.
        Uses LLaVA embed_tokens; batch size must be 1. No BOS.
        """
        enc = self._language_tokenizer(
            text.split(), is_split_into_words=True, return_tensors="pt", padding=True, truncation=True
        )
        input_ids = enc["input_ids"].to(self.device)  # [1, T]
        with torch.no_grad():
            tok_emb = self._main_model_embed_tokens(input_ids)[0]  # [T, D]
        start_idx = 0
        if input_ids.shape[1] > 1 and input_ids[0, 0].item() == self._language_tokenizer.bos_token_id:
            start_idx = 1
        return tok_emb[start_idx:]  # [num_words, hidden_dim]

    def apply_selection(self, mm_projector_features, clip_features, images, question_text, text_embeds=None, padding_patch_indices=None):
        """
        Apply coverage-based subset selection: select vision tokens that cover
        text tokens (question) and the vision token set (multimodal coverage).

        Args:
            mm_projector_features: [batch_size, num_tokens, hidden_dim] (output space)
            clip_features: [batch_size, num_tokens, hidden_dim] (for similarity; CLS stripped if present)
            images: Input images
            question_text: Question string (used to obtain text token embedding)

        Returns:
            selected_features: Selected subset of mm_projector features
            selected_indices: Indices of selected vision tokens
        """
        vision_feat = mm_projector_features
        vision_feat_clip = clip_features
        if vision_feat_clip is not None and vision_feat_clip.shape[1] - vision_feat.shape[1] == 1:
            vision_feat_clip = vision_feat_clip[:, 1:, :]

        text_for_coverage = self.text_processor.extract_keywords_simple(question_text)
        text_token_embedding = self._encode_text_with_token_pooling(text_for_coverage)

        selected_features, selected_indices = self.select_vision_tokens(
            vision_features=vision_feat,
            vision_features_clip=vision_feat_clip,
            text_token_embedding=text_token_embedding,
            padding_patch_indices_list=padding_patch_indices,
        )
        return selected_features, selected_indices

    def select_vision_tokens(
        self,
        vision_features: torch.Tensor,
        vision_features_clip: torch.Tensor,
        text_token_embedding: torch.Tensor,
        padding_patch_indices_list: list = None,
        **kwargs,
    ) -> torch.Tensor:
        """
        Subset selection under maximum coverage: greedy selection of vision tokens
        to cover text tokens (question) and the vision token set.

        Args:
            vision_features: [batch_size, num_tokens, hidden_dim] (mm_projector output, used as selected features)
            vision_features_clip: [batch_size, num_tokens, hidden_dim] (CLIP space for vision–vision coverage/diversity)
            text_token_embedding: Text token embedding (question/keywords) for text–vision coverage
            padding_patch_indices_list: Optional per-image padding patch indices to exclude from selection
            **kwargs: Extra arguments forwarded to the token selector (e.g., image_grid_thw).

        Returns:
            selected_tokens_batch: [batch_size, target_vision_tokens, hidden_dim] selected subset
            selected_indices_list: Per-batch selected indices
        """
        import inspect

        if vision_features.dim() == 2:
            vision_features = vision_features.unsqueeze(0)
        if vision_features_clip.dim() == 2:
            vision_features_clip = vision_features_clip.unsqueeze(0)
        batch_size, num_tokens, hidden_dim = vision_features.shape

        if num_tokens <= self.target_vision_tokens:
            return vision_features, [list(range(num_tokens))] * batch_size

        selected_tokens_list = []
        selected_indices_list = []

        # Inspect selector signature to forward only accepted kwargs
        selector_fn = self.token_selector.mm_coverage_selection
        sig = inspect.signature(selector_fn)
        valid_params = set(sig.parameters.keys())
        filtered_kwargs = {k: v for k, v in kwargs.items() if k in valid_params}

        for batch_idx in range(batch_size):
            vision_tokens = vision_features[batch_idx]
            vision_tokens_clip = vision_features_clip[batch_idx]
            if padding_patch_indices_list is not None and len(padding_patch_indices_list) > 0:
                padding_patch_indices = padding_patch_indices_list[batch_idx]
            else:
                padding_patch_indices = None

            selected_indices, selected_tokens = selector_fn(
                text_token_embedding=text_token_embedding,
                vision_tokens=vision_tokens,
                vision_tokens_clip=vision_tokens_clip,
                tv_temp=self.softmax_tv_temperature,
                vv_temp=self.softmax_vv_temperature,
                padding_patch_indices=padding_patch_indices,
                **filtered_kwargs,
            )
            selected_tokens_list.append(selected_tokens)
            selected_indices_list.append(selected_indices)

        selected_tokens_batch = torch.stack(selected_tokens_list, dim=0)

        return selected_tokens_batch, selected_indices_list

    def apply_selection_preprocess_qwen(self, image_embeds, image_features, question_text, target_vision_tokens=None, image_grid_thw=None):
        """
        Coverage-based subset selection for Qwen2.5-VL: select vision tokens
        to cover text (question only, or question+answer if provided) and vision set. Single-sample path.

        Args:
            image_embeds: [num_image_tokens, hidden_dim] mm_projector output
            image_features: CLIP features for vision–vision coverage
            question_text: Question string
            answer_text: Optional answer text (for compatibility; when no scout, use question only)
            target_vision_tokens: Target subset size (uses self.token_selector.target_vision_tokens if None)
            image_grid_thw: [num_images, 3] grid shape (temporal, height, width) for each image

        Returns:
            selected_indices: Indices of selected vision tokens
            selected_features: Selected subset of image features (single sample)
        """
        if target_vision_tokens is not None:
            self.token_selector.target_vision_tokens = target_vision_tokens

        text_for_embedding = f"Question: {question_text}"
        if getattr(self, "clean_text", False):
            text_for_embedding = self.text_processor.extract_keywords_simple(text_for_embedding)

        text_token_embedding = self._encode_text_with_token_pooling(text_for_embedding)
        selected_features, selected_indices = self.select_vision_tokens(
            vision_features=image_embeds,
            vision_features_clip=image_features,
            text_token_embedding=text_token_embedding,
            image_grid_thw=image_grid_thw,
        )
        return selected_indices[0], selected_features[0]
