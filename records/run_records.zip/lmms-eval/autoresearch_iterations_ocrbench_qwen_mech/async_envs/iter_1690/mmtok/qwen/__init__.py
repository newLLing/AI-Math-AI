# MMTok: Multimodal Coverage Maximization for Efficient Inference of VLMs
# Paper: https://arxiv.org/abs/2508.18264
# Copyright (c) 2025 Zoom Communications, Inc.
# Author: Anonymous
# Licensed under the Apache License, Version 2.0

"""
MMTok core: coverage-based subset selection, token selector, and text processing.
"""

from .gram_inv_selector import Iter450GramInvSelector
from .map_selector import MAPKernelSelector
from .mmtok_core import MMTokCore
from .nahs_dls_selector import NAHSDLSSelector
from .semantic_selector import SemanticTokenSelector, greedy_merged_jit_kernel
from .blockwise_max_selector import BlockwiseMaxSelector
from .dpp_greedy_selector import DPPGreedySelector
from .grid_region_selector import GridRegionSelector
from .qa_spadis_selector import QASpaDiSSelector
from .hilbert_window_selector import HilbertWindowSelector
from .spatial_constrained_selector import SpatialConstrainedSelector
from .spatial_kmeans_selector import SpatialKMeansSelector
from .spatial_semantic_selector import SpatialSemanticSelector
from .spatial_smoothing_selector import SpatialSmoothingSelector
from .sr_qdmmr_selector import SRQDMMRSelector
from .dct_smoothing_selector import DCTSmoothingSelector
from .text_processor import VQATextProcessor

from .autoresearch_v2_c0_selector import AutoResearchSelectorV20
from .autoresearch_v1_c0_selector import AutoResearchSelectorV10
from .autoresearch_v3_c0_selector import AutoResearchSelectorV30
from .autoresearch_selector import AutoResearchSelector
