# MMTok: Multimodal Coverage Maximization for Efficient Inference of VLMs
# Paper: https://arxiv.org/abs/2508.18264
# Copyright (c) 2025 Zoom Communications, Inc.
# Licensed under the Apache License, Version 2.0

"""
Spatial Smoothing Selector.

Diffuses per-token semantic relevance scores over a 2D spatial grid via
iterative cross-shaped kernel smoothing, then selects top-K tokens:
1. Compute cosine similarity between vision tokens and mean-pooled text query.
2. Reshape scores to a 2D spatial grid (inferred from N or via grid metadata).
3. Iteratively smooth the score map with a 3x3 cross kernel
   (center + 4 cardinals, weights 0.2 each).
4. Select the top-K tokens from the smoothed map.
   If no valid 2D grid can be formed, fall back to raw semantic scores.
"""

import math
from typing import List, Optional, Tuple

import torch
import torch.nn.functional as F


class SpatialSmoothingSelector:
    """
    Spatial smoothing vision token selector.
    """

    def __init__(
        self,
        target_vision_tokens: int = 64,
        T_steps: int = 3,
        lamb: float = 0.5,
        sort_indices: bool = True,
    ):
        self.target_vision_tokens = target_vision_tokens
        self.T_steps = T_steps
        self.lamb = lamb
        self.sort_indices = sort_indices

    @torch.no_grad()
    def mm_coverage_selection(
        self,
        text_token_embedding: torch.Tensor,
        vision_tokens: torch.Tensor,
        vision_tokens_clip: torch.Tensor,
        tv_temp: float = 0.01,
        vv_temp: float = 0.2,
        padding_patch_indices: Optional[List[int]] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Apply spatial smoothing selection on vision tokens.

        Args:
            text_token_embedding: [L, D] text token embeddings (question/keywords).
            vision_tokens: [N, D] mm_projector output tokens.
            vision_tokens_clip: Unused (interface compatibility).
            tv_temp: Unused (interface compatibility).
            vv_temp: Unused (interface compatibility).
            padding_patch_indices: Optional list of indices to exclude from selection.

        Returns:
            selected_indices: [K] LongTensor of selected token indices.
            selected_tokens: [K, D] selected vision tokens.
        """
        device = vision_tokens.device
        N = vision_tokens.size(0)
        k = min(self.target_vision_tokens, N)

        if k <= 0:
            selected_indices = torch.empty(0, dtype=torch.long, device=device)
            selected_tokens = torch.empty(
                0, vision_tokens.size(1), device=device, dtype=vision_tokens.dtype
            )
            return selected_indices, selected_tokens
        elif k >= N or N == 0:
            selected_indices = torch.arange(N, device=device)
            return selected_indices, vision_tokens

        # Candidate mask excluding padding patches
        candidate_mask = torch.ones(N, dtype=torch.bool, device=device)
        if padding_patch_indices is not None and len(padding_patch_indices) > 0:
            if isinstance(padding_patch_indices, torch.Tensor):
                pad_idx = padding_patch_indices.to(device)
            else:
                pad_idx = torch.tensor(padding_patch_indices, dtype=torch.long, device=device)
            candidate_mask[pad_idx] = False

        num_eligible = candidate_mask.sum().item()
        if k >= num_eligible:
            selected_indices = torch.where(candidate_mask)[0]
            return selected_indices, vision_tokens[selected_indices]

        k = min(k, num_eligible)

        # ---------- 1. Query embedding and cosine similarity ----------
        if text_token_embedding is not None and text_token_embedding.numel() > 0:
            q_emb = text_token_embedding.float().mean(dim=0)  # [D]
        else:
            q_emb = torch.zeros(vision_tokens.size(1), device=device, dtype=torch.float32)

        v_norm = F.normalize(vision_tokens.float(), p=2, dim=1, eps=1e-8)
        q_norm = F.normalize(q_emb, p=2, dim=0, eps=1e-8)
        s = v_norm @ q_norm  # [N]

        # ---------- 2. Try to reshape to 2D spatial grid ----------
        def nearest_square_grid(num: int) -> Tuple[int, int]:
            for d in range(int(math.isqrt(num)), 0, -1):
                if num % d == 0:
                    return d, num // d
            return 1, num

        spatial_shape = None
        h = int(N ** 0.5)
        if h * h == N:
            spatial_shape = (h, h)
        else:
            H, W = nearest_square_grid(N)
            # Only use non-square grid if it's reasonably close to square
            # (avoid extremely thin rectangles which break spatial meaning)
            if H >= 2 and W >= 2 and max(H, W) / max(min(H, W), 1) <= 4:
                spatial_shape = (H, W)

        # ---------- 3. Spatial smoothing or fallback ----------
        if spatial_shape is not None:
            H, W = spatial_shape
            g_2d = s.view(1, 1, H, W)
            # 3x3 cross kernel: center + 4 cardinals, each weight 0.2
            kernel = torch.tensor(
                [[[[0.0, 0.2, 0.0],
                   [0.2, 0.2, 0.2],
                   [0.0, 0.2, 0.0]]]],
                device=device, dtype=torch.float32,
            )
            for _ in range(self.T_steps):
                smoothed = F.conv2d(g_2d, kernel, padding=1)
                g_2d = (1 - self.lamb) * g_2d + self.lamb * smoothed
            g = g_2d.view(N)
        else:
            g = s

        # Exclude padding from selection
        g = g.masked_fill(~candidate_mask, float("-inf"))

        # ---------- 4. Select top-K ----------
        _, selected_indices = torch.topk(g, k)
        if self.sort_indices:
            selected_indices = torch.sort(selected_indices).values
        selected_tokens = vision_tokens[selected_indices]
        return selected_indices, selected_tokens
