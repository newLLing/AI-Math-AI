# MMTok: Multimodal Coverage Maximization for Efficient Inference of VLMs
# Paper: https://arxiv.org/abs/2508.18264
# Copyright (c) 2025 Zoom Communications, Inc.
# Licensed under the Apache License, Version 2.0

"""
Blockwise-Max Selector.

Partitions the vision token sequence (assumed row-major raster order) into K
contiguous blocks and selects the token with highest query similarity within
each block. This naturally enforces spatial coverage because each block covers
a distinct contiguous region of the image.
"""

from typing import List, Optional, Tuple

import torch
import torch.nn.functional as F


class BlockwiseMaxSelector:
    """
    Blockwise-max vision token selector.
    """

    def __init__(
        self,
        target_vision_tokens: int = 64,
        sort_indices: bool = True,
    ):
        self.target_vision_tokens = target_vision_tokens
        self.sort_indices = sort_indices

    @torch.no_grad()
    def mm_coverage_selection(
        self,
        text_token_embedding: torch.Tensor,
        vision_tokens: torch.Tensor,
        vision_tokens_clip: torch.Tensor,
        tv_temp: float = 0.01,
        vv_temp: float = 0.2,
        padding_patch_indices: Optional[List[int]] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Apply blockwise-max selection on vision tokens.

        Args:
            text_token_embedding: [L, D] text token embeddings (question/keywords).
            vision_tokens: [N, D] mm_projector output tokens.
            vision_tokens_clip: Unused (interface compatibility).
            tv_temp: Unused (interface compatibility).
            vv_temp: Unused (interface compatibility).
            padding_patch_indices: Optional list of indices to exclude from selection.

        Returns:
            selected_indices: [K] LongTensor of selected token indices.
            selected_tokens: [K, D] selected vision tokens.
        """
        device = vision_tokens.device
        N = vision_tokens.size(0)
        k = min(self.target_vision_tokens, N)

        if k <= 0:
            selected_indices = torch.empty(0, dtype=torch.long, device=device)
            selected_tokens = torch.empty(
                0, vision_tokens.size(1), device=device, dtype=vision_tokens.dtype
            )
            return selected_indices, selected_tokens
        elif k >= N or N == 0:
            selected_indices = torch.arange(N, device=device)
            return selected_indices, vision_tokens

        # Candidate mask excluding padding patches
        candidate_mask = torch.ones(N, dtype=torch.bool, device=device)
        if padding_patch_indices is not None and len(padding_patch_indices) > 0:
            if isinstance(padding_patch_indices, torch.Tensor):
                pad_idx = padding_patch_indices.to(device)
            else:
                pad_idx = torch.tensor(padding_patch_indices, dtype=torch.long, device=device)
            candidate_mask[pad_idx] = False

        num_eligible = candidate_mask.sum().item()
        if k >= num_eligible:
            selected_indices = torch.where(candidate_mask)[0]
            return selected_indices, vision_tokens[selected_indices]

        k = min(k, num_eligible)

        # ---------- 1. Query embedding and alignment scores ----------
        if text_token_embedding is not None and text_token_embedding.numel() > 0:
            q = text_token_embedding.mean(dim=0)  # [D]
        else:
            q = torch.zeros(vision_tokens.size(1), device=device, dtype=vision_tokens.dtype)

        vision_norm = F.normalize(vision_tokens, p=2, dim=1, eps=1e-8)
        q_norm = F.normalize(q, p=2, dim=0, eps=1e-8)
        align_scores = torch.matmul(vision_norm, q_norm.to(vision_tokens.dtype))  # [N]

        # Mask padding scores to -inf so they are never argmax-ed
        align_scores = align_scores.masked_fill(~candidate_mask, float("-inf"))

        # ---------- 2. Partition into K contiguous blocks ----------
        sizes = torch.full((k,), N // k, dtype=torch.long, device=device)
        remainder = N % k
        if remainder > 0:
            sizes[:remainder] += 1

        cumsum = torch.cumsum(sizes, dim=0)
        starts = torch.cat([torch.tensor([0], device=device), cumsum[:-1]])
        ends = cumsum

        # ---------- 3. Select max from each block ----------
        selected_idx_list = []
        for j in range(k):
            start = starts[j].item()
            end = ends[j].item()
            if end <= start:
                continue
            block_scores = align_scores[start:end]
            # If the entire block is padding, argmax returns the first element.
            # We filter those out afterwards.
            max_in_block = torch.argmax(block_scores)
            selected_idx_list.append(start + max_in_block.item())

        selected_indices = torch.tensor(selected_idx_list, dtype=torch.long, device=device)

        # Safety: filter out any padding tokens that might have been selected
        # from all-padding blocks
        selected_indices = selected_indices[candidate_mask[selected_indices]]

        # Fallback: if we ended up with fewer than k tokens, fill with top
        # remaining eligible tokens globally.
        if selected_indices.numel() < k:
            remaining_mask = candidate_mask.clone()
            remaining_mask[selected_indices] = False
            remaining_indices = torch.where(remaining_mask)[0]
            remaining_scores = align_scores[remaining_indices]
            fill_k = k - selected_indices.numel()
            fill_order = torch.topk(remaining_scores, min(fill_k, remaining_indices.numel())).indices
            fill_indices = remaining_indices[fill_order]
            selected_indices = torch.cat([selected_indices, fill_indices])

        if self.sort_indices:
            selected_indices = torch.sort(selected_indices).values
        selected_tokens = vision_tokens[selected_indices]
        return selected_indices, selected_tokens
