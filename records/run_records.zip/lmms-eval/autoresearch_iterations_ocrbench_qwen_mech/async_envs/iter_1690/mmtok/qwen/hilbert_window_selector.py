# MMTok: Multimodal Coverage Maximization for Efficient Inference of VLMs
# Paper: https://arxiv.org/abs/2508.18264
# Copyright (c) 2025 Zoom Communications, Inc.
# Licensed under the Apache License, Version 2.0

"""
Hilbert-Window Selector.

Arranges vision tokens along a Hilbert space-filling curve over their 2D spatial
grid, then selects the contiguous window of K tokens with the highest aggregate
query similarity. This balances spatial coverage with semantic relevance by
favouring compact spatial regions that are collectively relevant to the query.
"""

from typing import List, Optional, Tuple

import torch
import torch.nn.functional as F


def _hilbert_index(x: int, y: int, order: int) -> int:
    """Compute Hilbert curve index for grid coordinate (x, y)."""
    d = 0
    s = 1
    size = 1 << order
    while s < size:
        rx = (x & s) > 0
        ry = (y & s) > 0
        d += s * s * ((3 * rx) ^ ry)
        if ry == 0:
            if rx == 1:
                x = size - 1 - x
                y = size - 1 - y
            x, y = y, x
        s <<= 1
    return d


def _hilbert_perm(H: int, W: int, device: torch.device) -> torch.Tensor:
    """
    Return a permutation tensor that maps row-major indices to Hilbert order.

    Args:
        H: Grid height.
        W: Grid width.
        device: Torch device.

    Returns:
        perm: [H*W] LongTensor where perm[i] is the row-major index of the
              i-th token in Hilbert order.
    """
    order = max(H, W).bit_length()
    x_coords = torch.arange(H, device=device).unsqueeze(1).expand(-1, W).reshape(-1)
    y_coords = torch.arange(W, device=device).unsqueeze(0).expand(H, -1).reshape(-1)
    indices = [_hilbert_index(int(xi), int(yi), order) for xi, yi in zip(x_coords.tolist(), y_coords.tolist())]
    idx_tensor = torch.tensor(indices, dtype=torch.long, device=device)
    perm = torch.argsort(idx_tensor)
    return perm


def _nearest_square_grid(num: int) -> Tuple[int, int]:
    """Find the most square-like factorization of num."""
    best_h, best_w = 1, num
    min_diff = float("inf")
    sqrt_n = int(num ** 0.5)
    for h in range(1, sqrt_n + 1):
        if num % h == 0:
            w = num // h
            diff = abs(h - w)
            if diff < min_diff:
                min_diff = diff
                best_h, best_w = h, w
    return best_h, best_w


class HilbertWindowSelector:
    """
    Hilbert-window vision token selector.
    """

    def __init__(
        self,
        target_vision_tokens: int = 64,
        sort_indices: bool = True,
    ):
        self.target_vision_tokens = target_vision_tokens
        self.sort_indices = sort_indices

    @torch.no_grad()
    def mm_coverage_selection(
        self,
        text_token_embedding: torch.Tensor,
        vision_tokens: torch.Tensor,
        vision_tokens_clip: torch.Tensor,
        tv_temp: float = 0.01,
        vv_temp: float = 0.2,
        padding_patch_indices: Optional[List[int]] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Apply Hilbert-window selection on vision tokens.

        Args:
            text_token_embedding: [L, D] text token embeddings (question/keywords).
            vision_tokens: [N, D] mm_projector output tokens.
            vision_tokens_clip: Unused (interface compatibility).
            tv_temp: Unused (interface compatibility).
            vv_temp: Unused (interface compatibility).
            padding_patch_indices: Optional list of indices to exclude from selection.

        Returns:
            selected_indices: [K] LongTensor of selected token indices.
            selected_tokens: [K, D] selected vision tokens.
        """
        device = vision_tokens.device
        N = vision_tokens.size(0)
        k = min(self.target_vision_tokens, N)

        if k <= 0:
            selected_indices = torch.empty(0, dtype=torch.long, device=device)
            selected_tokens = torch.empty(
                0, vision_tokens.size(1), device=device, dtype=vision_tokens.dtype
            )
            return selected_indices, selected_tokens
        elif k >= N or N == 0:
            selected_indices = torch.arange(N, device=device)
            return selected_indices, vision_tokens

        # Candidate mask excluding padding patches
        candidate_mask = torch.ones(N, dtype=torch.bool, device=device)
        if padding_patch_indices is not None and len(padding_patch_indices) > 0:
            if isinstance(padding_patch_indices, torch.Tensor):
                pad_idx = padding_patch_indices.to(device)
            else:
                pad_idx = torch.tensor(padding_patch_indices, dtype=torch.long, device=device)
            candidate_mask[pad_idx] = False

        num_eligible = candidate_mask.sum().item()
        if k >= num_eligible:
            selected_indices = torch.where(candidate_mask)[0]
            return selected_indices, vision_tokens[selected_indices]

        k = min(k, num_eligible)

        # ---------- 1. Text query and similarity scores ----------
        if text_token_embedding is not None and text_token_embedding.numel() > 0:
            q_emb = text_token_embedding.mean(dim=0)
        else:
            q_emb = torch.zeros(vision_tokens.size(1), device=device, dtype=vision_tokens.dtype)

        vision_norm = F.normalize(vision_tokens, p=2, dim=1, eps=1e-8)
        q_norm = F.normalize(q_emb, p=2, dim=0, eps=1e-8)
        scores = torch.matmul(vision_norm, q_norm.to(vision_tokens.dtype))  # [N]

        # Mask padding so they don't contribute to window sums
        scores = scores.masked_fill(~candidate_mask, float("-inf"))

        # ---------- 2. Infer grid and Hilbert permutation ----------
        H, W = _nearest_square_grid(N)
        hilbert_perm = _hilbert_perm(H, W, device)

        # ---------- 3. Sliding window along Hilbert curve ----------
        scores_sorted = scores[hilbert_perm]  # [N]
        cum_scores = torch.cat([
            torch.zeros(1, device=device, dtype=scores_sorted.dtype),
            torch.cumsum(scores_sorted, dim=0),
        ])  # [N+1]
        window_sums = cum_scores[k:] - cum_scores[:-k]  # [N-k+1]

        best_start = torch.argmax(window_sums).item()
        selected_indices = hilbert_perm[best_start : best_start + k]

        # Safety: filter padding tokens (shouldn't happen unless window is all padding)
        selected_indices = selected_indices[candidate_mask[selected_indices]]

        # Fallback if padding caused us to drop below k
        if selected_indices.numel() < k:
            remaining_mask = candidate_mask.clone()
            remaining_mask[selected_indices] = False
            remaining_indices = torch.where(remaining_mask)[0]
            remaining_scores = scores[remaining_indices]
            fill_k = k - selected_indices.numel()
            fill_order = torch.topk(remaining_scores, min(fill_k, remaining_indices.numel())).indices
            fill_indices = remaining_indices[fill_order]
            selected_indices = torch.cat([selected_indices, fill_indices])

        if self.sort_indices:
            selected_indices = torch.sort(selected_indices).values
        selected_tokens = vision_tokens[selected_indices]
        return selected_indices, selected_tokens
