# MMTok: Multimodal Coverage Maximization for Efficient Inference of VLMs
# Paper: https://arxiv.org/abs/2508.18264
# Copyright (c) 2025 Zoom Communications, Inc.
# Licensed under the Apache License, Version 2.0

"""
Spatial-Semantic Greedy Selector.

A relevance-first vision token selector that penalises spatial redundancy:
1. Compute per-token semantic relevance via cosine similarity to the text query.
2. Greedily select tokens maximising relevance minus an accumulated
   spatial-semantic redundancy penalty.
3. The redundancy penalty combines an RBF spatial kernel and absolute
   semantic similarity to already-selected tokens.
"""

import math
from typing import List, Optional, Tuple

import torch
import torch.nn.functional as F


class SpatialSemanticSelector:
    """
    Spatial-semantic greedy vision token selector.

    Selects vision tokens by greedily maximising a score that balances
    query relevance against spatial and semantic redundancy.
    """

    def __init__(
        self,
        target_vision_tokens: int = 64,
        alpha: float = 0.3,
        beta: float = 1.0,
        sort_indices: bool = True,
    ):
        self.target_vision_tokens = target_vision_tokens
        self.alpha = alpha
        self.beta = beta
        self.sort_indices = sort_indices

    @torch.no_grad()
    def mm_coverage_selection(
        self,
        text_token_embedding: torch.Tensor,
        vision_tokens: torch.Tensor,
        vision_tokens_clip: torch.Tensor,
        tv_temp: float = 0.01,
        vv_temp: float = 0.2,
        padding_patch_indices: Optional[List[int]] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Apply spatial-semantic greedy selection on vision tokens.

        Args:
            text_token_embedding: [L, D] text token embeddings (question/keywords).
            vision_tokens: [N, D] mm_projector output tokens.
            vision_tokens_clip: Unused (interface compatibility).
            tv_temp: Unused (interface compatibility).
            vv_temp: Unused (interface compatibility).
            padding_patch_indices: Optional list of indices to exclude from selection.

        Returns:
            selected_indices: [K] LongTensor of selected token indices.
            selected_tokens: [K, D] selected vision tokens.
        """
        device = vision_tokens.device
        N = vision_tokens.size(0)
        k = min(self.target_vision_tokens, N)

        if k <= 0:
            selected_indices = torch.empty(0, dtype=torch.long, device=device)
            selected_tokens = torch.empty(
                0, vision_tokens.size(1), device=device, dtype=vision_tokens.dtype
            )
            return selected_indices, selected_tokens
        elif k >= N or N == 0:
            selected_indices = torch.arange(N, device=device)
            return selected_indices, vision_tokens

        # Candidate mask excluding padding patches
        candidate_mask = torch.ones(N, dtype=torch.bool, device=device)
        if padding_patch_indices is not None and len(padding_patch_indices) > 0:
            if isinstance(padding_patch_indices, torch.Tensor):
                pad_idx = padding_patch_indices.to(device)
            else:
                pad_idx = torch.tensor(padding_patch_indices, dtype=torch.long, device=device)
            candidate_mask[pad_idx] = False

        num_eligible = candidate_mask.sum().item()
        if k >= num_eligible:
            selected_indices = torch.where(candidate_mask)[0]
            return selected_indices, vision_tokens[selected_indices]

        # ---------- 1. L2 normalise vision embeddings ----------
        vision_normed = F.normalize(vision_tokens, p=2, dim=-1, eps=1e-8)

        # ---------- 2. Aggregate text query and normalise ----------
        if text_token_embedding is not None and text_token_embedding.numel() > 0:
            q_agg = text_token_embedding.mean(dim=0)
            q_normed = F.normalize(q_agg, p=2, dim=-1, eps=1e-8)
        else:
            q_normed = torch.zeros(
                vision_tokens.size(1), device=device, dtype=vision_tokens.dtype
            )

        # ---------- 3. Per-token semantic relevance scores ----------
        relevance_scores = torch.matmul(vision_normed, q_normed)  # (N,)

        # ---------- 4. Infer 2D spatial grid dimensions ----------
        side = int(math.isqrt(N))
        if side * side == N:
            H, W = side, side
        else:
            H = int(math.sqrt(N))
            while N % H != 0:
                H -= 1
                if H == 0:
                    H = 1
                    break
            W = N // H

        # Coordinate grid for spatial positions
        row_coords = (
            torch.arange(H, device=device, dtype=vision_tokens.dtype)
            .unsqueeze(1)
            .expand(H, W)
            .reshape(-1)[:N]
        )
        col_coords = (
            torch.arange(W, device=device, dtype=vision_tokens.dtype)
            .unsqueeze(0)
            .expand(H, W)
            .reshape(-1)[:N]
        )
        spatial_coords = torch.stack([row_coords, col_coords], dim=-1)  # (N, 2)

        # ---------- 5. Greedy spatial-semantic token selection ----------
        selected = []
        is_selected = torch.zeros(N, dtype=torch.bool, device=device)
        accumulated_penalty = torch.zeros(N, dtype=vision_tokens.dtype, device=device)

        for i in range(k):
            if i == 0:
                candidate_scores = relevance_scores.clone()
            else:
                redundancy = accumulated_penalty / i
                candidate_scores = relevance_scores - self.alpha * redundancy

            # Exclude already selected and padding tokens
            candidate_scores = candidate_scores.masked_fill(is_selected, float("-inf"))
            candidate_scores = candidate_scores.masked_fill(~candidate_mask, float("-inf"))

            if torch.all(torch.isinf(candidate_scores)) or torch.all(torch.isnan(candidate_scores)):
                break

            best_idx = torch.argmax(candidate_scores).item()
            selected.append(best_idx)
            is_selected[best_idx] = True

            # Update running penalty for next iterations
            if i < k - 1:
                delta_p = spatial_coords - spatial_coords[best_idx]  # (N, 2)
                dist_sq = (delta_p ** 2).sum(dim=-1)  # (N,)
                spatial_kernel = torch.exp(-self.beta * dist_sq)  # (N,)
                sem_sim = torch.abs(
                    torch.matmul(vision_normed, vision_normed[best_idx])
                )  # (N,)
                spatial_sem_product = spatial_kernel * sem_sim
                accumulated_penalty = accumulated_penalty + spatial_sem_product

        selected_indices = torch.tensor(selected, dtype=torch.long, device=device)
        if self.sort_indices:
            selected_indices = torch.sort(selected_indices).values
        selected_tokens = vision_tokens[selected_indices]
        return selected_indices, selected_tokens
