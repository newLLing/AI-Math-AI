# MMTok: Multimodal Coverage Maximization for Efficient Inference of VLMs
# Paper: https://arxiv.org/abs/2508.18264
# Copyright (c) 2025 Zoom Communications, Inc.
# Licensed under the Apache License, Version 2.0

"""
MAP Kernel Selector: Greedy MAP (Maximum A Posteriori) subset selection with
relevance-weighted RBF kernels over vision features and spatial positions.

1. Compute query-relevance scores via cosine similarity between vision tokens
   and aggregated text embedding.
2. Build combined RBF kernel (feature + spatial) weighted by relevance.
3. Greedily select tokens maximizing the determinant gain via incremental
   block-matrix inversion.
"""

import math
from typing import List, Optional, Tuple

import torch
import torch.nn.functional as F


class MAPKernelSelector:
    """
    MAP kernel-based greedy vision token selector.

    Selects vision tokens using a relevance-weighted kernel matrix and greedy
    determinant maximization (approximating MAP inference).
    """

    def __init__(
        self,
        target_vision_tokens: int = 64,
        gamma: float = 0.1,
        beta: float = 0.1,
        jitter: float = 1e-6,
        sort_indices: bool = True,
    ):
        self.target_vision_tokens = target_vision_tokens
        self.gamma = gamma
        self.beta = beta
        self.jitter = jitter
        self.sort_indices = sort_indices

    @torch.no_grad()
    def mm_coverage_selection(
        self,
        text_token_embedding: torch.Tensor,
        vision_tokens: torch.Tensor,
        vision_tokens_clip: torch.Tensor,
        tv_temp: float = 0.01,
        vv_temp: float = 0.2,
        padding_patch_indices: Optional[List[int]] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Apply MAP kernel greedy selection on vision tokens.

        Args:
            text_token_embedding: [L, D] text token embeddings (question/keywords).
            vision_tokens: [N, D] mm_projector output tokens.
            vision_tokens_clip: Unused (interface compatibility).
            tv_temp: Unused (interface compatibility).
            vv_temp: Unused (interface compatibility).
            padding_patch_indices: Optional list of indices to exclude from selection.

        Returns:
            selected_indices: [K] LongTensor of selected token indices.
            selected_tokens: [K, D] selected vision tokens.
        """
        device = vision_tokens.device
        N = vision_tokens.size(0)
        k = min(self.target_vision_tokens, N)

        if k <= 0:
            selected_indices = torch.empty(0, dtype=torch.long, device=device)
            selected_tokens = torch.empty(
                0, vision_tokens.size(1), device=device, dtype=vision_tokens.dtype
            )
            return selected_indices, selected_tokens
        elif k >= N or N == 0:
            selected_indices = torch.arange(N, device=device)
            return selected_indices, vision_tokens

        # Candidate mask excluding padding patches
        candidate_mask = torch.ones(N, dtype=torch.bool, device=device)
        if padding_patch_indices is not None and len(padding_patch_indices) > 0:
            if isinstance(padding_patch_indices, torch.Tensor):
                pad_idx = padding_patch_indices.to(device)
            else:
                pad_idx = torch.tensor(padding_patch_indices, dtype=torch.long, device=device)
            candidate_mask[pad_idx] = False

        num_eligible = candidate_mask.sum().item()
        if k >= num_eligible:
            selected_indices = torch.where(candidate_mask)[0]
            return selected_indices, vision_tokens[selected_indices]

        # ---------- 1. L2 normalise tokens and text embedding ----------
        vision_norm = F.normalize(vision_tokens, p=2, dim=1).float()

        if text_token_embedding is not None and text_token_embedding.numel() > 0:
            text_agg = text_token_embedding.float().mean(dim=0)
            text_agg = F.normalize(text_agg, p=2, dim=0).float()
        else:
            # Fallback: zero relevance if no text provided
            text_agg = torch.zeros(vision_tokens.size(1), device=device, dtype=torch.float32)

        # ---------- 2. Compute query-relevance scores ----------
        relevance = F.cosine_similarity(vision_norm, text_agg.unsqueeze(0), dim=-1).clamp(min=0.0)

        # ---------- 3. Build spatial positions (normalised to [0,1]^2) ----------
        H = int(math.isqrt(N))
        while N % H != 0:
            H -= 1
            if H == 0:
                H = 1
                break
        W = N // H

        ys = torch.arange(H, device=device).float()
        xs = torch.arange(W, device=device).float()
        grid_y, grid_x = torch.meshgrid(ys, xs, indexing="ij")
        grid_y = grid_y.reshape(-1) / max(H - 1, 1)
        grid_x = grid_x.reshape(-1) / max(W - 1, 1)
        spatial_positions = torch.stack([grid_y, grid_x], dim=1)  # (N, 2)

        # ---------- 4. Build kernel matrix L ----------
        # Feature RBF kernel
        dist_sq = torch.cdist(vision_norm.unsqueeze(0), vision_norm.unsqueeze(0)).squeeze(0)
        K_feat = torch.exp(-self.gamma * dist_sq)

        # Spatial RBF kernel
        spat_diff = spatial_positions.unsqueeze(0) - spatial_positions.unsqueeze(1)
        spat_dist_sq = (spat_diff ** 2).sum(dim=-1)
        K_spat = torch.exp(-self.beta * spat_dist_sq)

        # Combine and apply relevance
        K_combined = K_feat * K_spat
        R = torch.diag(relevance)
        L = R @ K_combined @ R

        # Symmetrise and add jitter for PSD stability
        L = 0.5 * (L + L.T)
        L.diagonal().add_(self.jitter)

        # ---------- 5. Greedy MAP subset selection ----------
        selected = []
        selected_mask = torch.zeros(N, dtype=torch.bool, device=device)
        L_inv_S = None

        for _ in range(k):
            if L_inv_S is None:
                gains = L.diagonal().clone()
            else:
                sel_idx = torch.tensor(selected, dtype=torch.long, device=device)
                L_i_S = L[:, sel_idx]
                A = L_i_S @ L_inv_S
                quad = torch.sum(A * L_i_S, dim=1)
                gains = L.diagonal() - quad

            # Exclude already selected and padding tokens
            gains[~candidate_mask] = -float("inf")
            gains[selected_mask] = -float("inf")
            best_idx = torch.argmax(gains).item()
            selected.append(best_idx)
            selected_mask[best_idx] = True

            # Update the inverse of L_S via block matrix inversion
            if L_inv_S is None:
                L_inv_S = (1.0 / L[best_idx, best_idx]).unsqueeze(0).unsqueeze(1)
            else:
                old_len = len(selected) - 1
                u_idx = selected[:old_len]
                u = L[u_idx, best_idx]
                c_val = L[best_idx, best_idx] - (u @ L_inv_S @ u)
                c = max(c_val.item(), self.jitter)
                L_inv_S_u = L_inv_S @ u

                new_L_inv = torch.zeros(old_len + 1, old_len + 1, device=device)
                new_L_inv[:old_len, :old_len] = L_inv_S + (1.0 / c) * torch.outer(L_inv_S_u, L_inv_S_u)
                new_L_inv[:old_len, old_len] = -(1.0 / c) * L_inv_S_u
                new_L_inv[old_len, :old_len] = -(1.0 / c) * L_inv_S_u
                new_L_inv[old_len, old_len] = 1.0 / c
                L_inv_S = new_L_inv

        selected_indices = torch.tensor(selected, dtype=torch.long, device=device)
        if self.sort_indices:
            selected_indices = torch.sort(selected_indices).values
        selected_tokens = vision_tokens[selected_indices]
        return selected_indices, selected_tokens
