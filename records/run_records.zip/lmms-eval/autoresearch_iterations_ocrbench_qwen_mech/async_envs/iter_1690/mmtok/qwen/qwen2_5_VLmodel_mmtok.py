# MMTok: Multimodal Coverage Maximization for Efficient Inference of VLMs
# Paper: https://arxiv.org/abs/2508.18264
# This file is modified from the official Qwen2.5-VL code (https://github.com/QwenLM/Qwen2.5-VL).
# Copyright (c) 2025 Zoom Communications, Inc. Author: Anonymous

"""
MMTok Qwen2.5-VL model: overridden forward with token selection (image -> Vision Tower -> MMTok select -> Qwen2.5-VL).
"""

import os
from typing import List, Optional, Tuple, Union

import torch
import torch.nn as nn
from loguru import logger as eval_logger
from transformers.models.qwen2_5_vl.modeling_qwen2_5_vl import Qwen2_5_VLModelOutputWithPast, auto_docstring


class Qwen2_5_VL_MMTok(nn.Module):
    """
    MMTok Qwen2.5-VL: forward runs vision -> MMTok selection -> language model.
    """

    def get_video_features(self, pixel_values_videos: torch.FloatTensor, video_grid_thw: Optional[torch.LongTensor] = None):
        """
        Encodes videos into continuous embeddings that can be forwarded to the language model.

        Args:
            pixel_values_videos (`torch.FloatTensor` of shape `(batch_size, num_channels, image_size, image_size)`):
                The tensors corresponding to the input videos.
            video_grid_thw (`torch.LongTensor` of shape `(num_videos, 3)`, *optional*):
                The temporal, height and width of feature shape of each video in LLM.
        """
        pixel_values_videos = pixel_values_videos.type(self.visual.dtype)
        video_embeds, image_features = self.visual(pixel_values_videos, grid_thw=video_grid_thw)
        return video_embeds, image_features

    def get_image_features(self, pixel_values: torch.FloatTensor, image_grid_thw: Optional[torch.LongTensor] = None):
        """
        Encodes images into continuous embeddings that can be forwarded to the language model.

        Args:
            pixel_values (`torch.FloatTensor` of shape `(batch_size, num_channels, image_size, image_size)`):
                The tensors corresponding to the input images.
            image_grid_thw (`torch.LongTensor` of shape `(num_images, 3)`, *optional*):
                The temporal, height and width of feature shape of each image in LLM.
        """
        pixel_values = pixel_values.type(self.visual.dtype)
        image_embeds, image_features = self.visual(pixel_values, grid_thw=image_grid_thw)
        return image_embeds, image_features

    @auto_docstring
    def forward(
        self,
        input_ids: torch.LongTensor = None,
        attention_mask: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.LongTensor] = None,
        past_key_values: Optional[List[torch.FloatTensor]] = None,
        inputs_embeds: Optional[torch.FloatTensor] = None,
        use_cache: Optional[bool] = None,
        output_attentions: Optional[bool] = None,
        output_hidden_states: Optional[bool] = None,
        return_dict: Optional[bool] = None,
        pixel_values: Optional[torch.Tensor] = None,
        pixel_values_videos: Optional[torch.FloatTensor] = None,
        image_grid_thw: Optional[torch.LongTensor] = None,
        video_grid_thw: Optional[torch.LongTensor] = None,
        rope_deltas: Optional[torch.LongTensor] = None,
        cache_position: Optional[torch.LongTensor] = None,
        second_per_grid_ts: Optional[torch.Tensor] = None,
        **kwargs,
    ) -> Union[Tuple, Qwen2_5_VLModelOutputWithPast]:
        r"""
        pixel_values_videos (`torch.FloatTensor` of shape `(seq_length, num_channels * temporal_size * image_size * image_size)):
            The tensors corresponding to the input videos. Pixel values can be obtained using
            [`AutoImageProcessor`]. See [`Qwen2_5_VLImageProcessor.__call__`] for details. [`Qwen2_5_VLProcessor`] uses
            [`Qwen2_5_VLImageProcessor`] for processing videos.
        image_grid_thw (`torch.LongTensor` of shape `(num_images, 3)`, *optional*):
            The temporal, height and width of feature shape of each image in LLM.
        video_grid_thw (`torch.LongTensor` of shape `(num_videos, 3)`, *optional*):
            The temporal, height and width of feature shape of each video in LLM.
        rope_deltas (`torch.LongTensor` of shape `(batch_size, )`, *optional*):
            The rope index difference between sequence length and multimodal rope.
        second_per_grid_ts (`torch.Tensor` of shape `(num_videos)`, *optional*):
            The time interval (in seconds) for each grid along the temporal dimension in the 3D position IDs.
        """

        output_attentions = output_attentions if output_attentions is not None else self.config.output_attentions
        output_hidden_states = output_hidden_states if output_hidden_states is not None else self.config.output_hidden_states
        return_dict = return_dict if return_dict is not None else self.config.use_return_dict

        select_pixel = False
        if inputs_embeds is None:
            inputs_embeds = self.get_input_embeddings()(input_ids)
            if pixel_values is not None:
                select_pixel = True
                image_embeds, image_features = self.get_image_features(pixel_values, image_grid_thw)
                n_image_tokens = (input_ids == self.config.image_token_id).sum().item()
                n_image_features = image_embeds.shape[0]
                if n_image_tokens != n_image_features:
                    raise ValueError(f"Image features and image tokens do not match: tokens: {n_image_tokens}, features {n_image_features}")

                mask = input_ids == self.config.image_token_id
                mask_unsqueezed = mask.unsqueeze(-1)
                mask_expanded = mask_unsqueezed.expand_as(inputs_embeds)
                image_mask = mask_expanded.to(inputs_embeds.device)

                image_embeds = image_embeds.to(inputs_embeds.device, inputs_embeds.dtype)
                image_features = image_features.to(inputs_embeds.device, inputs_embeds.dtype)
                inputs_embeds = inputs_embeds.masked_scatter(image_mask, image_embeds)

            if pixel_values_videos is not None:
                video_embeds, video_features = self.get_video_features(pixel_values_videos, video_grid_thw)
                n_video_tokens = (input_ids == self.config.video_token_id).sum().item()
                n_video_features = video_embeds.shape[0]
                if n_video_tokens != n_video_features:
                    raise ValueError(f"Video features and video tokens do not match: tokens: {n_video_tokens}, features {n_video_features}")

                mask = input_ids == self.config.video_token_id
                mask_unsqueezed = mask.unsqueeze(-1)
                mask_expanded = mask_unsqueezed.expand_as(inputs_embeds)
                video_mask = mask_expanded.to(inputs_embeds.device)

                video_embeds = video_embeds.to(inputs_embeds.device, inputs_embeds.dtype)
                inputs_embeds = inputs_embeds.masked_scatter(video_mask, video_embeds)

            if attention_mask is not None:
                attention_mask = attention_mask.to(inputs_embeds.device)

        # if we get 4D attention mask we cannot calculate rope deltas anymore. TODO @raushan fixme
        if position_ids is None and (attention_mask is None or attention_mask.ndim == 2):
            # calculate RoPE index once per generation in the pre-fill stage only
            if (cache_position is not None and cache_position[0] == 0) or self.rope_deltas is None or (past_key_values is None or past_key_values.get_seq_length() == 0):
                position_ids, rope_deltas = self.get_rope_index(
                    input_ids,
                    image_grid_thw,
                    video_grid_thw,
                    second_per_grid_ts,
                    attention_mask,
                )
                self.rope_deltas = rope_deltas
            # then use the prev pre-calculated rope-deltas to get the correct position ids
            else:
                batch_size, seq_length, _ = inputs_embeds.shape
                delta = (cache_position[0] + self.rope_deltas).to(inputs_embeds.device) if cache_position is not None else 0
                position_ids = torch.arange(seq_length, device=inputs_embeds.device)
                position_ids = position_ids.view(1, -1).expand(batch_size, -1)
                if cache_position is not None:  # otherwise `deltas` is an int `0`
                    delta = delta.repeat_interleave(batch_size // delta.shape[0], dim=0)
                position_ids = position_ids.add(delta)
                position_ids = position_ids.unsqueeze(0).expand(3, -1, -1)

        if select_pixel:
            token_retain_ratio = getattr(self._mmtok_core, "retain_ratio", float(os.environ.get("TOKEN_RETAIN_RATIO", "0.1")))
            selection_method = os.environ.get("SELECTION_METHOD", "mmtok").lower()

            if selection_method == "divprune":
                def DivPrune(visual_feature_vectors, target_vision_tokens=1):
                    threshold_terms = target_vision_tokens

                    def pairwise_cosine_similarity(matrix):
                        norm_matrix = matrix / matrix.norm(dim=1, keepdim=True)
                        cosine_similarity = torch.mm(norm_matrix, norm_matrix.t())
                        return cosine_similarity

                    cosine_matrix = 1.0 - (pairwise_cosine_similarity(visual_feature_vectors))

                    s = torch.empty(threshold_terms, dtype=torch.long, device=visual_feature_vectors.device)
                    selected_mask = torch.zeros(cosine_matrix.size(0), dtype=torch.bool, device=cosine_matrix.device)
                    for i in range(threshold_terms):
                        if i == 0:
                            m2 = cosine_matrix
                        else:
                            m2 = torch.index_select(cosine_matrix, 0, torch.index_select(s, 0, torch.arange(0, i, device=cosine_matrix.device)))

                        if i == 0:
                            scores = torch.topk(m2, 2, dim=0, largest=False).values[1, :]  # for distance
                        else:
                            scores = torch.min(m2, dim=0).values  # for distance

                        scores[selected_mask] = float("-inf")

                        phrase_to_add_idx = torch.argmax(scores)

                        s[i] = phrase_to_add_idx
                        selected_mask[phrase_to_add_idx] = True

                    s.sort()
                    return s
            else:
                DivPrune = None

            batch_size = input_ids.shape[0]
            if batch_size == 1:
                question = self.get_question()
                target_vision_tokens = int(token_retain_ratio * image_embeds.shape[0])

                if selection_method == "mmtok":
                    selected_indices, selected_image_embeds = self._mmtok_core.apply_selection_preprocess_qwen(
                        image_embeds, image_features, question, target_vision_tokens=target_vision_tokens, image_grid_thw=image_grid_thw
                    )
                elif selection_method == "divprune":
                    selected_indices = DivPrune(image_features, target_vision_tokens=target_vision_tokens)
                    selected_image_embeds = image_embeds[selected_indices]
                else:
                    raise ValueError(f"[MMTok] Unsupported SELECTION_METHOD: {selection_method}, use 'mmtok' or 'divprune'")

                select_mask = torch.zeros(image_embeds.shape[0], dtype=torch.bool, device=image_embeds.device)
                select_mask[selected_indices] = True

                img_mask = (input_ids == self.config.image_token_id)[0]
                st_idx = torch.nonzero(img_mask, as_tuple=True)[0]

                if st_idx.numel() > 0:
                    first, last = st_idx[0].item(), st_idx[-1].item()
                    if len(selected_indices) == 0:
                        # Remove all vision tokens, keep text only
                        position_ids = torch.cat([position_ids[:, :, :first], position_ids[:, :, last + 1 :]], dim=2)
                        attention_mask = torch.cat([attention_mask[:, :first], attention_mask[:, last + 1 :]], dim=1)
                        inputs_embeds = torch.cat([inputs_embeds[:, :first], inputs_embeds[:, last + 1 :]], dim=1)
                    else:
                        img_mask[first : last + 1] = ~select_mask
                        img_mask = ~img_mask
                        selected_positions = first + torch.tensor(selected_indices, device=img_mask.device)
                        inputs_embeds[:, selected_positions] = selected_image_embeds

                        position_ids = position_ids[:, :, img_mask]
                        attention_mask = attention_mask[:, img_mask]
                        inputs_embeds = inputs_embeds[:, img_mask]
                        del selected_positions
                del image_embeds, image_features, selected_indices, selected_image_embeds
                del select_mask, img_mask, st_idx
                del question, target_vision_tokens
            else:
                # Batched path: process each sample individually because selection is question-specific
                # and produces variable-length outputs that need per-sample compaction.
                questions = self.get_question_list() if hasattr(self, "get_question_list") else []
                if len(questions) < batch_size:
                    last_q = self.get_question() or ""
                    questions = questions + [last_q] * (batch_size - len(questions))

                # Compute tokens per image from grid_thw
                spatial_merge_unit = getattr(self.visual, "spatial_merge_size", 2) ** 2
                tokens_per_image = []
                for g in image_grid_thw:
                    tokens_per_image.append(int(g[0].item() * g[1].item() * g[2].item()) // spatial_merge_unit)

                total_img_toks = sum(tokens_per_image)
                if total_img_toks != image_embeds.shape[0]:
                    eval_logger.warning(
                        f"[MMTok] Token count mismatch: expected {total_img_toks}, got {image_embeds.shape[0]}. "
                        f"Falling back to equal split."
                    )
                    n_images = len(tokens_per_image)
                    tokens_per_image = [image_embeds.shape[0] // n_images] * n_images

                # Map images to samples based on image token counts in input_ids
                image_tokens_per_sample = (input_ids == self.config.image_token_id).sum(dim=1).tolist()
                sample_image_indices = []
                img_idx = 0
                for b in range(batch_size):
                    n_toks = image_tokens_per_sample[b]
                    indices = []
                    cumsum = 0
                    while img_idx < len(tokens_per_image) and cumsum < n_toks:
                        indices.append(img_idx)
                        cumsum += tokens_per_image[img_idx]
                        img_idx += 1
                    sample_image_indices.append(indices)

                # Split image_embeds and image_features per image
                image_embeds_split = []
                image_features_split = []
                offset = 0
                for n_toks in tokens_per_image:
                    image_embeds_split.append(image_embeds[offset : offset + n_toks])
                    image_features_split.append(image_features[offset : offset + n_toks])
                    offset += n_toks

                new_inputs_embeds = []
                new_attention_masks = [] if attention_mask is not None else None
                new_position_ids = []

                for b in range(batch_size):
                    ids_b = input_ids[b : b + 1]
                    embeds_b = inputs_embeds[b : b + 1]
                    attn_b = attention_mask[b : b + 1] if attention_mask is not None else None
                    pos_b = position_ids[:, b : b + 1, :]

                    img_indices = sample_image_indices[b]
                    if len(img_indices) == 0:
                        new_inputs_embeds.append(embeds_b.squeeze(0))
                        if new_attention_masks is not None:
                            new_attention_masks.append(attn_b.squeeze(0))
                        new_position_ids.append(pos_b.squeeze(1))
                        continue

                    sample_image_embeds = torch.cat([image_embeds_split[i] for i in img_indices], dim=0)
                    sample_image_features = torch.cat([image_features_split[i] for i in img_indices], dim=0)

                    question = questions[b] if b < len(questions) else questions[-1]
                    target_vision_tokens = int(token_retain_ratio * sample_image_embeds.shape[0])

                    if selection_method == "mmtok":
                        selected_indices, selected_image_embeds = self._mmtok_core.apply_selection_preprocess_qwen(
                            sample_image_embeds,
                            sample_image_features,
                            question,
                            target_vision_tokens=target_vision_tokens,
                        )
                    elif selection_method == "divprune":
                        selected_indices = DivPrune(sample_image_features, target_vision_tokens=target_vision_tokens)
                        selected_image_embeds = sample_image_embeds[selected_indices]
                    else:
                        raise ValueError(f"[MMTok] Unsupported SELECTION_METHOD: {selection_method}, use 'mmtok' or 'divprune'")

                    select_mask = torch.zeros(sample_image_embeds.shape[0], dtype=torch.bool, device=sample_image_embeds.device)
                    select_mask[selected_indices] = True

                    img_mask = (ids_b == self.config.image_token_id)[0]
                    st_idx = torch.nonzero(img_mask, as_tuple=True)[0]

                    if st_idx.numel() > 0:
                        first, last = st_idx[0].item(), st_idx[-1].item()
                        if len(selected_indices) == 0:
                            pos_b = torch.cat([pos_b[:, :, :first], pos_b[:, :, last + 1 :]], dim=2)
                            if attn_b is not None:
                                attn_b = torch.cat([attn_b[:, :first], attn_b[:, last + 1 :]], dim=1)
                            embeds_b = torch.cat([embeds_b[:, :first], embeds_b[:, last + 1 :]], dim=1)
                        else:
                            img_mask_local = img_mask.clone()
                            img_mask_local[first : last + 1] = ~select_mask
                            img_mask_local = ~img_mask_local
                            selected_positions = first + torch.tensor(selected_indices, device=img_mask_local.device)
                            embeds_b[:, selected_positions] = selected_image_embeds

                            pos_b = pos_b[:, :, img_mask_local]
                            if attn_b is not None:
                                attn_b = attn_b[:, img_mask_local]
                            embeds_b = embeds_b[:, img_mask_local]

                    new_inputs_embeds.append(embeds_b.squeeze(0))
                    if new_attention_masks is not None:
                        new_attention_masks.append(attn_b.squeeze(0))
                    new_position_ids.append(pos_b.squeeze(1))

                # Pad all sequences to the same length
                max_len = max(e.shape[0] for e in new_inputs_embeds)

                def _pad_2d(t, target_len):
                    pad_size = target_len - t.shape[0]
                    if pad_size <= 0:
                        return t
                    pad = torch.zeros(pad_size, t.shape[1], device=t.device, dtype=t.dtype)
                    return torch.cat([t, pad], dim=0)

                def _pad_1d(t, target_len):
                    pad_size = target_len - t.shape[0]
                    if pad_size <= 0:
                        return t
                    pad = torch.zeros(pad_size, device=t.device, dtype=t.dtype)
                    return torch.cat([t, pad], dim=0)

                def _pad_posids(t, target_len):
                    # t: [D, L] where D is 3 or 4 depending on the transformers version
                    pad_size = target_len - t.shape[1]
                    if pad_size <= 0:
                        return t
                    pad = torch.zeros(t.shape[0], pad_size, device=t.device, dtype=t.dtype)
                    return torch.cat([t, pad], dim=1)

                inputs_embeds = torch.stack([_pad_2d(e, max_len) for e in new_inputs_embeds], dim=0)
                position_ids = torch.stack([_pad_posids(p, max_len) for p in new_position_ids], dim=1)
                if new_attention_masks is not None:
                    attention_mask = torch.stack([_pad_1d(a, max_len) for a in new_attention_masks], dim=0)

                del image_embeds, image_features
                del questions, tokens_per_image, sample_image_indices
                del image_embeds_split, image_features_split
                del new_inputs_embeds, new_position_ids
                if new_attention_masks is not None:
                    del new_attention_masks
            del token_retain_ratio, selection_method
        elif pixel_values_videos is not None:
            # MMTok video-token selection for video-only inputs.
            # (When images are also present we keep the existing image path and skip
            # video selection to avoid interaction between two compaction steps.)
            batch_size = input_ids.shape[0]
            if batch_size == 1:
                question = self.get_question()
                token_retain_ratio = getattr(self._mmtok_core, "retain_ratio", float(os.environ.get("TOKEN_RETAIN_RATIO", "0.1")))
                target_video_tokens = int(token_retain_ratio * video_embeds.shape[0])

                video_features = video_features.to(inputs_embeds.device, inputs_embeds.dtype)
                selected_indices, selected_video_embeds = self._mmtok_core.apply_selection_preprocess_qwen(
                    video_embeds,
                    video_features,
                    question,
                    target_vision_tokens=target_video_tokens,
                    image_grid_thw=video_grid_thw,
                )

                select_mask = torch.zeros(video_embeds.shape[0], dtype=torch.bool, device=video_embeds.device)
                select_mask[selected_indices] = True

                video_mask = (input_ids == self.config.video_token_id)[0]
                st_idx = torch.nonzero(video_mask, as_tuple=True)[0]

                if st_idx.numel() > 0:
                    first, last = st_idx[0].item(), st_idx[-1].item()
                    if len(selected_indices) == 0:
                        # Remove all video tokens, keep text only
                        position_ids = torch.cat([position_ids[:, :, :first], position_ids[:, :, last + 1 :]], dim=2)
                        attention_mask = torch.cat([attention_mask[:, :first], attention_mask[:, last + 1 :]], dim=1)
                        inputs_embeds = torch.cat([inputs_embeds[:, :first], inputs_embeds[:, last + 1 :]], dim=1)
                    else:
                        video_mask[first : last + 1] = ~select_mask
                        video_mask = ~video_mask
                        selected_positions = first + torch.tensor(selected_indices, device=video_mask.device)
                        inputs_embeds[:, selected_positions] = selected_video_embeds

                        position_ids = position_ids[:, :, video_mask]
                        attention_mask = attention_mask[:, video_mask]
                        inputs_embeds = inputs_embeds[:, video_mask]
                        del selected_positions
                del video_embeds, video_features, selected_indices, selected_video_embeds
                del select_mask, video_mask, st_idx
                del question, target_video_tokens, token_retain_ratio
            else:
                # Batched video selection is not implemented yet; fall back to full video tokens.
                pass
        # Qwen2.5-VL's text decoder does not accept mm_token_type_ids.
        kwargs.pop("mm_token_type_ids", None)
        outputs = self.language_model(
            input_ids=None,
            position_ids=position_ids,
            attention_mask=attention_mask,
            past_key_values=past_key_values,
            inputs_embeds=inputs_embeds,
            use_cache=use_cache,
            output_attentions=output_attentions,
            output_hidden_states=output_hidden_states,
            return_dict=True,
            cache_position=cache_position,
            **kwargs,
        )

        output = Qwen2_5_VLModelOutputWithPast(
            last_hidden_state=outputs.last_hidden_state,
            past_key_values=outputs.past_key_values,
            hidden_states=outputs.hidden_states,
            attentions=outputs.attentions,
            rope_deltas=self.rope_deltas,
        )
        return output if return_dict else output.to_tuple()
