# MMTok: Multimodal Coverage Maximization for Efficient Inference of VLMs
# Paper: https://arxiv.org/abs/2508.18264
# Copyright (c) 2025 Zoom Communications, Inc.
# Author: Anonymous
# Licensed under the Apache License, Version 2.0

"""
Spatial K-Means selector: cluster vision tokens by spatial coordinates,
then pick the token with highest text similarity in each cluster.
"""

import math
from typing import List, Optional, Tuple

import torch
import torch.nn.functional as F


class SpatialKMeansSelector:
    """
    Select vision tokens via spatial K-Means + text-query cosine similarity.

    1. Infer spatial grid (H, W) from token count N.
    2. Run K-Means (K = target_vision_tokens) on 2-D pixel coordinates.
    3. Score each token by cosine similarity to the mean text embedding.
    4. Select the highest-scoring token per cluster.
    """

    def __init__(self, target_vision_tokens: int = 64):
        self.target_vision_tokens = target_vision_tokens

    def mm_coverage_selection(
        self,
        text_token_embedding: torch.Tensor,
        vision_tokens: torch.Tensor,
        vision_tokens_clip: torch.Tensor,
        tv_temp: float = 0.01,
        vv_temp: float = 0.2,
        padding_patch_indices: Optional[List[int]] = None,
    ) -> Tuple[List[int], torch.Tensor]:
        """
        Args:
            text_token_embedding: [T, D] text token embeddings.
            vision_tokens: [N, D] vision token embeddings.
            vision_tokens_clip: [N, D] (unused, kept for interface compatibility).
            tv_temp, vv_temp: unused, kept for interface compatibility.
            padding_patch_indices: optional indices to exclude.

        Returns:
            selected_indices: list of selected token indices.
            selected_tokens: [K, D] selected vision tokens.
        """
        device = vision_tokens.device
        N, D = vision_tokens.shape
        K = min(self.target_vision_tokens, N)

        # ---- query vector from text ----
        q_emb = text_token_embedding.mean(dim=0)  # [D]

        # ---- infer spatial grid ----
        H = int(math.isqrt(N))
        W = N // H
        while H * W != N:
            H -= 1
            W = N // H

        y_coords, x_coords = torch.meshgrid(
            torch.arange(H, device=device),
            torch.arange(W, device=device),
            indexing="ij",
        )
        coords = torch.stack([y_coords, x_coords], dim=-1).reshape(-1, 2).float()

        # ---- spatial K-Means ----
        perm = torch.randperm(N, device=device)[:K]
        centroids = coords[perm]  # [K, 2]

        for _ in range(10):
            dist_sq = ((coords.unsqueeze(1) - centroids.unsqueeze(0)) ** 2).sum(dim=2)  # [N, K]
            labels = dist_sq.argmin(dim=-1)  # [N]

            one_hot = F.one_hot(labels, num_classes=K).float()  # [N, K]
            counts = one_hot.sum(dim=0)  # [K]
            new_centroids = (one_hot.T @ coords) / counts.clamp(min=1).unsqueeze(1)

            mask_empty = counts == 0
            if mask_empty.any():
                farthest_idx = dist_sq.max(dim=1).values.argmax()
                new_centroids[mask_empty] = coords[farthest_idx]
            centroids = new_centroids

        # ---- score by text similarity ----
        scores = F.cosine_similarity(vision_tokens, q_emb.unsqueeze(0), dim=-1)  # [N]
        scores = torch.nan_to_num(scores, nan=0.0)

        # suppress padding indices
        if padding_patch_indices is not None and len(padding_patch_indices) > 0:
            scores[padding_patch_indices] = -float("inf")

        # ---- select best per cluster ----
        selected_indices = []
        for k in range(K):
            mask = labels == k
            if mask.sum() == 0:
                continue
            masked_scores = scores.masked_fill(~mask, -float("inf"))
            best_local = masked_scores.argmax()
            selected_indices.append(best_local.item())

        # fallback: ensure exactly K tokens
        if len(selected_indices) < K:
            remaining_scores = scores.clone()
            already = torch.tensor(selected_indices, device=device, dtype=torch.long)
            if len(already) > 0:
                remaining_scores[already] = -float("inf")
            while len(selected_indices) < K and remaining_scores.max() > -float("inf"):
                best_idx = remaining_scores.argmax()
                selected_indices.append(best_idx.item())
                remaining_scores[best_idx] = -float("inf")

        selected_indices = torch.tensor(selected_indices, dtype=torch.long, device=device)
        selected_indices, _ = selected_indices.sort()
        selected_tokens = vision_tokens[selected_indices]
        return selected_indices.tolist(), selected_tokens
