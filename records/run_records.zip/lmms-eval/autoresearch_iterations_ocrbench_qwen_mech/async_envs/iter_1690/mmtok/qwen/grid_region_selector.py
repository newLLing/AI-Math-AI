# MMTok: Multimodal Coverage Maximization for Efficient Inference of VLMs
# Paper: https://arxiv.org/abs/2508.18264
# Copyright (c) 2025 Zoom Communications, Inc.
# Licensed under the Apache License, Version 2.0

"""
Grid-Region Selector.

Partitions the vision token grid into spatial regions and selects the top-scoring
token from each region:
1. Compute cosine similarity between vision tokens and the mean-pooled text query.
2. Infer a square-ish 2D grid layout for the vision tokens.
3. Partition the grid into non-overlapping regions of size ~s x s, where
   s = max(1, sqrt(N / K)).
4. For each region, pick the eligible token with highest query similarity.
5. Score regions as alpha * max_similarity + beta and select the top-K regions.
   If fewer than K valid regions exist, fall back to global top-K similarity.
"""

import math
from typing import List, Optional, Tuple

import torch
import torch.nn.functional as F


class GridRegionSelector:
    """
    Spatial grid-region vision token selector.
    """

    def __init__(
        self,
        target_vision_tokens: int = 64,
        alpha: float = 1.0,
        beta: float = 0.5,
        sort_indices: bool = True,
    ):
        self.target_vision_tokens = target_vision_tokens
        self.alpha = alpha
        self.beta = beta
        self.sort_indices = sort_indices

    @torch.no_grad()
    def mm_coverage_selection(
        self,
        text_token_embedding: torch.Tensor,
        vision_tokens: torch.Tensor,
        vision_tokens_clip: torch.Tensor,
        tv_temp: float = 0.01,
        vv_temp: float = 0.2,
        padding_patch_indices: Optional[List[int]] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Apply grid-region selection on vision tokens.

        Args:
            text_token_embedding: [L, D] text token embeddings (question/keywords).
            vision_tokens: [N, D] mm_projector output tokens.
            vision_tokens_clip: Unused (interface compatibility).
            tv_temp: Unused (interface compatibility).
            vv_temp: Unused (interface compatibility).
            padding_patch_indices: Optional list of indices to exclude from selection.

        Returns:
            selected_indices: [K] LongTensor of selected token indices.
            selected_tokens: [K, D] selected vision tokens.
        """
        device = vision_tokens.device
        N = vision_tokens.size(0)
        k = min(self.target_vision_tokens, N)

        if k <= 0:
            selected_indices = torch.empty(0, dtype=torch.long, device=device)
            selected_tokens = torch.empty(
                0, vision_tokens.size(1), device=device, dtype=vision_tokens.dtype
            )
            return selected_indices, selected_tokens
        elif k >= N or N == 0:
            selected_indices = torch.arange(N, device=device)
            return selected_indices, vision_tokens

        # Candidate mask excluding padding patches
        candidate_mask = torch.ones(N, dtype=torch.bool, device=device)
        if padding_patch_indices is not None and len(padding_patch_indices) > 0:
            if isinstance(padding_patch_indices, torch.Tensor):
                pad_idx = padding_patch_indices.to(device)
            else:
                pad_idx = torch.tensor(padding_patch_indices, dtype=torch.long, device=device)
            candidate_mask[pad_idx] = False

        num_eligible = candidate_mask.sum().item()
        if k >= num_eligible:
            selected_indices = torch.where(candidate_mask)[0]
            return selected_indices, vision_tokens[selected_indices]

        k = min(k, num_eligible)

        # ---------- 1. Query embedding and similarity scores ----------
        if text_token_embedding is not None and text_token_embedding.numel() > 0:
            q_emb = text_token_embedding.mean(dim=0)  # [D]
        else:
            q_emb = torch.zeros(vision_tokens.size(1), device=device, dtype=vision_tokens.dtype)

        sim = F.cosine_similarity(vision_tokens, q_emb.unsqueeze(0), dim=-1)  # [N]

        # ---------- 2. Infer square-ish grid ----------
        def nearest_square_grid(num: int) -> Tuple[int, int]:
            for d in range(int(math.isqrt(num)), 0, -1):
                if num % d == 0:
                    return d, num // d
            return 1, num

        H, W = nearest_square_grid(N)

        # ---------- 3. Spatial partition into regions ----------
        s = max(1, int((N / k) ** 0.5))
        num_regions_h = math.ceil(H / s)
        num_regions_w = math.ceil(W / s)
        M = num_regions_h * num_regions_w

        while M < k and s > 1:
            s -= 1
            num_regions_h = math.ceil(H / s)
            num_regions_w = math.ceil(W / s)
            M = num_regions_h * num_regions_w

        idx = torch.arange(N, device=device)
        rows = idx // W
        cols = idx % W
        region_ids = (rows // s) * num_regions_w + (cols // s)  # [N]

        # ---------- 4. Per-region best token (eligible only) ----------
        max_sim = torch.full((M,), float("-inf"), device=device)
        best_idx = torch.zeros(M, dtype=torch.long, device=device)

        for rid in range(M):
            mask = (region_ids == rid) & candidate_mask
            if mask.any():
                rid_sims = sim[mask]
                rid_indices = torch.where(mask)[0]
                best_local = torch.argmax(rid_sims)
                best_idx[rid] = rid_indices[best_local]
                max_sim[rid] = rid_sims[best_local]

        valid_region_mask = max_sim > float("-inf")
        num_valid_regions = valid_region_mask.sum().item()

        region_score = self.alpha * max_sim + self.beta  # [M]

        # ---------- 5. Select top-K regions (fallback to global top-K) ----------
        if num_valid_regions < k:
            eligible_sim = sim.clone()
            eligible_sim[~candidate_mask] = float("-inf")
            selected_indices = torch.topk(eligible_sim, k).indices
        else:
            selected_regions = torch.topk(region_score, k).indices
            selected_indices = best_idx[selected_regions]

        if self.sort_indices:
            selected_indices = torch.sort(selected_indices).values
        selected_tokens = vision_tokens[selected_indices]
        return selected_indices, selected_tokens
