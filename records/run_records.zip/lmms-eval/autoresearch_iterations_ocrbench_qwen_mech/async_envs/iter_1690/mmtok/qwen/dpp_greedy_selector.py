# MMTok: Multimodal Coverage Maximization for Efficient Inference of VLMs
# Paper: https://arxiv.org/abs/2508.18264
# Copyright (c) 2025 Zoom Communications, Inc.
# Licensed under the Apache License, Version 2.0

"""
DPP Greedy Selector.

Determinantal Point Process (DPP) greedy log-determinant maximization with
combined feature and spatial kernels:
1. Infer a 2D grid layout for vision tokens and build normalized spatial coords.
2. Compute per-token quality scores q_i = exp(cos_sim(query, token) / tau).
3. Build combined kernel S = S_feat * S_pos where:
   - S_feat: Gaussian RBF over vision feature cosine distances.
   - S_pos:  Gaussian RBF over 2D spatial distances.
4. Form DPP kernel L = diag(q) @ S @ diag(q) + eps*I.
5. Greedily select tokens maximizing log(conditional variance) via incremental
   Cholesky updates.
"""

import math
from typing import List, Optional, Tuple

import torch
import torch.nn.functional as F


class DPPGreedySelector:
    """
    DPP-based greedy vision token selector with spatial and feature kernels.
    """

    def __init__(
        self,
        target_vision_tokens: int = 64,
        tau: float = 0.1,
        sigma: float = 0.5,
        delta_param: float = 0.3,
        eps_jitter: float = 1e-6,
        sort_indices: bool = True,
    ):
        self.target_vision_tokens = target_vision_tokens
        self.tau = tau
        self.sigma = sigma
        self.delta_param = delta_param
        self.eps_jitter = eps_jitter
        self.sort_indices = sort_indices

    @torch.no_grad()
    def mm_coverage_selection(
        self,
        text_token_embedding: torch.Tensor,
        vision_tokens: torch.Tensor,
        vision_tokens_clip: torch.Tensor,
        tv_temp: float = 0.01,
        vv_temp: float = 0.2,
        padding_patch_indices: Optional[List[int]] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Apply DPP greedy selection on vision tokens.

        Args:
            text_token_embedding: [L, D] text token embeddings (question/keywords).
            vision_tokens: [N, D] mm_projector output tokens.
            vision_tokens_clip: Unused (interface compatibility).
            tv_temp: Unused (interface compatibility).
            vv_temp: Unused (interface compatibility).
            padding_patch_indices: Optional list of indices to exclude from selection.

        Returns:
            selected_indices: [K] LongTensor of selected token indices.
            selected_tokens: [K, D] selected vision tokens.
        """
        device = vision_tokens.device
        N = vision_tokens.size(0)
        k = min(self.target_vision_tokens, N)

        if k <= 0:
            selected_indices = torch.empty(0, dtype=torch.long, device=device)
            selected_tokens = torch.empty(
                0, vision_tokens.size(1), device=device, dtype=vision_tokens.dtype
            )
            return selected_indices, selected_tokens
        elif k >= N or N == 0:
            selected_indices = torch.arange(N, device=device)
            return selected_indices, vision_tokens

        # Candidate mask excluding padding patches
        candidate_mask = torch.ones(N, dtype=torch.bool, device=device)
        if padding_patch_indices is not None and len(padding_patch_indices) > 0:
            if isinstance(padding_patch_indices, torch.Tensor):
                pad_idx = padding_patch_indices.to(device)
            else:
                pad_idx = torch.tensor(padding_patch_indices, dtype=torch.long, device=device)
            candidate_mask[pad_idx] = False

        num_eligible = candidate_mask.sum().item()
        if k >= num_eligible:
            selected_indices = torch.where(candidate_mask)[0]
            return selected_indices, vision_tokens[selected_indices]

        k = min(k, num_eligible)

        # ---------- 1. Infer 2D grid and spatial coordinates ----------
        w_max = int(math.isqrt(N)) + 1
        best_H, best_W = 1, N
        min_diff = N
        for w in range(1, w_max):
            if N % w == 0:
                h = N // w
                diff = abs(h - w)
                if diff < min_diff:
                    min_diff = diff
                    best_H, best_W = h, w
        H, W = best_H, best_W

        rows = (
            torch.arange(H, device=device, dtype=vision_tokens.dtype)
            .unsqueeze(1)
            .expand(H, W)
            .reshape(-1)
        )
        cols = (
            torch.arange(W, device=device, dtype=vision_tokens.dtype)
            .unsqueeze(0)
            .expand(H, W)
            .reshape(-1)
        )
        if H > 1:
            rows = rows / (H - 1)
        if W > 1:
            cols = cols / (W - 1)
        positions = torch.stack([rows, cols], dim=1)  # (N, 2)

        # ---------- 2. Text query embedding ----------
        if text_token_embedding is not None and text_token_embedding.numel() > 0:
            q_emb = text_token_embedding.mean(dim=0).to(vision_tokens.dtype)
        else:
            q_emb = torch.zeros(vision_tokens.size(1), device=device, dtype=vision_tokens.dtype)

        # ---------- 3. Convert to float32 for DPP stability ----------
        vision_f32 = vision_tokens.float()
        q_emb_f32 = q_emb.float()
        positions_f32 = positions.float()

        vision_norm = F.normalize(vision_f32, p=2, dim=1, eps=1e-12)
        text_norm = F.normalize(q_emb_f32, p=2, dim=0, eps=1e-12)

        # ---------- 4. Quality scores ----------
        cos_sim = torch.matmul(vision_norm, text_norm)  # (N,)
        q = torch.exp(cos_sim / self.tau)

        # ---------- 5. Feature similarity kernel ----------
        dot = torch.matmul(vision_norm, vision_norm.T)
        dist_feat = 2.0 - 2.0 * dot
        S_feat = torch.exp(-dist_feat / (2.0 * self.sigma ** 2))

        # ---------- 6. Spatial similarity kernel ----------
        pos_dot = torch.matmul(positions_f32, positions_f32.T)
        pos_sq = (positions_f32 ** 2).sum(dim=1)
        dist_pos = pos_sq.unsqueeze(1) + pos_sq.unsqueeze(0) - 2.0 * pos_dot
        S_pos = torch.exp(-dist_pos / (2.0 * self.delta_param ** 2))

        # ---------- 7. DPP kernel ----------
        S = S_feat * S_pos
        L = q.unsqueeze(1) * S * q.unsqueeze(0)  # (N, N)
        L.diagonal().add_(self.eps_jitter)

        # ---------- 8. Greedy log-det maximization ----------
        # First: highest quality among eligible tokens
        q_masked = q.clone()
        q_masked[~candidate_mask] = float("-inf")
        first_idx = torch.argmax(q_masked).item()

        selected = [first_idx]
        is_remaining = torch.ones(N, dtype=torch.bool, device=device)
        is_remaining[~candidate_mask] = False
        is_remaining[first_idx] = False

        # Initialize Cholesky factor of L[selected, selected]
        L_chol = torch.sqrt(L[first_idx, first_idx].clone().detach()).unsqueeze(0).unsqueeze(0)

        for step in range(1, k):
            cands = torch.where(is_remaining)[0]
            if cands.numel() == 0:
                break

            l_cS = L[cands][:, selected]  # (C, step)
            l_cc = L[cands, cands]        # (C,)

            # Solve L_chol @ z = l_cS.T  ->  z: (step, C)
            z = torch.linalg.solve_triangular(L_chol, l_cS.T, upper=False)
            var = (z ** 2).sum(dim=0)     # (C,)
            cond_num = l_cc - var

            gains = torch.full_like(cond_num, float("-inf"))
            valid = cond_num > 0
            gains[valid] = torch.log(cond_num[valid])

            best_local = torch.argmax(gains)
            best_cand = cands[best_local].item()
            selected.append(best_cand)
            is_remaining[best_cand] = False

            # Incremental Cholesky update
            z_best = z[:, best_local]     # (step,)
            cond_best = max(cond_num[best_local].item(), 1e-12)
            sqrt_cond = torch.sqrt(torch.tensor(cond_best, device=device, dtype=L_chol.dtype))

            new_size = step + 1
            L_chol_new = torch.zeros(new_size, new_size, device=device, dtype=L_chol.dtype)
            L_chol_new[:step, :step] = L_chol
            L_chol_new[step, :step] = z_best
            L_chol_new[step, step] = sqrt_cond
            L_chol = L_chol_new

        selected_indices = torch.tensor(selected, dtype=torch.long, device=device)
        if self.sort_indices:
            selected_indices = torch.sort(selected_indices).values
        selected_tokens = vision_tokens[selected_indices]
        return selected_indices, selected_tokens
