# MMTok: Multimodal Coverage Maximization for Efficient Inference of VLMs
# Paper: https://arxiv.org/abs/2508.18264
# Copyright (c) 2025 Zoom Communications, Inc.
# Licensed under the Apache License, Version 2.0

"""
Spatially-Constrained Greedy Selector.

Selects vision tokens by semantic relevance while enforcing a minimum spatial
separation between selected tokens:
1. Compute per-token semantic relevance via cosine similarity to the mean-pooled
   text query embedding.
2. Sort tokens by relevance descending.
3. Greedily accept a token only if it is at least `delta` grid units away from
   all previously accepted tokens.
4. If the spatial constraint leaves fewer than K tokens, fill the remainder
   with the next highest-scoring remaining tokens.
"""

import math
from typing import List, Optional, Tuple

import torch
import torch.nn.functional as F


class SpatialConstrainedSelector:
    """
    Spatially-constrained greedy vision token selector.
    """

    def __init__(
        self,
        target_vision_tokens: int = 64,
        delta: Optional[float] = None,
        sort_indices: bool = True,
    ):
        self.target_vision_tokens = target_vision_tokens
        self.delta = delta
        self.sort_indices = sort_indices

    @torch.no_grad()
    def mm_coverage_selection(
        self,
        text_token_embedding: torch.Tensor,
        vision_tokens: torch.Tensor,
        vision_tokens_clip: torch.Tensor,
        tv_temp: float = 0.01,
        vv_temp: float = 0.2,
        padding_patch_indices: Optional[List[int]] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Apply spatially-constrained greedy selection on vision tokens.

        Args:
            text_token_embedding: [L, D] text token embeddings (question/keywords).
            vision_tokens: [N, D] mm_projector output tokens.
            vision_tokens_clip: Unused (interface compatibility).
            tv_temp: Unused (interface compatibility).
            vv_temp: Unused (interface compatibility).
            padding_patch_indices: Optional list of indices to exclude from selection.

        Returns:
            selected_indices: [K] LongTensor of selected token indices.
            selected_tokens: [K, D] selected vision tokens.
        """
        device = vision_tokens.device
        N = vision_tokens.size(0)
        k = min(self.target_vision_tokens, N)

        if k <= 0:
            selected_indices = torch.empty(0, dtype=torch.long, device=device)
            selected_tokens = torch.empty(
                0, vision_tokens.size(1), device=device, dtype=vision_tokens.dtype
            )
            return selected_indices, selected_tokens
        elif k >= N or N == 0:
            selected_indices = torch.arange(N, device=device)
            return selected_indices, vision_tokens

        # Candidate mask excluding padding patches
        candidate_mask = torch.ones(N, dtype=torch.bool, device=device)
        if padding_patch_indices is not None and len(padding_patch_indices) > 0:
            if isinstance(padding_patch_indices, torch.Tensor):
                pad_idx = padding_patch_indices.to(device)
            else:
                pad_idx = torch.tensor(padding_patch_indices, dtype=torch.long, device=device)
            candidate_mask[pad_idx] = False

        num_eligible = candidate_mask.sum().item()
        if k >= num_eligible:
            selected_indices = torch.where(candidate_mask)[0]
            return selected_indices, vision_tokens[selected_indices]

        k = min(k, num_eligible)

        # ---------- 1. Query embedding and semantic scores ----------
        if text_token_embedding is not None and text_token_embedding.numel() > 0:
            q = text_token_embedding.mean(dim=0)  # [D]
        else:
            q = torch.zeros(vision_tokens.size(1), device=device, dtype=vision_tokens.dtype)

        feat_norm = F.normalize(vision_tokens, p=2, dim=-1, eps=1e-8)
        q_norm = F.normalize(q, p=2, dim=-1, eps=1e-8)
        scores = (feat_norm * q_norm).sum(dim=-1)  # [N]

        # ---------- 2. Spatial coordinates ----------
        H = W = int(math.sqrt(N))
        if H * W != N:
            W = math.ceil(math.sqrt(N))
            H = (N + W - 1) // W  # ceiling division

        y_coords, x_coords = torch.meshgrid(
            torch.arange(H, device=device),
            torch.arange(W, device=device),
            indexing="ij",
        )
        coords = torch.stack([y_coords.flatten(), x_coords.flatten()], dim=1)[:N].float()

        # ---------- 3. Distance threshold ----------
        delta = self.delta if self.delta is not None else max(1.0, math.sqrt(N / k))

        # ---------- 4. Greedy constrained selection ----------
        sorted_scores, sorted_idx = torch.sort(scores, descending=True)
        is_selected = torch.zeros(N, dtype=torch.bool, device=device)
        # Exclude padding from the start
        is_selected[~candidate_mask] = True

        selected_coords = torch.empty((k, 2), dtype=coords.dtype, device=device)
        num_selected = 0

        for idx in sorted_idx.tolist():
            if num_selected >= k:
                break
            if is_selected[idx]:
                continue

            ci = coords[idx].unsqueeze(0)  # [1, 2]
            if num_selected == 0:
                is_selected[idx] = True
                selected_coords[0] = ci
                num_selected += 1
            else:
                dists = torch.norm(selected_coords[:num_selected] - ci, p=2, dim=1)
                if dists.min().item() >= delta:
                    is_selected[idx] = True
                    selected_coords[num_selected] = ci
                    num_selected += 1

        # ---------- 5. Fallback: fill with top remaining scores ----------
        if num_selected < k:
            remaining_mask = ~is_selected
            # sorted_idx ordered by score; keep only those still remaining
            remaining_sorted_idx = sorted_idx[remaining_mask[sorted_idx]]
            fill_k = k - num_selected
            fill_indices = remaining_sorted_idx[:fill_k].tolist()
            for idx in fill_indices:
                is_selected[idx] = True
                selected_coords[num_selected] = coords[idx]
                num_selected += 1

        selected_indices = torch.nonzero(is_selected).squeeze(1)[:k]
        if self.sort_indices:
            selected_indices = torch.sort(selected_indices).values
        selected_tokens = vision_tokens[selected_indices]
        return selected_indices, selected_tokens
