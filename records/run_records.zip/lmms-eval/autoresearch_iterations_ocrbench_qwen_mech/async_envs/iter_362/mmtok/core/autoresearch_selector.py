# MMTok: Multimodal Coverage Maximization for Efficient Inference of VLMs
# Paper: https://arxiv.org/abs/2508.18264
# Copyright (c) 2025 Zoom Communications, Inc.
# Author: Anonymous
# Licensed under the Apache License, Version 2.0

"""
Qwen2.5-VL algorithm core: query-aware vision token selection.

This file contains the algorithmic core for vision token selection in Qwen2.5-VL.
The Coder Agent modifies the region between ALGORITHM CORE placeholders to experiment
with new selection algorithms, while the model file (qwen2_5_VLmodel_mmtok.py) handles
the fixed post-processing (compaction, padding, position_ids/attention_mask updates).
"""

import torch
import torch.nn.functional as F
from typing import List, Optional, Tuple


class QwenAlgorithmCore:
    """
    Algorithm core for Qwen2.5-VL vision token selection.

    Separates the selection algorithm from the model's forward-pass plumbing,
    enabling safe AutoResearch experiments on the algorithm without risking
    the multimodal sequence post-processing logic.
    """

    def __init__(self, mmtok_core=None):
        self.mmtok_core = mmtok_core

    def select_vision_tokens(
        self,
        image_embeds: torch.Tensor,
        image_features: torch.Tensor,
        question: str = "",
        target_vision_tokens: int = None,
        image_grid_thw: torch.Tensor = None,
        text_token_embedding: torch.Tensor = None,
    ) -> torch.Tensor:
        """
        Select vision tokens for a single sample.

        Args:
            image_embeds: [N, D] mm_projector output embeddings.
            image_features: [N, D] CLIP-space vision features.
            question: Question text string.
            target_vision_tokens: Target number of tokens to retain.
            image_grid_thw: [3] or [num_images, 3] grid shape (optional).

        Returns:
            selected_indices: [K] torch.long, indices of selected vision tokens.
        """
        if target_vision_tokens is None:
            target_vision_tokens = getattr(
                self.mmtok_core, "target_vision_tokens", 64
            )

        # --- ALGORITHM CORE START ---
        N, d_feat = image_features.shape
        device = image_features.device

        # Convert to float32 once
        feats = image_features.float()  # (N, d_feat)

        # Parameters (hardcoded as per algorithm design)
        lambda_risk = 0.1
        alpha_reg = 0.01
        neighbour_window = 5

        # Robust 2D grid factorization
        H = int(N ** 0.5)
        while H > 1 and N % H != 0:
            H -= 1
        W = N // H

        half = neighbour_window // 2
        idx_map = torch.arange(N, device=device).reshape(H, W)

        # ---- Precompute neighbor indices and find max neighbors ----
        neighbor_list = []          # list of lists of indices for each token
        max_m = 0
        for r in range(H):
            for c in range(W):
                r_min, r_max = max(0, r - half), min(H, r + half + 1)
                c_min, c_max = max(0, c - half), min(W, c + half + 1)
                neigh_block = idx_map[r_min:r_max, c_min:c_max].reshape(-1)
                i_center = idx_map[r, c]
                mask = neigh_block != i_center
                neigh_idx = neigh_block[mask].tolist()  # Python list
                neighbor_list.append(neigh_idx)
                max_m = max(max_m, len(neigh_idx))

        # Build padded neighbor index tensor and validity mask
        neighbor_idx_all = torch.full((N, max_m), -1, dtype=torch.long, device=device)
        valid_mask = torch.zeros(N, max_m, dtype=torch.bool, device=device)
        for i in range(N):
            n_idx = neighbor_list[i]
            m_i = len(n_idx)
            neighbor_idx_all[i, :m_i] = torch.tensor(n_idx, device=device, dtype=torch.long)
            valid_mask[i, :m_i] = True

        # Gather neighbor features: shape (N, max_m, d_feat)
        # Clamp -1 → 0 to avoid out-of-bounds, then zero out invalid rows later
        safe_idx = neighbor_idx_all.clamp(min=0)          # (N, max_m)
        X_all = feats[safe_idx]                           # (N, max_m, d_feat)
        X_all[~valid_mask] = 0.0                           # invalid → zero

        # ---- Batched dual-coefficient regression ----
        # Compute A_i = X_i X_i^T + alpha * I  for all i
        # X_all @ X_all.transpose(-2,-1): (N, max_m, max_m)
        Gram = X_all @ X_all.transpose(-2, -1)             # (N, max_m, max_m)
        A_all = Gram + alpha_reg * torch.eye(max_m, device=device, dtype=torch.float32).unsqueeze(0)

        # RHS: (X_i) @ y_i  where y_i = feats[i]  (d_feat,)
        # X_all[i, j, :] dot feats[i]  → (N, max_m)
        y_exp = feats.unsqueeze(1)                         # (N, 1, d_feat)
        RHS = (X_all * y_exp).sum(dim=2)                   # (N, max_m)

        # Solve batched linear systems: b_i = A_i^{-1} * RHS_i
        # torch.linalg.solve expects (N, *, *, *) and (N, *, *) for RHS
        b_batch = torch.linalg.solve(A_all, RHS.unsqueeze(-1)).squeeze(-1)  # (N, max_m)

        # Utility = alpha_reg * ||b_i||_2
        utility = alpha_reg * torch.norm(b_batch, dim=1, p=2)  # (N,)

        # Risk = log(cond(A_i))
        eigs = torch.linalg.eigvalsh(A_all)                  # (N, max_m) ascending
        eps = 1e-8
        cond = (eigs[:, -1] + eps) / (eigs[:, 0] + eps)      # (N,)
        risk = torch.log(cond + eps)                          # (N,)

        # Score
        scores = utility - lambda_risk * risk                  # (N,)

        # Select top-k (boundary handled by caller)
        _, selected_indices = torch.topk(scores, k=target_vision_tokens)
        selected_indices = selected_indices.sort()[0]          # ascending order
        # --- ALGORITHM CORE END ---

        return selected_indices

    def select_vision_tokens_batch(
        self,
        image_embeds_list,
        image_features_list,
        questions,
        target_vision_tokens_list,
        image_grid_thw_list=None,
    ):
        """
        Select vision tokens for a batch of samples.

        Args:
            image_embeds_list: List of [N_i, D] tensors.
            image_features_list: List of [N_i, D] tensors.
            questions: List of question strings.
            target_vision_tokens_list: List of target token counts.
            image_grid_thw_list: Optional list of grid shapes.

        Returns:
            selected_indices_list: List of [K_i] tensors.
        """
        selected_indices_list = []
        n = len(image_embeds_list)
        for i in range(n):
            emb = image_embeds_list[i]
            feat = image_features_list[i]
            q = questions[i] if i < len(questions) else questions[-1]
            tgt = (
                target_vision_tokens_list[i]
                if i < len(target_vision_tokens_list)
                else target_vision_tokens_list[-1]
            )
            grid = None
            if image_grid_thw_list is not None and i < len(image_grid_thw_list):
                grid = image_grid_thw_list[i]

            selected_indices = self.select_vision_tokens(
                emb, feat, q, target_vision_tokens=tgt, image_grid_thw=grid
            )
            selected_indices_list.append(selected_indices)

        return selected_indices_list


# ---------------------------------------------------------------------------
# AutoResearchSelector wrapper
# ---------------------------------------------------------------------------
# mmtok/qwen/mmtok_core.py imports AutoResearchSelector from this module and
# expects it to expose the same interface as the selectors in mmtok/qwen/
# (i.e. __init__(target_vision_tokens, alpha) and mm_coverage_selection(...)).
# The QwenAlgorithmCore class above is the actual target that the Coder Agent
# patches; this thin wrapper adapts it to the interface expected by MMTokCore.
# ---------------------------------------------------------------------------


class AutoResearchSelector:
    """
    Adapter that exposes the MMTok selector interface on top of
    QwenAlgorithmCore (the file that the AutoResearch Coder Agent modifies).
    """

    def __init__(self, target_vision_tokens: int = 32, alpha: float = 0.5):
        self.target_vision_tokens = target_vision_tokens
        self.alpha = alpha
        # QwenAlgorithmCore only needs mmtok_core for a default
        # target_vision_tokens fallback; passing None is safe because we always
        # supply target_vision_tokens explicitly in the call below.
        self._core = QwenAlgorithmCore(mmtok_core=None)

    def mm_coverage_selection(
        self,
        text_token_embedding: torch.Tensor,
        vision_tokens: torch.Tensor,
        vision_tokens_clip: torch.Tensor,
        tv_temp: float = 0.01,
        vv_temp: float = 0.2,
        padding_patch_indices: Optional[List[int]] = None,
    ) -> Tuple[List[int], torch.Tensor]:
        """
        Run the algorithm core and return results in the format expected by
        MMTokCore.select_vision_tokens.

        Args / Returns follow the contract of the other selectors in
        mmtok/qwen/ (e.g. semantic_selector.py).
        """
        # QwenAlgorithmCore.select_vision_tokens returns a [K] torch.long tensor.
        selected_indices_tensor = self._core.select_vision_tokens(
            image_embeds=vision_tokens,
            image_features=vision_tokens_clip,
            question="",
            target_vision_tokens=self.target_vision_tokens,
            text_token_embedding=text_token_embedding,
        )

        # Convert to Python list to match the selector contract.
        selected_indices = selected_indices_tensor.tolist()
        # Guard against scalar tensor (when only one index is selected).
        if not isinstance(selected_indices, list):
            selected_indices = torch.tensor([selected_indices], dtype=torch.long, device=image_embeds.device)
        selected_tokens = vision_tokens[selected_indices_tensor]
        return selected_indices, selected_tokens
