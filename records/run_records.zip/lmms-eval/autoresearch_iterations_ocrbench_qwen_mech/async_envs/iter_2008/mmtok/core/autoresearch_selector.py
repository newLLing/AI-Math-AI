# MMTok: Multimodal Coverage Maximization for Efficient Inference of VLMs
# Paper: https://arxiv.org/abs/2508.18264
# Copyright (c) 2025 Zoom Communications, Inc.
# Author: Anonymous
# Licensed under the Apache License, Version 2.0

"""
Qwen2.5-VL algorithm core: query-aware vision token selection.

This file contains the algorithmic core for vision token selection in Qwen2.5-VL.
The Coder Agent modifies the region between ALGORITHM CORE placeholders to experiment
with new selection algorithms, while the model file (qwen2_5_VLmodel_mmtok.py) handles
the fixed post-processing (compaction, padding, position_ids/attention_mask updates).
"""

import torch
import torch.nn.functional as F
from typing import List, Optional, Tuple


class QwenAlgorithmCore:
    """
    Algorithm core for Qwen2.5-VL vision token selection.

    Separates the selection algorithm from the model's forward-pass plumbing,
    enabling safe AutoResearch experiments on the algorithm without risking
    the multimodal sequence post-processing logic.
    """

    def __init__(self, mmtok_core=None):
        self.mmtok_core = mmtok_core

    def select_vision_tokens(
        self,
        image_embeds: torch.Tensor,
        image_features: torch.Tensor,
        question: str = "",
        target_vision_tokens: int = None,
        image_grid_thw: torch.Tensor = None,
        text_token_embedding: torch.Tensor = None,
    ) -> torch.Tensor:
        """
        Select vision tokens for a single sample.

        Args:
            image_embeds: [N, D] mm_projector output embeddings.
            image_features: [N, D] CLIP-space vision features.
            question: Question text string.
            target_vision_tokens: Target number of tokens to retain.
            image_grid_thw: [3] or [num_images, 3] grid shape (optional).

        Returns:
            selected_indices: [K] torch.long, indices of selected vision tokens.
        """
        if target_vision_tokens is None:
            target_vision_tokens = getattr(
                self.mmtok_core, "target_vision_tokens", 64
            )

        # --- ALGORITHM CORE START ---
        N = image_embeds.shape[0]
        device = image_embeds.device
        k = int(target_vision_tokens)

        def _bandwidth_from_dist2(D2, eps=1e-6):
            n = D2.shape[0]
            if n <= 1:
                return torch.ones((), device=device, dtype=torch.float32)
            triu_i, triu_j = torch.triu_indices(n, n, 1)
            triu_i = triu_i.to(device)
            triu_j = triu_j.to(device)
            triu = D2[triu_i, triu_j]
            med = triu.median()
            if med <= 1e-12:
                med = triu.mean() + eps
            return torch.sqrt(med / 2.0)

        def _rbf_from_dist2(D2, sigma, eps=1e-12):
            return torch.exp(-D2 / (2.0 * sigma * sigma + eps))

        def _center(K):
            row_mean = K.mean(dim=1, keepdim=True)
            col_mean = K.mean(dim=0, keepdim=True)
            grand = K.mean()
            return K - row_mean - col_mean + grand

        def _pairwise_dist2_from_subset(indices):
            # Vectorized squared Euclidean distance for a feature subset.
            Xs = X[:, indices]
            Gs = Xs @ Xs.T
            D2 = (Gs.diag().unsqueeze(1) + Gs.diag().unsqueeze(0) - 2.0 * Gs)
            return D2.clamp_min(0.0)

        if N == 0:
            selected_indices = torch.empty(0, dtype=torch.long, device=device)
        elif k <= 0:
            selected_indices = torch.empty(0, dtype=torch.long, device=device)
        elif k >= N:
            selected_indices = torch.arange(N, device=device, dtype=torch.long)
        else:
            # Use the primary vision embeddings for selection. This avoids
            # hidden/token-count mismatches between image_embeds and image_features.
            # Limit the feature dimension to at most 1024 for stable kernel computation.
            X = image_embeds.float().to(device)[:, :1024]
            d = X.shape[1]

            if X.var(dim=0).sum() < 1e-8:
                idx = torch.linspace(0, N - 1, steps=k, device=device).round().long()
                idx = torch.unique(idx)[:k]
                selected_indices = idx.sort()[0]
            else:
                half = max(1, d // 2)
                all_idx = torch.arange(d, device=device)
                even = all_idx[::2]
                odd = all_idx[1::2]

                var = X.var(dim=0)
                var_order = torch.argsort(var, descending=True)
                var_a = var_order[:half]
                var_b = var_order[half:]

                base_a = all_idx[:half]
                base_b = all_idx[half:]

                tasks = [
                    {"a_idx": base_a, "b_idx": base_b, "s_a": 1.0, "s_b": 1.0},
                    {"a_idx": even, "b_idx": odd, "s_a": 1.0, "s_b": 1.0},
                    {"a_idx": var_a, "b_idx": var_b, "s_a": 1.0, "s_b": 1.0},
                    {"a_idx": base_a, "b_idx": base_b, "s_a": 1.8, "s_b": 1.8},
                ]

                C_list = []
                row_sum_list = []
                diag_list = []
                Q_list = []

                for task in tasks:
                    a_idx = task["a_idx"]
                    b_idx = task["b_idx"]
                    if a_idx.numel() == 0 or b_idx.numel() == 0:
                        continue

                    # Vectorized pairwise squared distances on selected feature subsets.
                    D2a = _pairwise_dist2_from_subset(a_idx)
                    D2b = _pairwise_dist2_from_subset(b_idx)

                    sigma_a = _bandwidth_from_dist2(D2a) * task["s_a"]
                    sigma_b = _bandwidth_from_dist2(D2b) * task["s_b"]

                    K = _rbf_from_dist2(D2a, sigma_a)
                    L = _rbf_from_dist2(D2b, sigma_b)

                    Kc = _center(K)
                    Lc = _center(L)

                    C = Kc * Lc

                    C_list.append(C)
                    row_sum_list.append(C.sum(dim=1))
                    diag_list.append(C.diag())
                    Q_list.append(C.sum())

                num_tasks = len(C_list)
                if num_tasks == 0:
                    idx = torch.linspace(0, N - 1, steps=k, device=device).round().long()
                    idx = torch.unique(idx)[:k]
                    selected_indices = idx.sort()[0]
                else:
                    n = N
                    active = torch.ones(N, dtype=torch.bool, device=device)
                    inv_b = 1.0 / float(num_tasks)
                    neg_inf = torch.tensor(float("-inf"), dtype=torch.float32, device=device)

                    while n > k:
                        score = torch.zeros(N, dtype=torch.float32, device=device)
                        for b in range(num_tasks):
                            score += (2.0 * row_sum_list[b] - diag_list[b]) * inv_b

                        score = torch.where(active, score, neg_inf)
                        r = torch.argmax(score)

                        for b in range(num_tasks):
                            D_r = 2.0 * row_sum_list[b][r] - diag_list[b][r]
                            Q_list[b] -= D_r
                            c_col = C_list[b][:, r]
                            row_sum_list[b] = torch.where(
                                active,
                                row_sum_list[b] - c_col,
                                row_sum_list[b]
                            )

                        active[r] = False
                        n -= 1

                    selected_indices = torch.nonzero(active, as_tuple=False).squeeze(1)
                    selected_indices = selected_indices.sort()[0]
        # --- ALGORITHM CORE END ---

        return selected_indices

    def select_vision_tokens_batch(
        self,
        image_embeds_list,
        image_features_list,
        questions,
        target_vision_tokens_list,
        image_grid_thw_list=None,
    ):
        """
        Select vision tokens for a batch of samples.

        Args:
            image_embeds_list: List of [N_i, D] tensors.
            image_features_list: List of [N_i, D] tensors.
            questions: List of question strings.
            target_vision_tokens_list: List of target token counts.
            image_grid_thw_list: Optional list of grid shapes.

        Returns:
            selected_indices_list: List of [K_i] tensors.
        """
        selected_indices_list = []
        n = len(image_embeds_list)
        for i in range(n):
            emb = image_embeds_list[i]
            feat = image_features_list[i]
            q = questions[i] if i < len(questions) else questions[-1]
            tgt = (
                target_vision_tokens_list[i]
                if i < len(target_vision_tokens_list)
                else target_vision_tokens_list[-1]
            )
            grid = None
            if image_grid_thw_list is not None and i < len(image_grid_thw_list):
                grid = image_grid_thw_list[i]

            selected_indices = self.select_vision_tokens(
                emb, feat, q, target_vision_tokens=tgt, image_grid_thw=grid
            )
            selected_indices_list.append(selected_indices)

        return selected_indices_list


# ---------------------------------------------------------------------------
# AutoResearchSelector wrapper
# ---------------------------------------------------------------------------
# mmtok/qwen/mmtok_core.py imports AutoResearchSelector from this module and
# expects it to expose the same interface as the selectors in mmtok/qwen/
# (i.e. __init__(target_vision_tokens, alpha) and mm_coverage_selection(...)).
# The QwenAlgorithmCore class above is the actual target that the Coder Agent
# patches; this thin wrapper adapts it to the interface expected by MMTokCore.
# ---------------------------------------------------------------------------


class AutoResearchSelector:
    """
    Adapter that exposes the MMTok selector interface on top of
    QwenAlgorithmCore (the file that the AutoResearch Coder Agent modifies).
    """

    def __init__(self, target_vision_tokens: int = 32, alpha: float = 0.5):
        self.target_vision_tokens = target_vision_tokens
        self.alpha = alpha
        # QwenAlgorithmCore only needs mmtok_core for a default
        # target_vision_tokens fallback; passing None is safe because we always
        # supply target_vision_tokens explicitly in the call below.
        self._core = QwenAlgorithmCore(mmtok_core=None)

    def mm_coverage_selection(
        self,
        text_token_embedding: torch.Tensor,
        vision_tokens: torch.Tensor,
        vision_tokens_clip: torch.Tensor,
        tv_temp: float = 0.01,
        vv_temp: float = 0.2,
        padding_patch_indices: Optional[List[int]] = None,
    ) -> Tuple[List[int], torch.Tensor]:
        """
        Run the algorithm core and return results in the format expected by
        MMTokCore.select_vision_tokens.

        Args / Returns follow the contract of the other selectors in
        mmtok/qwen/ (e.g. semantic_selector.py).
        """
        # QwenAlgorithmCore.select_vision_tokens returns a [K] torch.long tensor.
        selected_indices_tensor = self._core.select_vision_tokens(
            image_embeds=vision_tokens,
            image_features=vision_tokens_clip,
            question="",
            target_vision_tokens=self.target_vision_tokens,
            text_token_embedding=text_token_embedding,
        )

        # Convert to Python list to match the selector contract.
        selected_indices = selected_indices_tensor.tolist()
        # Guard against scalar tensor (when only one index is selected).
        if not isinstance(selected_indices, list):
            selected_indices = torch.tensor([selected_indices], dtype=torch.long, device=image_embeds.device)
        selected_tokens = vision_tokens[selected_indices_tensor]
        return selected_indices, selected_tokens