# MMTok: Multimodal Coverage Maximization for Efficient Inference of VLMs
# Paper: https://arxiv.org/abs/2508.18264
# Copyright (c) 2025 Zoom Communications, Inc.
# Author: Anonymous
# Licensed under the Apache License, Version 2.0

"""
Qwen2.5-VL algorithm core: query-aware vision token selection.

This file contains the algorithmic core for vision token selection in Qwen2.5-VL.
The Coder Agent modifies the region between ALGORITHM CORE placeholders to experiment
with new selection algorithms, while the model file (qwen2_5_VLmodel_mmtok.py) handles
the fixed post-processing (compaction, padding, position_ids/attention_mask updates).
"""

import torch
import torch.nn.functional as F
from typing import List, Optional, Tuple


class QwenAlgorithmCore:
    """
    Algorithm core for Qwen2.5-VL vision token selection.

    Separates the selection algorithm from the model's forward-pass plumbing,
    enabling safe AutoResearch experiments on the algorithm without risking
    the multimodal sequence post-processing logic.
    """

    def __init__(self, mmtok_core=None):
        self.mmtok_core = mmtok_core

    def select_vision_tokens(
        self,
        image_embeds: torch.Tensor,
        image_features: torch.Tensor,
        question: str = "",
        target_vision_tokens: int = None,
        image_grid_thw: torch.Tensor = None,
        text_token_embedding: torch.Tensor = None,
    ) -> torch.Tensor:
        """
        Select vision tokens for a single sample.

        Args:
            image_embeds: [N, D] mm_projector output embeddings.
            image_features: [N, D] CLIP-space vision features.
            question: Question text string.
            target_vision_tokens: Target number of tokens to retain.
            image_grid_thw: [3] or [num_images, 3] grid shape (optional).

        Returns:
            selected_indices: [K] torch.long, indices of selected vision tokens.
        """
        if target_vision_tokens is None:
            target_vision_tokens = getattr(
                self.mmtok_core, "target_vision_tokens", 64
            )

        # --- ALGORITHM CORE START ---
        import math

        N = image_embeds.shape[0]
        k = int(target_vision_tokens)
        device = image_embeds.device
        eps = 1e-6

        # Online Renyi information-bottleneck hyperparameters
        lam = 0.20
        lr = 0.15
        T = 20

        X = image_embeds.to(device=device, dtype=torch.float32)
        row_norm = torch.linalg.vector_norm(X, dim=1, keepdim=True)

        # Degenerate visual embeddings: explicit boundary fallback.
        if row_norm.sum() <= eps:
            selected_indices = torch.randperm(N, device=device)[:k]
            selected_indices = torch.sort(selected_indices)[0]
        else:
            zero_mask = (row_norm <= eps).squeeze(1)
            X = X / row_norm.clamp_min(eps)

            # Text query is required by this matrix-Renyi IB objective.
            if text_token_embedding is None or text_token_embedding.numel() == 0:
                selected_indices = torch.randperm(N, device=device)[:k]
                selected_indices = torch.sort(selected_indices)[0]
            else:
                Q = text_token_embedding.to(device=device, dtype=torch.float32)
                M = Q.shape[0]

                if M == 0:
                    selected_indices = torch.randperm(N, device=device)[:k]
                    selected_indices = torch.sort(selected_indices)[0]
                else:
                    q_norm = torch.linalg.vector_norm(Q, dim=1, keepdim=True)
                    Q = Q / q_norm.clamp_min(eps)

                    # Linear-kernel Gram matrices and the elementwise-squared visual Gram.
                    G_xx = X @ X.T.to(X.dtype)                # [N, N]
                    G_xq = X @ Q.T.to(X.dtype)                # [N, M]
                    G_qq = Q @ Q.T.to(Q.dtype)                # [M, M]

                    A = G_xx * G_xx               # [N, N]

                    # Collision entropy weights in the unnormalized visual space.
                    h = torch.ones(N, device=device, dtype=torch.float32)
                    if zero_mask.any():
                        h = h.masked_fill(zero_mask, 0.0)

                    r = (G_xq * G_xq).sum(dim=1)  # [N]
                    c1 = torch.diag(G_qq).sum().clamp_min(eps)
                    c2 = (G_qq * G_qq).sum().clamp_min(eps)

                    if h.sum() <= eps:
                        selected_indices = torch.randperm(N, device=device)[:k]
                        selected_indices = torch.sort(selected_indices)[0]
                    else:
                        # Logit-space initialization around the target inclusion rate.
                        w0 = float(k) / float(N)
                        w0 = min(max(w0, 1e-4), 0.999)
                        a = torch.full(
                            (N,),
                            math.log(w0 / (1.0 - w0)),
                            device=device,
                            dtype=torch.float32,
                        )
                        a = a + 0.01 * torch.randn(N, device=device, dtype=torch.float32)

                        # Online gradient ascent over soft inclusion weights.
                        for _ in range(T):
                            w = torch.sigmoid(a)
                            u = 1.0 - w

                            fw = A @ w.to(A.dtype)                # [N]
                            fu = A @ u.to(A.dtype)                # [N]

                            fS = torch.dot(w, fw).clamp_min(eps)
                            hS = torch.dot(w, h).clamp_min(eps)

                            fU = torch.dot(u, fu).clamp_min(eps)
                            hU = torch.dot(u, h).clamp_min(eps)

                            fSQ = fS + 2.0 * torch.dot(w, r) + c2
                            hSQ = hS + c1

                            grad_w = (
                                (2.0 * (fw + r) / fSQ.clamp_min(eps) - 2.0 * h / hSQ.clamp_min(eps))
                                - (1.0 - lam) * (2.0 * fw / fS.clamp_min(eps) - 2.0 * h / hS.clamp_min(eps))
                                + lam * (2.0 * h / hU.clamp_min(eps) - 2.0 * fu / fU.clamp_min(eps))
                            )

                            grad_a = grad_w * w * u

                            # Gradient clipping without CPU-GPU synchronization inside the loop.
                            gnorm = torch.norm(grad_a)
                            scale = torch.clamp(5.0 / gnorm.clamp_min(eps), max=1.0)
                            grad_a = grad_a * scale

                            a = a + lr * grad_a

                        w = torch.sigmoid(a)
                        if not torch.isfinite(w).all():
                            w = torch.full((N,), 1.0 / N, device=device, dtype=torch.float32)

                        selected_indices = torch.topk(w, k=k).indices.to(torch.long)
                        selected_indices = torch.sort(selected_indices)[0]
        # --- ALGORITHM CORE END ---

        return selected_indices

    def select_vision_tokens_batch(
        self,
        image_embeds_list,
        image_features_list,
        questions,
        target_vision_tokens_list,
        image_grid_thw_list=None,
    ):
        """
        Select vision tokens for a batch of samples.

        Args:
            image_embeds_list: List of [N_i, D] tensors.
            image_features_list: List of [N_i, D] tensors.
            questions: List of question strings.
            target_vision_tokens_list: List of target token counts.
            image_grid_thw_list: Optional list of grid shapes.

        Returns:
            selected_indices_list: List of [K_i] tensors.
        """
        selected_indices_list = []
        n = len(image_embeds_list)
        for i in range(n):
            emb = image_embeds_list[i]
            feat = image_features_list[i]
            q = questions[i] if i < len(questions) else questions[-1]
            tgt = (
                target_vision_tokens_list[i]
                if i < len(target_vision_tokens_list)
                else target_vision_tokens_list[-1]
            )
            grid = None
            if image_grid_thw_list is not None and i < len(image_grid_thw_list):
                grid = image_grid_thw_list[i]

            selected_indices = self.select_vision_tokens(
                emb, feat, q, target_vision_tokens=tgt, image_grid_thw=grid
            )
            selected_indices_list.append(selected_indices)

        return selected_indices_list


# ---------------------------------------------------------------------------
# AutoResearchSelector wrapper
# ---------------------------------------------------------------------------
# mmtok/qwen/mmtok_core.py imports AutoResearchSelector from this module and
# expects it to expose the same interface as the selectors in mmtok/qwen/
# (i.e. __init__(target_vision_tokens, alpha) and mm_coverage_selection(...)).
# The QwenAlgorithmCore class above is the actual target that the Coder Agent
# patches; this thin wrapper adapts it to the interface expected by MMTokCore.
# ---------------------------------------------------------------------------


class AutoResearchSelector:
    """
    Adapter that exposes the MMTok selector interface on top of
    QwenAlgorithmCore (the file that the AutoResearch Coder Agent modifies).
    """

    def __init__(self, target_vision_tokens: int = 32, alpha: float = 0.5):
        self.target_vision_tokens = target_vision_tokens
        self.alpha = alpha
        # QwenAlgorithmCore only needs mmtok_core for a default
        # target_vision_tokens fallback; passing None is safe because we always
        # supply target_vision_tokens explicitly in the call below.
        self._core = QwenAlgorithmCore(mmtok_core=None)

    def mm_coverage_selection(
        self,
        text_token_embedding: torch.Tensor,
        vision_tokens: torch.Tensor,
        vision_tokens_clip: torch.Tensor,
        tv_temp: float = 0.01,
        vv_temp: float = 0.2,
        padding_patch_indices: Optional[List[int]] = None,
    ) -> Tuple[List[int], torch.Tensor]:
        """
        Run the algorithm core and return results in the format expected by
        MMTokCore.select_vision_tokens.

        Args / Returns follow the contract of the other selectors in
        mmtok/qwen/ (e.g. semantic_selector.py).
        """
        # QwenAlgorithmCore.select_vision_tokens returns a [K] torch.long tensor.
        selected_indices_tensor = self._core.select_vision_tokens(
            image_embeds=vision_tokens,
            image_features=vision_tokens_clip,
            question="",
            target_vision_tokens=self.target_vision_tokens,
            text_token_embedding=text_token_embedding,
        )

        # Convert to Python list to match the selector contract.
        selected_indices = selected_indices_tensor.tolist()
        # Guard against scalar tensor (when only one index is selected).
        if not isinstance(selected_indices, list):
            selected_indices = torch.tensor([selected_indices], dtype=torch.long, device=image_embeds.device)
        selected_tokens = vision_tokens[selected_indices_tensor]
        return selected_indices, selected_tokens