1. **Algorithm name and mathematical objective function**

**Algorithm name:** *Spatially-Weighted Isolation Gating (SWIG)*

**Mathematical objective (pure notation):**  
Let \(V = \{v_i = (f_i, p_i) \mid f_i \in \mathbb{R}^{d_f},\; p_i \in \mathbb{R}^{2}\}\) be a set of \(n\) points, where \(f_i\) are feature vectors and \(p_i\) are spatial coordinates.  
Define the composite metric  

\[
D(i,j) = \|f_i - f_j\|_2 \;+\; \gamma \,\|p_i - p_j\|_2 ,\qquad \gamma \ge 0,
\]

and the *isolation score* for each point  

\[
\eta_i = \min_{j \neq i} D(i,j).
\]

The token selection problem is:  

\[
S^* = \arg\max_{\substack{S \subseteq V \\ |S| = k}} \; \mathcal{H}(S),\qquad 
\mathcal{H}(S) = \sum_{i \in S} \eta_i .
\]

In words, we choose a size‑\(k\) subset that maximises the total isolation, i.e., the sum of nearest‑neighbour composite distances.

The selection is performed by a **gating operator**:  

\[
g_i = \mathbf{1}\!\bigl(\eta_i \ge \tau\bigr), \qquad 
\tau = \text{the }k\text{-th largest value of } \{\eta_i\}_{i=1}^{n},
\]

so that exactly \(k\) gates are open. This can be seen as MAP inference from the Gibbs measure  

\[
P(S) \propto \exp\!\bigl(\beta\,\mathcal{H}(S)\bigr) \quad (|S|=k)
\]

in the limit \(\beta\to\infty\).

---

2. **Mathematical Formalisation & Mapping Argument**

**a. Formalisation (set‑theoretic / optimisation)**  

Given the abstract points \(V\) and the distance function \(D\), we seek a subset of cardinality \(k\) that maximises the *sum of local isolation*.  
The objective is *additively separable*, meaning the contribution of each selected point is its own isolation score, independent of other selected points.  
This leads to a straightforward combinatorial optimisation:

\[
\max_{S} \sum_{i\in S} \eta_i \quad \text{s.t.} \quad |S| = k .
\]

Because the objective is linear in the indicator variables of \(S\), the optimal solution is simply the \(k\) points with the largest \(\eta_i\).

**b. Why the recalled theory is a natural solution**  

The recalled literature on *geodesic farthest‑point Voronoi diagrams* (Oh et al., 2018; Kim et al., 2022) studies sets of points that are “far” from a given site set and introduces the notion of *farthest‑point regions* – the geometric loci of points whose nearest site is maximally far.  
Our isolation score \(\eta_i = \min_{j\neq i} D(i,j)\) directly measures how “farthest” point \(i\) is from all other points, i.e., it is the distance to the nearest other point.  
Hence selecting points with maximal \(\eta_i\) is equivalent to picking points that lie in the largest (most isolated) Voronoi cells of the full point set – a principled geometric approach to diverse coverage.  
The gating mechanism (hard thresholding of these geometric scores) mimics the biological concept of *lateral inhibition*, where strong responses suppress weaker ones, leaving only the most distinct information channels open.

**c. Computational steps and PyTorch mapping**  

| Core computation | PyTorch API / approximation |
|------------------|-----------------------------|
| Feature distance matrix \(D_{\text{feat}} \in \mathbb{R}^{n\times n}\) | `torch.cdist(image_features, image_features, p=2)` |
| Spatial coordinate grid \(\{p_i\}\) (when \(n\) is a perfect square) | `H = W = int(n**0.5); grid = torch.stack(torch.meshgrid(torch.arange(H), torch.arange(W), indexing='ij'), dim=-1)` then flatten |
| Spatial distance matrix \(D_{\text{spat}}\) | `torch.cdist(coords_flat, coords_flat, p=2)` |
| Composite distance \(D\) | element‑wise addition: `D = D_feat + gamma * D_spat` |
| Ignore self‑distances | `D.fill_diagonal_(float('inf'))` |
| Isolation scores \(\eta_i\) | `eta = D.min(dim=1).values` |
| Top‑\(k\) selection (deterministic MAP) | `indices = torch.topk(eta, k, largest=True).indices` |
| Gating mask (if desired) | `mask = torch.zeros(n, dtype=torch.bool); mask[indices] = True` |

**d. Prohibited vanilla templates avoided**  
This algorithm uses **neither** farthest‑point‑sampling (FPS), nor random projection, nor K‑means clustering, nor cosine‑similarity ranking, nor cross‑attention. The core mechanism is a **global threshold gate** on a geometric isolation measure, which is conceptually and computationally distinct from all listed templates.

---

3. **Concrete forward computation graph and PyTorch pseudocode**

```python
import torch

def forward_selection(
    image_features: torch.Tensor,   # [N, token, 1280] but we assume batch=1, so [N, 1280]
    target_vision_tokens: int,
) -> tuple[torch.Tensor, torch.Tensor]:
    """
    Args:
        image_features: CLIP‑space vision tokens, shape [N, 1280]
        target_vision_tokens: k, number of tokens to retain.
    Returns:
        selected_indices: LongTensor of shape [k]
        selected_image_embeds: image_embeds should be provided externally, but here we only have image_features;
                               we will return the corresponding features as a placeholder.
                               In the actual hook we will extract from image_embeds.
    """
    N, d = image_features.shape
    k = target_vision_tokens

    # ── Boundary conditions ──
    if k <= 0 or N == 0:
        return torch.empty(0, dtype=torch.long, device=image_features.device), torch.empty(0, d, device=image_features.device)
    if k >= N:
        return torch.arange(N, device=image_features.device), image_features

    # ── Compute feature distance matrix ──
    # Use fp32 for numerical stability if input is fp16/bf16
    feat = image_features.float()
    D_feat = torch.cdist(feat, feat, p=2)                       # [N, N]

    # ── Spatial topology (assume square grid) ──
    H = W = int(N ** 0.5)
    # Only proceed if N is perfect square; else fallback to no spatial weighting (gamma=0)
    if H * W == N:
        y, x = torch.meshgrid(torch.arange(H, device=feat.device, dtype=torch.float32),
                              torch.arange(W, device=feat.device, dtype=torch.float32),
                              indexing='ij')
        coords = torch.stack([x, y], dim=-1).flatten(0, 1)      # [N, 2]
        # Normalise to roughly same scale as features
        coords = coords / coords.max()
        D_spat = torch.cdist(coords, coords, p=2)               # [N, N]
        gamma = 1.0       # hyperparameter (see suggestions)
        D = D_feat + gamma * D_spat
    else:
        D = D_feat          # fallback: feature distance only

    # ── Isolation score ──
    D.diagonal().fill_(float('inf'))          # ignore self
    eta = D.min(dim=1).values                 # [N]

    # ── Select top‑k by isolation (gating) ──
    _, selected_indices = torch.topk(eta, k, largest=True)

    # ── In the actual hook, we will have image_embeds available;
    #     here we just return indices and a dummy placeholder ──
    selected_image_embeds = image_features[selected_indices]   # dummy; replace with image_embeds in real use
    return selected_indices, selected_image_embeds
```

**Integration note:**  
Inside the `if select_pixel:` block, the function will be called with `image_features` (CLIP space), and then `selected_image_embeds` must be obtained from the projector output `image_embeds` using the same `selected_indices`.  
Because the algorithm is **pure diversity**, `text_token_embedding` is not accessed.

---

4. **Key hyperparameter suggestions**

- \(\gamma\): weight of spatial distance. Start with \(\gamma = 1.0\) after normalising spatial coordinates to \([0,1]\). Larger \(\gamma\) forces tokens to be more spatially spread out.  
- Coordinate normalisation: divide spatial coordinates by their maximum value so that they lie in \([0,1]\), making the spatial distance term compatible with the magnitude of CLIP feature distances.  
- If \(N\) is not a perfect square (e.g., non‑square image resolution), the spatial grid cannot be constructed; in that case the algorithm automatically falls back to feature‑only isolation (\(\gamma=0\)).  
- Optionally, the CLIP features may be \(L_2\)‑normalised before distance computation to emphasise angular diversity.

---

5. **Numerical stability precautions**

- **fp16 / bf16:** The distance matrix is computed in `float32` to avoid catastrophic cancellation and overflow.  
- **Self‑distance:** The diagonal is set to `inf` so that the nearest neighbour search ignores the point itself.  
- **Empty inputs:** If \(N=0\) or \(k=0\), an empty tensor is immediately returned.  
- **All‑zero embeddings:** If all features are zero, the distance matrix is zero everywhere; \(\eta_i = \infty\)? Actually D = inf on diagonal, others 0, so eta = 0 for all. Top‑k will select any k indices; algorithm remains robust, though selection is arbitrary, which is acceptable.  
- **Division by zero:** No division occurs.  
- **Spatial normalisation:** `coords / coords.max()` handles all positive values gracefully.

---

6. **Cited theoretical sources**

- *The Geodesic Farthest‑point Voronoi Diagram in a Simple Polygon* (arXiv:1802.06223) – uses farthest‑point Voronoi diagrams to identify points maximally far from existing sites, motivating isolation‑based selection.  
- *Farthest‑point Voronoi diagrams in the presence of rectangular obstacles* (arXiv:2203.03198) – extends the concept to constrained geometries, inspiring the inclusion of spatial topology as a secondary distance term.  
- Broadly, the idea of threshold gating on a geometric measure is rooted in **computational geometry** and the biological principle of lateral inhibition (neuroscience).

---

7. **Difference explanation from historical schemes**

- **Not FPS:** Farthest‑point sampling greedily builds a set by repeatedly picking the point farthest from the current set; our method computes a *global* isolation score per point and selects all \(k\) points at once.  
- **Not norm‑weighted FPS:** No point norms are used to bias selection.  
- **Not k‑means or ranking by similarity:** The selection is driven by a local geometric property (nearest‑neighbour distance) rather than cluster membership or text‑visual similarity.  
- **Gating mechanism:** The use of a hard threshold on isolation scores is a genuine gating operation – each token either passes or is blocked – unlike simple top‑\(k\) ranking which is often implemented as a sort; here we explicitly conceptualise and implement it as a binary gate derived from a geometric score.

---

8. **Primary Direction Declaration**

PRIMARY_DIRECTION: geometry  

*(The core mechanism is the geometric isolation score and its threshold gating, not an SVD, clustering, or attention‑based method.)*