# MMTok: Multimodal Coverage Maximization for Efficient Inference of VLMs
# Paper: https://arxiv.org/abs/2508.18264
# Copyright (c) 2025 Zoom Communications, Inc.
# Author: Anonymous
# Licensed under the Apache License, Version 2.0

"""
Qwen2.5-VL algorithm core: query-aware vision token selection.

This file contains the algorithmic core for vision token selection in Qwen2.5-VL.
The Coder Agent modifies the region between ALGORITHM CORE placeholders to experiment
with new selection algorithms, while the model file (qwen2_5_VLmodel_mmtok.py) handles
the fixed post-processing (compaction, padding, position_ids/attention_mask updates).
"""

import torch
import torch.nn.functional as F
from typing import List, Optional, Tuple


class QwenAlgorithmCore:
    """
    Algorithm core for Qwen2.5-VL vision token selection.

    Separates the selection algorithm from the model's forward-pass plumbing,
    enabling safe AutoResearch experiments on the algorithm without risking
    the multimodal sequence post-processing logic.
    """

    def __init__(self, mmtok_core=None):
        self.mmtok_core = mmtok_core

    def select_vision_tokens(
        self,
        image_embeds: torch.Tensor,
        image_features: torch.Tensor,
        question: str = "",
        target_vision_tokens: int = None,
        image_grid_thw: torch.Tensor = None,
        text_token_embedding: torch.Tensor = None,
    ) -> torch.Tensor:
        """
        Select vision tokens for a single sample.

        Args:
            image_embeds: [N, D] mm_projector output embeddings.
            image_features: [N, D] CLIP-space vision features.
            question: Question text string.
            target_vision_tokens: Target number of tokens to retain.
            image_grid_thw: [3] or [num_images, 3] grid shape (optional).

        Returns:
            selected_indices: [K] torch.long, indices of selected vision tokens.
        """
        if target_vision_tokens is None:
            target_vision_tokens = getattr(
                self.mmtok_core, "target_vision_tokens", 64
            )

        # --- ALGORITHM CORE START ---
        N = image_embeds.shape[0]
        K = target_vision_tokens
        device = image_embeds.device

        # use CLIP-space features (float32)
        F = image_features.float()  # (N, d_clip)

        # robust 2D grid factorization
        H = int(math.sqrt(N))
        while N % H != 0:
            H -= 1
        W = N // H

        # spatial coordinates
        grid_y, grid_x = torch.meshgrid(torch.arange(H, device=device),
                                        torch.arange(W, device=device), indexing='ij')
        grid_y, grid_x = grid_y.reshape(-1), grid_x.reshape(-1)

        # 4-neighbour edge list (undirected, unique)
        directions = [(0, 1), (1, 0), (0, -1), (-1, 0)]
        edge_list = []
        for dy, dx in directions:
            ny = grid_y + dy
            nx = grid_x + dx
            mask = (ny >= 0) & (ny < H) & (nx >= 0) & (nx < W)
            u = torch.arange(N, device=device)[mask]
            v = (ny[mask] * W + nx[mask])
            edge_list.append(torch.stack([u, v], dim=1))
        edge_index = torch.cat(edge_list, dim=0).t().contiguous()   # (2, E)
        mask = edge_index[0] < edge_index[1]
        edge_index = edge_index[:, mask]   # keep only one direction per edge
        E = edge_index.size(1)

        # normalized adjacency (A_hat) weights
        deg = torch.zeros(N, device=device).float()
        deg.scatter_add_(0, edge_index[0], torch.ones(E, device=device))
        deg.scatter_add_(0, edge_index[1], torch.ones(E, device=device))
        deg_safe = deg + 1e-8
        deg_inv_sqrt = deg_safe.pow(-0.5)
        weight = deg_inv_sqrt[edge_index[0]] * deg_inv_sqrt[edge_index[1]]  # (E,)

        # helper: multiply by A_hat
        def apply_A_hat(x):
            out = torch.zeros_like(x)
            src1 = x[edge_index[1]] * weight.unsqueeze(-1)
            out.scatter_add_(0, edge_index[0].unsqueeze(-1).expand_as(src1), src1)
            src2 = x[edge_index[0]] * weight.unsqueeze(-1)
            out.scatter_add_(0, edge_index[1].unsqueeze(-1).expand_as(src2), src2)
            return out

        # Chebyshev spectral filter (order 2)
        A_hat_F = apply_A_hat(F)
        L_F = F - A_hat_F
        A_hat_LF = apply_A_hat(L_F)
        L2_F = L_F - A_hat_LF
        # low-pass coefficients
        filtered = 1.0 * F - 0.5 * L_F + 0.25 * L2_F
        w = filtered.norm(dim=1)   # spectral importance (N,)

        # edge collapse cost
        f_u = F[edge_index[0]]
        f_v = F[edge_index[1]]
        dot = (f_u * f_v).sum(dim=1)
        norm_u = f_u.norm(dim=1)
        norm_v = f_v.norm(dim=1)
        cos_sim = dot / (norm_u * norm_v + 1e-8)
        cost = (w[edge_index[0]] + w[edge_index[1]]) * (1.0 - cos_sim)

        # greedy collapse using static edge order
        sorted_ord = torch.argsort(cost)  # ascending
        active = torch.ones(N, dtype=torch.bool, device=device)
        num_active = N

        for idx in sorted_ord:
            u = edge_index[0, idx].item()
            v = edge_index[1, idx].item()
            if active[u] and active[v]:
                # keep the one with higher spectral energy, remove the other
                if w[u] < w[v]:
                    remove, keep = u, v
                else:
                    remove, keep = v, u
                active[remove] = False
                num_active -= 1
                if num_active == K:
                    break

        # if we could not reach K by edge collapses (e.g., graph became disconnected),
        # deactivate the lowest-w tokens among the remaining active ones
        if num_active > K:
            active_idx = torch.where(active)[0]
            w_active = w[active_idx]
            _, order = torch.sort(w_active)   # ascending
            to_remove = active_idx[order[:num_active - K]]
            active[to_remove] = False
            num_active = K

        # gather and sort
        selected_indices = torch.where(active)[0]
        selected_indices, _ = torch.sort(selected_indices)
        # --- ALGORITHM CORE END ---

        return selected_indices

    def select_vision_tokens_batch(
        self,
        image_embeds_list,
        image_features_list,
        questions,
        target_vision_tokens_list,
        image_grid_thw_list=None,
    ):
        """
        Select vision tokens for a batch of samples.

        Args:
            image_embeds_list: List of [N_i, D] tensors.
            image_features_list: List of [N_i, D] tensors.
            questions: List of question strings.
            target_vision_tokens_list: List of target token counts.
            image_grid_thw_list: Optional list of grid shapes.

        Returns:
            selected_indices_list: List of [K_i] tensors.
        """
        selected_indices_list = []
        n = len(image_embeds_list)
        for i in range(n):
            emb = image_embeds_list[i]
            feat = image_features_list[i]
            q = questions[i] if i < len(questions) else questions[-1]
            tgt = (
                target_vision_tokens_list[i]
                if i < len(target_vision_tokens_list)
                else target_vision_tokens_list[-1]
            )
            grid = None
            if image_grid_thw_list is not None and i < len(image_grid_thw_list):
                grid = image_grid_thw_list[i]

            selected_indices = self.select_vision_tokens(
                emb, feat, q, target_vision_tokens=tgt, image_grid_thw=grid
            )
            selected_indices_list.append(selected_indices)

        return selected_indices_list


# ---------------------------------------------------------------------------
# AutoResearchSelector wrapper
# ---------------------------------------------------------------------------
# mmtok/qwen/mmtok_core.py imports AutoResearchSelector from this module and
# expects it to expose the same interface as the selectors in mmtok/qwen/
# (i.e. __init__(target_vision_tokens, alpha) and mm_coverage_selection(...)).
# The QwenAlgorithmCore class above is the actual target that the Coder Agent
# patches; this thin wrapper adapts it to the interface expected by MMTokCore.
# ---------------------------------------------------------------------------


class AutoResearchSelector:
    """
    Adapter that exposes the MMTok selector interface on top of
    QwenAlgorithmCore (the file that the AutoResearch Coder Agent modifies).
    """

    def __init__(self, target_vision_tokens: int = 32, alpha: float = 0.5):
        self.target_vision_tokens = target_vision_tokens
        self.alpha = alpha
        # QwenAlgorithmCore only needs mmtok_core for a default
        # target_vision_tokens fallback; passing None is safe because we always
        # supply target_vision_tokens explicitly in the call below.
        self._core = QwenAlgorithmCore(mmtok_core=None)

    def mm_coverage_selection(
        self,
        text_token_embedding: torch.Tensor,
        vision_tokens: torch.Tensor,
        vision_tokens_clip: torch.Tensor,
        tv_temp: float = 0.01,
        vv_temp: float = 0.2,
        padding_patch_indices: Optional[List[int]] = None,
    ) -> Tuple[List[int], torch.Tensor]:
        """
        Run the algorithm core and return results in the format expected by
        MMTokCore.select_vision_tokens.

        Args / Returns follow the contract of the other selectors in
        mmtok/qwen/ (e.g. semantic_selector.py).
        """
        # QwenAlgorithmCore.select_vision_tokens returns a [K] torch.long tensor.
        selected_indices_tensor = self._core.select_vision_tokens(
            image_embeds=vision_tokens,
            image_features=vision_tokens_clip,
            question="",
            target_vision_tokens=self.target_vision_tokens,
            text_token_embedding=text_token_embedding,
        )

        # Convert to Python list to match the selector contract.
        selected_indices = selected_indices_tensor.tolist()
        # Guard against scalar tensor (when only one index is selected).
        if not isinstance(selected_indices, list):
            selected_indices = torch.tensor([selected_indices], dtype=torch.long, device=image_embeds.device)
        selected_tokens = vision_tokens[selected_indices_tensor]
        return selected_indices, selected_tokens
