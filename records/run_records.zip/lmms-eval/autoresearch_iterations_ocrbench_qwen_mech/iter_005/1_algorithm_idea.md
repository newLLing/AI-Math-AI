**1. Algorithm name and mathematical objective function**

**Name:** Projection-Transport Equilibrium (PTE) token selection.

**Objective function (pure mathematical notation):**

Given a set of points \(\{x_i\}_{i=1}^N \subset \mathbb{R}^d\) and an integer \(k \ll N\), let \(Z = V^T X\) be the projection onto the top-\(r\) principal subspace obtained by PCA, where \(X\) is the centered data matrix and \(V\) is the \(d \times r\) matrix of orthonormal basis vectors.  
Let \(R = \{r_j\}_{j=1}^k \subset \mathbb{R}^r\) be \(k\) reference points drawn uniformly from the unit sphere and scaled to match the scale of \(Z\).  
Define the cost matrix \(C_{ij} = \|z_i - r_j\|_2^2\).  
We seek to select a subset \(S \subset \{1,\dots,N\}\) of size \(k\) that emerges from the entropic optimal transport (OT) equilibrium between the empirical measure \(\mu = \frac{1}{N}\sum_i \delta_{z_i}\) and the reference measure \(\nu = \frac{1}{k}\sum_j \delta_{r_j}\).  
The equilibrium coupling \(P^*\) solves
\[
\min_{P \in \Pi(\mu,\nu)} \; \langle C, P \rangle - \varepsilon H(P),\qquad
\Pi(\mu,\nu)=\{P \in \mathbb{R}_+^{N\times k} \mid P\mathbf{1}_k = \tfrac{1}{N}\mathbf{1}_N,\; P^T\mathbf{1}_N = \tfrac{1}{k}\mathbf{1}_k\},
\]
where \(H(P) = -\sum_{i,j} P_{ij}(\log P_{ij} - 1)\) is the entropy regularizer and \(\varepsilon > 0\) is a temperature.  
The final selection is obtained by a deterministic rounding of \(P^*\): each reference point \(r_j\) is assigned to a distinct token \(i(j)\) via the greedy majority rule
\[
\text{selected\_indices} = \mathrm{GreedyMatch}\big(\mathop{\arg\max}_{i} P_{ij} \text{ with conflict resolution}\big).
\]

**Key point:** The Sinkhorn algorithm that solves the above regularized OT problem consists entirely of alternating Bregman projections onto the marginal constraints, which makes the core selection operator a **projection** operator.

---

**2. Mathematical Formalization & Mapping Argument**

**a) Formalizing visual token selection as a pure mathematical problem**  

We are given a set of \(N\) points in \(\mathbb{R}^d\). We want to choose a subset of size \(k\) that is “representative” in a geometric sense and also diverse.  
Formally, we treat the selection as an equilibrium allocation problem in a transport economy:

- Every token (point) is endowed with \(1/N\) unit of “probability mass”.
- There are \(k\) distinct “slots” (ideal locations in a low-dimensional latent manifold), each offering a uniform supply of \(1/k\) unit of “capacity”.
- The cost of transporting a unit of mass from token \(i\) to slot \(j\) is the squared Euclidean distance between their projected representations.
- The equilibrium of this economy is a transport plan \(P\) that clears the market while maximizing total surplus (i.e., minimizing transport cost) under the entropy incentive.

The resulting allocation, after rounding, determines exactly which \(k\) tokens are assigned to the slots, thereby selecting a diverse and geometrically faithful subset.

**b) Why the recalled mathematical theory is a NATURAL solution**  

The recalled theory (nonlinear dimensionality reduction, manifold learning, optimal transport, and Sinkhorn’s algorithm) directly addresses two core requirements:
1. **Geometric structure preservation:** PCA projection captures the global variance of the token manifold, making the low-dimensional coordinates \(z_i\) reliable summary statistics of the original features.
2. **Diverse, non‑greedy selection:** The regularised OT problem finds a global coupling that balances individual costs with the collective diversity constraint (each slot gets exactly one token). The Sinkhorn algorithm, which is a sequence of **projections** onto row‑sum and column‑sum constraints, naturally implements this global allocation without collapsing into a trivial per‑token ranking.

Thus, the algorithm is fully grounded in manifold geometry and the theory of optimal transport, with the selection operator being a pure projection (Sinkhorn’s alternative projections).

**c) Computational Steps → PyTorch mapping**  

| Theoretical step | PyTorch realisation |
|------------------|---------------------|
| Center data matrix | `X_c = X - X.mean(0)` |
| PCA – top‑\(r\) eigenvectors | `cov = X_c.T @ X_c / N`; `eigvals, eigvecs = torch.linalg.eigh(cov)`; `V = eigvecs[:, -r:]` (computations in `float32`) |
| Projections \(z_i = V^T x_i\) | `Z = X_c @ V` |
| Generate \(k\) reference points on the unit sphere | `R_raw = torch.randn(k, r)`; `R_norm = R_raw / R_raw.norm(dim=1, keepdim=True)`; scale `s = torch.median(torch.norm(Z, dim=1))` → `R = R_norm * s` |
| Cost matrix \(C_{ij} = \|z_i - r_j\|^2\) | `C = torch.cdist(Z, R, p=2).pow(2)` |
| Sinkhorn iterations (Bregman projections) | `K = torch.exp(-C / eps)`; initialise `u = 1/N`, `v = 1/k`; iterate: `u = a / (K @ v + 1e-8)`, `v = b / (K.T @ u + 1e-8)` (with masking if necessary). Finally `P = u.unsqueeze(1) * K * v.unsqueeze(0)` |
| Greedy assignment from \(P\) | Sort columns by decreasing `max(P, axis=0)`; for each column assign token with highest \(P\) among still‑available tokens. |

---

**3. Concrete forward computation graph and PyTorch pseudocode**

```python
def select_pixel_pte(
    vision_tokens_clip: torch.Tensor,   # [N, 1280]  CLIP features
    vision_tokens: torch.Tensor,        # [N, 3584]  LLM‑space features (used only for output gathering)
    target_vision_tokens: int,
    r: int = 16,
    eps_mult: float = 0.1,
    sinkhorn_iters: int = 50,
):
    N, d = vision_tokens_clip.shape
    k = target_vision_tokens
    device = vision_tokens_clip.device
    dtype_clip = vision_tokens_clip.dtype

    # ---- Boundary conditions ----
    if k == 0:
        return vision_tokens.new_zeros(0, dtype=torch.long), vision_tokens.new_zeros(0, 3584)
    if k >= N:
        # fallback: keep all tokens
        return torch.arange(N, device=device), vision_tokens

    # ---- Step 1: centre & PCA (float32 for stability) ----
    X = vision_tokens_clip.to(torch.float32)          # [N, d]
    X_c = X - X.mean(dim=0, keepdim=True)
    cov = (X_c.t() @ X_c) / N                        # [d, d]
    eigvals, eigvecs = torch.linalg.eigh(cov)         # ascending order
    V = eigvecs[:, -r:]                               # [d, r]  top-r eigenvectors
    Z = X_c @ V                                        # [N, r]

    # ---- Step 2: reference points on unit sphere ----
    R_raw = torch.randn(k, r, device=device, dtype=torch.float32)
    R_norm = R_raw / (R_raw.norm(dim=1, keepdim=True) + 1e-8)
    # scale to match token cloud
    token_norms = Z.norm(dim=1)
    s = torch.median(token_norms)
    R = R_norm * (s + 1e-6)

    # ---- Step 3: cost matrix ----
    C = torch.cdist(Z, R, p=2).pow(2)                 # [N, k]

    # ---- Step 4: Sinkhorn (entropic OT) ----
    eps_val = eps_mult * torch.median(C[C > 0])       # avoid zero
    K = torch.exp(-C / eps_val)                       # kernel matrix
    a = torch.full((N,), 1.0/N, device=device, dtype=torch.float32)
    b = torch.full((k,), 1.0/k, device=device, dtype=torch.float32)
    u = a.clone()
    v = b.clone()
    for _ in range(sinkhorn_iters):
        u = a / (K @ v + 1e-12)
        v = b / (K.t() @ u + 1e-12)
    P = u.unsqueeze(1) * K * v.unsqueeze(0)           # [N, k]

    # ---- Step 5: deterministic assignment (greedy max per column) ----
    # Break ties by giving priority to columns with higher max P
    max_vals, max_idx = P.max(dim=0)                  # [k]
    order = torch.argsort(max_vals, descending=True)
    selected = set()
    selected_indices_list = []
    for j in order:
        # candidates sorted by P descending in this column
        candidates = torch.argsort(P[:, j], descending=True).tolist()
        for cand in candidates:
            if cand not in selected:
                selected.add(cand)
                selected_indices_list.append(cand)
                break
    if len(selected_indices_list) < k:
        # extreme fallback: pad with unseen tokens (should not happen)
        remain = [i for i in range(N) if i not in selected]
        for i in remain[: (k - len(selected_indices_list))]:
            selected_indices_list.append(i)
    selected_indices = torch.tensor(selected_indices_list, device=device, dtype=torch.long)
    selected_image_embeds = vision_tokens[selected_indices]

    return selected_indices, selected_image_embeds
```

**Boundary handling in the pseudocode:**
- `k == 0` returns empty tensors.
- `k >= N` returns all indices.
- Eigen‑decomposition and Sinkhorn are performed in `float32` for numerical safety; inputs can be `bf16/fp16` but are cast internally.
- Division by zero is guarded by `+ 1e-12` or `+ 1e-8` where needed.
- The greedy assignment loop always produces `k` distinct indices; the fallback at the end is a safety net.

---

**4. Key hyperparameter suggestions**

- `r = 16` (PCA subspace dimensionality) – captures ~95% of CLIP feature variance and keeps the transport problem small.
- `eps_mult = 0.1` – temperature relative to median cost. A smaller value (e.g. 0.05) makes the assignment closer to hard matching, a larger one (0.2) increases entropy and smoothens the coupling.
- `sinkhorn_iters = 50` – plenty for convergence at this scale; can be reduced to 20–30 for speed if needed.

---

**5. Numerical stability precautions**

- **Eigendecomposition:** `torch.linalg.eigh` on a 1280×1280 matrix is stable in `float32`. The projection matrix `V` is orthogonal by construction; no gradient is required so precision loss through bf16 is irrelevant.
- **Sinkhorn kernel:** The exponential may underflow if `eps_val` is too small. Using `eps_val = 0.1 * median(C[C>0])` guarantees that the largest values of `-C/eps` are around -10, so `exp` stays above \(e^{-10} \approx 5\times10^{-5}\), well within safe range. The division steps have a small epsilon additive term to avoid infinite results.
- **Zero‑norm tokens:** If every token is the zero vector, PCA will produce zero eigenvalues; then `Z` is all‑zero, token norms are zero, and `s` is zero. In that degenerate case, reference points remain unit‑sphere vectors but further scaled by `s` (→ zero) – this leads to a uniform cost matrix, and the method reduces to a random permutation (still valid). We explicitly add `1e-6` to `s` to avoid division by zero in scaling.
- **Device/dtype consistency:** All intermediates are kept on the same device and in `float32` until the final selection; the output `selected_image_embeds` is gathered from the original `vision_tokens` (dtype unchanged).

---

**6. Cited theoretical sources**

- Nonlinear dimensionality reduction (manifold learning, PCA) – *Wikipedia, “Nonlinear dimensionality reduction”*, used for the projection onto the top principal subspace.
- Optimal transport and Sinkhorn’s algorithm – implicitly referenced from the broader OT literature; the projection nature of Sinkhorn (alternating Bregman projections) is a classic result.
- Dimensionality reduction and kernel PCA – *Wikipedia, “Dimensionality reduction”*, supporting the use of linear PCA as a feature extraction step.

All mechanisms belong to the **geometry** domain, with the selection operator being a **projection** (Sinkhorn’s iterative normalisation).

---

**7. Difference explanation from historical schemes**

- **Not “K‑Means + distance ranking”:** No cluster centroids are computed; reference points are isotropically distributed on a sphere, and the selection follows a global transport plan, not simple nearest‑centroid assignment.
- **Not “RandomProjection + Top‑K”:** The random projection is only used to generate reference points, not to score individual tokens. The selection emerges from the OT coupling, which implicitly balances all tokens against all references.
- **Not “FPS + Norm weighting”:** The method is non‑greedy; it solves a convex regularised OT problem whose optimum provides a fractional coupling, and the final deterministic assignment is extracted in one pass after convergence.

The core innovation is the use of entropic optimal transport with projected token features and randomly drawn reference anchors, solved by the purely projection‑based Sinkhorn algorithm, which formally satisfies the projection mechanism requirement.

---

**8. Primary Direction Declaration**

PRIMARY_DIRECTION: projection