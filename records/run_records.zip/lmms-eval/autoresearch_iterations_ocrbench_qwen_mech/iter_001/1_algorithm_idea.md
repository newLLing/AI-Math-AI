Algorithm name: **Metric Reconstruction via Density–Peak Selection (MRDPS)**  
Mathematical objective function (pure notation):  
Let \(X = \{x_1,\dots,x_N\}\subset \mathbb{R}^{d}\) be a point cloud in a metric space with distance \(d(\cdot,\cdot)\). For a subset \(S\subseteq X\), \(|S|=k\), define the reconstruction error  
\[
E(S) = \sum_{x\in X} \min_{s\in S} d(x,s),
\]  
the sum of distances from each point to its nearest selected point (nearest-neighbour reconstruction). The goal is  
\[
\min_{S\subset X,\,|S|=k} E(S).
\]  
This is the \(k\)-medoids problem (also related to rate‑distortion / vector quantization). We solve it approximately by scoring each point with a **distance‑metric** derived quantity, without iterative greedy steps.

---

### 2. Mathematical Formalization & Mapping Argument

a. **Formalization as a pure optimisation problem**  
Given a finite metric space \((X,d)\) and an integer \(k\;(1\le k\le N)\), find a subset \(S\subseteq X\) with \(|S|=k\) that minimises the average (or total) reconstruction error when every point \(x\in X\) is represented by its closest point in \(S\).  
The problem is NP‑hard in general, but a powerful heuristic is the **density‑peak clustering** paradigm, which selects points that simultaneously have high local density and large distance to any point of higher density. These two quantities depend solely on the pairwise distances, i.e., on the metric.

b. **Why the recalled theory is a natural solution**  
Metric spaces provide exactly the language needed: a distance function \(d\) that satisfies positivity, symmetry and the triangle inequality. The triangle inequality guarantees that if a point is close to a selected centre and far from another point, the two points are separated, so centres can cover distinct regions. The density‑peak method constructs a purely distance‑based importance score (\(\gamma = \rho\times\delta\)), turning the combinatorial optimisation into a simple ranking – a genuine **distance‑metric** selection operator that directly exploits the metric structure without any projection, entropy, or greedy coverage loop.

c. **Computational steps → PyTorch mapping**  

1. Pairwise Euclidean distance matrix → `torch.cdist(features, features)`  
2. Cutoff distance \(d_c\) → `torch.quantile(D_upper.flatten(), q)`  
3. Local density \(\rho_i = \sum_j \exp(-(d_{ij}/d_c)^2)\) → element‑wise `exp` and `sum` along dim  
4. For each point, \(\delta_i = \min_{j:\rho_j>\rho_i} d_{ij}\) (and \(\max_j d_{ij}\) for the global density maximum) → a double loop or vectorised masked `min` (see pseudocode)  
5. Score \(\gamma_i = \rho_i \times \delta_i\) → element‑wise multiplication  
6. Top‑\(k\) indices → `torch.topk(gamma, k)`

d. **Difference from vanilla templates**  
This is **not** FPS (no greedy farthest‑point loop), not random projection + TopK, not KMeans, and not any dot‑product‑based similarity. The core selection operator is a distance‑metric derived scalar (\(\gamma\)) that measures both representativeness and separation, computed globally without iterative subset refinement.

---

### 3. Concrete forward computation graph and PyTorch pseudocode

```python
import torch
import torch.nn.functional as F

def select_tokens_mrdps(
    image_features: torch.Tensor,      # [N, 1280] CLIP space
    image_embeds: torch.Tensor,        # [N, 3584] projector output
    target_vision_tokens: int,         # k
    q: float = 0.02,                   # quantile for cutoff distance
    eps: float = 1e-8
):
    """
    image_features: primary signal, used to compute metric-based scores.
    image_embeds:   only used to gather the final selected embeddings.
    Returns: selected_indices (LongTensor), selected_image_embeds (Tensor)
    """
    N, d = image_features.shape
    k = min(target_vision_tokens, N)

    # --- Boundary conditions ---
    if k <= 0:
        # Return empty selection
        return torch.empty(0, dtype=torch.long, device=image_features.device), \
               torch.empty(0, *image_embeds.shape[1:], dtype=image_embeds.dtype, device=image_embeds.device)
    if k >= N:
        return torch.arange(N, device=image_features.device), image_embeds

    # --- Step 1: Pairwise distances (Euclidean) ---
    # Ensure float32 for numerical stability
    features = image_features.to(torch.float32)
    D = torch.cdist(features, features, p=2.0)   # [N, N]

    # --- Step 2: Cutoff distance d_c ---
    # Use upper-triangular part to avoid duplicates and zeros on diagonal
    triu_idx = torch.triu_indices(N, N, offset=1)
    D_upper = D[triu_idx[0], triu_idx[1]]        # N*(N-1)/2
    if D_upper.numel() == 0:
        # N==1 edge case
        return torch.tensor([0], device=features.device), image_embeds[:1]

    d_c = torch.quantile(D_upper, q) + eps       # avoid d_c=0

    # --- Step 3: Local density (Gaussian kernel) ---
    rho = torch.sum(torch.exp(- (D / d_c) ** 2), dim=1)  # [N]

    # --- Step 4: Delta (distance to nearest point of higher density) ---
    # Sort indices by density descending to obtain ordering
    order = torch.argsort(rho, descending=True)
    delta = torch.empty(N, dtype=features.dtype, device=features.device)
    # For the point with highest density, delta = max distance to any other point
    max_density_idx = order[0]
    delta[max_density_idx] = D[max_density_idx].max()

    # For all other points: find min distance to any point with higher density
    # We can loop; O(N^2) overall but N is moderate
    for i in range(1, N):
        idx_i = order[i]
        # Indices of points with higher density than idx_i
        higher_mask = rho > rho[idx_i]           # [N] bool
        # If no higher density (should not happen due to unique max), fallback
        if not higher_mask.any():
            delta[idx_i] = D[idx_i].max()
        else:
            delta[idx_i] = D[idx_i][higher_mask].min()

    # --- Step 5: Gamma score ---
    gamma = rho * delta

    # --- Step 6: Select top-k ---
    _, selected_indices = torch.topk(gamma, k, largest=True)

    # --- Gather embeddings ---
    selected_image_embeds = image_embeds[selected_indices]

    return selected_indices, selected_image_embeds
```

**Boundary condition handling**:

- `target_vision_tokens <= 0`: return empty tensors.

- `target_vision_tokens >= N`: return all indices.

- `N == 1`: D_upper will be empty; handled by special case returning index 0.

- All‑zero embeddings: all distances zero → `d_c` becomes `eps`; `rho` becomes N for all points; `delta` will be tiny (almost 0 because distance to higher‑density point is 0 for all except max‑density point). The max‑density point gets `delta = 0` and others get `delta = 0` too, so gamma is all zeros. We add a tiny jitter to break ties? For safety, if gamma is all equal, topk returns the first k indices arbitrarily (consistent). We can add a tiny random jitter only in that degenerate case: `if gamma.std() < 1e-12: gamma += torch.randn_like(gamma)*1e-6`. Not shown but easily added.

- Device/dtype: `image_features` is cast to float32 for distance computation; `image_embeds` stays in its original dtype (likely fp16/bf16). Output `selected_indices` is `torch.long` on same device.

---

### 4. Key hyperparameter suggestions

- **\(d_c\) quantile \(q\)**: default 0.02 works well for N≈500–1000. For smaller N, use higher quantile (e.g. 0.1) to avoid too few neighbours.
- **Distance metric**: Euclidean (\(p=2\)) is natural; cosine distance could be tried but requires normalisation. Euclidean after L2‑normalisation may be equivalent to cosine distance.
- **Gaussian bandwidth**: the kernel \(e^{-(d/d_c)^2}\) can be replaced by a flat kernel \(\mathbf{1}_{d < d_c}\); Gaussian is smoother and less sensitive to the exact threshold.

---

### 5. Numerical stability precautions

- **d_c = 0**: if `D_upper` contains only zeros (e.g., all tokens identical), quantile returns 0. Adding `eps = 1e-8` prevents division by zero and infinite exponent.
- **Exponent overflow**: distances can be large → `exp(-large^2)` underflows to 0, which is safe. For safety, clamp distances: `D_clipped = D / d_c` but not necessary because `exp` handles large negative inputs.
- **Mask for higher density**: ensure `higher_mask.any()` before `min()`; fallback to `max` if no higher density exists (handles the max‑density point correctly and any numerical ties).
- **All‑zero gamma**: if all points are identical, gamma may be all zero. Add a tiny random perturbation to gamma before topk to avoid arbitrary selection that could degrade diversity (optional).
- **float16/bf16**: perform all computations in `float32`. Input `image_features` may be in fp16; convert explicitly.

---

### 6. Cited theoretical sources

- **Metric space** (Wikipedia) – definition of distance metrics, triangle inequality.
- **Triangle inequality** (Wikipedia) – foundational property ensuring that distance‑based separation measures are consistent.
- **Density peak clustering** (Rodriguez & Laio, *Science* 2014) – the core idea of selecting points by `rho * delta` using only pairwise distances. This work operates entirely within the metric space framework.

The recalled knowledge (metric space, triangle inequality) provides the axiomatic basis for the distance‑metric selection operator.

---

### 7. Difference explanation from historical schemes

- **Not FPS**: No iterative farthest‑point selection. Scores are computed globally in one shot.
- **Not KMeans‑based**: No centroid updates, no assignment to clusters.
- **Not projection‑based**: No random projection or linear scoring.
- **Not dot‑product/top‑k**: No text conditioning, no similarity to a query.

The mechanism is a pure distance‑metric scoring (`rho` and `delta` derived from pairwise distances) that intrinsically balances local density and global separation, directly targeting the reconstruction objective.

---

### 8. PRIMARY_DIRECTION: geometry

PRIMARY_DIRECTION: geometry