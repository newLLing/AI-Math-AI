# MMTok: Multimodal Coverage Maximization for Efficient Inference of VLMs
# Paper: https://arxiv.org/abs/2508.18264
# Copyright (c) 2025 Zoom Communications, Inc.
# Author: Anonymous
# Licensed under the Apache License, Version 2.0

"""
Qwen2.5-VL algorithm core: query-aware vision token selection.

This file contains the algorithmic core for vision token selection in Qwen2.5-VL.
The Coder Agent modifies the region between ALGORITHM CORE placeholders to experiment
with new selection algorithms, while the model file (qwen2_5_VLmodel_mmtok.py) handles
the fixed post-processing (compaction, padding, position_ids/attention_mask updates).
"""

import torch
import torch.nn.functional as F
from typing import List, Optional, Tuple


class QwenAlgorithmCore:
    """
    Algorithm core for Qwen2.5-VL vision token selection.

    Separates the selection algorithm from the model's forward-pass plumbing,
    enabling safe AutoResearch experiments on the algorithm without risking
    the multimodal sequence post-processing logic.
    """

    def __init__(self, mmtok_core=None):
        self.mmtok_core = mmtok_core

    def select_vision_tokens(
        self,
        image_embeds: torch.Tensor,
        image_features: torch.Tensor,
        question: str = "",
        target_vision_tokens: int = None,
        image_grid_thw: torch.Tensor = None,
        text_token_embedding: torch.Tensor = None,
    ) -> torch.Tensor:
        """
        Select vision tokens for a single sample.

        Args:
            image_embeds: [N, D] mm_projector output embeddings.
            image_features: [N, D] CLIP-space vision features.
            question: Question text string.
            target_vision_tokens: Target number of tokens to retain.
            image_grid_thw: [3] or [num_images, 3] grid shape (optional).

        Returns:
            selected_indices: [K] torch.long, indices of selected vision tokens.
        """
        if target_vision_tokens is None:
            target_vision_tokens = getattr(
                self.mmtok_core, "target_vision_tokens", 64
            )

        # --- ALGORITHM CORE START ---
        # Evolutionary Facility Location Selection (EFLS)
        # k‑medoids diversity selection in CLIP space using an evolutionary meta‑heuristic

        import torch

        N = image_embeds.shape[0]
        k = target_vision_tokens

        # Constants (fixed hyper‑parameters)
        population_size = 10
        generations = 20
        mutation_prob = 0.1
        seed = 42

        # Convert CLIP features to float32 and normalise for cosine distance
        feat = image_features.float()
        norm = feat.norm(dim=1, keepdim=True).clamp_min(1e-12)
        feat_norm = feat / norm

        # Precompute pairwise cosine distance matrix (N x N) in float32
        D = 1.0 - feat_norm @ feat_norm.T.to(feat_norm.dtype)
        D = D.clamp_min(0.0)

        # Fitness function: negative sum of minimum distances (higher is better)
        def fitness(subset):
            # subset: (k,) LongTensor
            dists = D[subset]          # (k, N)
            min_dists, _ = torch.min(dists, dim=0)  # (N,)
            return -min_dists.sum()

        # Deterministic initialisation with reproducibility
        torch.manual_seed(seed)
        pop = []
        for _ in range(population_size):
            idx = torch.randperm(N, device=image_embeds.device)[:k]
            pop.append(idx)

        pop_fitness = torch.stack([fitness(sub) for sub in pop])

        # Evolutionary loop
        for gen in range(generations):
            # Tournament selection (size 2)
            parent1_idx = torch.randint(0, population_size, (population_size,), device=image_embeds.device)
            parent2_idx = torch.randint(0, population_size, (population_size,), device=image_embeds.device)

            f1 = pop_fitness[parent1_idx]
            f2 = pop_fitness[parent2_idx]
            mask = f2 > f1
            parent_idx = torch.where(mask, parent2_idx, parent1_idx)
            parents = [pop[i] for i in parent_idx.tolist()]

            children = []
            for i in range(population_size):
                p1 = parents[i]
                p2 = parents[(i + 1) % population_size]

                # Crossover: Farthest Point Sampling (FPS) on union
                union = torch.unique(torch.cat([p1, p2]))
                if union.shape[0] <= k:
                    child = union.clone()
                else:
                    # FPS within union
                    start_idx = int(torch.randint(0, union.shape[0], (1,), device=image_embeds.device).item())
                    selected = [union[start_idx].item()]
                    dist_to_selected = D[selected[0], union]
                    for _ in range(k - 1):
                        farthest = int(torch.argmax(dist_to_selected).item())
                        selected.append(union[farthest].item())
                        new_dists = D[union[farthest], union]
                        dist_to_selected = torch.minimum(dist_to_selected, new_dists)
                    child = torch.tensor(selected, dtype=torch.long, device=image_embeds.device)

                # Mutation: replace a few tokens with random ones not already in the child
                mutate_mask = torch.rand(k, device=image_embeds.device) < mutation_prob
                if mutate_mask.any():
                    # Build list of available indices (not in current child)
                    child_set = set(child.tolist())
                    available = torch.tensor(
                        sorted(set(range(N)) - child_set),
                        dtype=torch.long,
                        device=image_embeds.device
                    )
                    if available.shape[0] > 0:
                        replacement = available[
                            torch.randperm(available.shape[0], device=image_embeds.device)[:mutate_mask.sum()]
                        ]
                        child[mutate_mask] = replacement

                children.append(child)

            children_fitness = torch.stack([fitness(ch) for ch in children])

            # Elitism: keep the best across parents + children
            all_subsets = pop + children
            all_fitness = torch.cat([pop_fitness, children_fitness])
            _, topk_idx = torch.topk(all_fitness, population_size)
            pop = [all_subsets[i] for i in topk_idx.tolist()]
            pop_fitness = all_fitness[topk_idx]

        # Select the best individual from the final population
        best_idx = int(torch.argmax(pop_fitness).item())
        selected_indices = pop[best_idx]
        # Sort in ascending order as required by the framework
        selected_indices = selected_indices.sort()[0]

        # --- ALGORITHM CORE END ---

        return selected_indices

    def select_vision_tokens_batch(
        self,
        image_embeds_list,
        image_features_list,
        questions,
        target_vision_tokens_list,
        image_grid_thw_list=None,
    ):
        """
        Select vision tokens for a batch of samples.

        Args:
            image_embeds_list: List of [N_i, D] tensors.
            image_features_list: List of [N_i, D] tensors.
            questions: List of question strings.
            target_vision_tokens_list: List of target token counts.
            image_grid_thw_list: Optional list of grid shapes.

        Returns:
            selected_indices_list: List of [K_i] tensors.
        """
        selected_indices_list = []
        n = len(image_embeds_list)
        for i in range(n):
            emb = image_embeds_list[i]
            feat = image_features_list[i]
            q = questions[i] if i < len(questions) else questions[-1]
            tgt = (
                target_vision_tokens_list[i]
                if i < len(target_vision_tokens_list)
                else target_vision_tokens_list[-1]
            )
            grid = None
            if image_grid_thw_list is not None and i < len(image_grid_thw_list):
                grid = image_grid_thw_list[i]

            selected_indices = self.select_vision_tokens(
                emb, feat, q, target_vision_tokens=tgt, image_grid_thw=grid
            )
            selected_indices_list.append(selected_indices)

        return selected_indices_list


# ---------------------------------------------------------------------------
# AutoResearchSelector wrapper
# ---------------------------------------------------------------------------
# mmtok/qwen/mmtok_core.py imports AutoResearchSelector from this module and
# expects it to expose the same interface as the selectors in mmtok/qwen/
# (i.e. __init__(target_vision_tokens, alpha) and mm_coverage_selection(...)).
# The QwenAlgorithmCore class above is the actual target that the Coder Agent
# patches; this thin wrapper adapts it to the interface expected by MMTokCore.
# ---------------------------------------------------------------------------


class AutoResearchSelector:
    """
    Adapter that exposes the MMTok selector interface on top of
    QwenAlgorithmCore (the file that the AutoResearch Coder Agent modifies).
    """

    def __init__(self, target_vision_tokens: int = 32, alpha: float = 0.5):
        self.target_vision_tokens = target_vision_tokens
        self.alpha = alpha
        # QwenAlgorithmCore only needs mmtok_core for a default
        # target_vision_tokens fallback; passing None is safe because we always
        # supply target_vision_tokens explicitly in the call below.
        self._core = QwenAlgorithmCore(mmtok_core=None)

    def mm_coverage_selection(
        self,
        text_token_embedding: torch.Tensor,
        vision_tokens: torch.Tensor,
        vision_tokens_clip: torch.Tensor,
        tv_temp: float = 0.01,
        vv_temp: float = 0.2,
        padding_patch_indices: Optional[List[int]] = None,
    ) -> Tuple[List[int], torch.Tensor]:
        """
        Run the algorithm core and return results in the format expected by
        MMTokCore.select_vision_tokens.

        Args / Returns follow the contract of the other selectors in
        mmtok/qwen/ (e.g. semantic_selector.py).
        """
        # QwenAlgorithmCore.select_vision_tokens returns a [K] torch.long tensor.
        selected_indices_tensor = self._core.select_vision_tokens(
            image_embeds=vision_tokens,
            image_features=vision_tokens_clip,
            question="",
            target_vision_tokens=self.target_vision_tokens,
            text_token_embedding=text_token_embedding,
        )

        # Convert to Python list to match the selector contract.
        selected_indices = selected_indices_tensor.tolist()
        # Guard against scalar tensor (when only one index is selected).
        if not isinstance(selected_indices, list):
            selected_indices = torch.tensor([selected_indices], dtype=torch.long, device=image_embeds.device)
        selected_tokens = vision_tokens[selected_indices_tensor]
        return selected_indices, selected_tokens
