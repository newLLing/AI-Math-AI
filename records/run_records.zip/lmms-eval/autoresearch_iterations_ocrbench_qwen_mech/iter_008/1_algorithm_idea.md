**Algorithm name:** Evolutionary Facility Location Selection (EFLS) — a “geometry + evolution” approach to pure‑diversity token reduction.

**Mathematical objective function (pure notation)**  
Let \(V = \{v_1, v_2, \dots, v_N\} \subset \mathbb{R}^{d}\) (the set of CLIP‑space features, \(d=1280\)), with a non‑negative distance function \(d(v,u)\) (e.g. cosine distance). For any subset \(S \subseteq V\) with \(|S| = k\), define the **coverage loss**

\[
\mathcal{L}(S) = \sum_{v \in V} \min_{s \in S} d(v,s).
\]

The token selection problem is

\[
S^* = \arg\min_{\substack{S \subset V \\ |S| = k}} \mathcal{L}(S),
\]

i.e. the classical \(k\)-medoids / facility location problem on the metric space \((V, d)\).  
The algorithm searches for an approximate solution using an evolutionary meta‑heuristic.

---

### 2. Mathematical Formalization & Mapping Argument

**a. Formalization as a pure optimisation problem**  
We have a finite metric space \((V, d)\). The goal is to choose a subset of size \(k\) that *covers* the whole space as well as possible, where coverage is measured by the sum of distances from each point to its nearest chosen representative. This is a purely geometric, combinatorial optimisation problem; no mention of tokens, vision or neural networks is needed.

**b. Why the recalled theory suggests a natural solution**  
- The recalled theory (Abdurakhmanov 2025) introduces the notion of **metric density** – a subset that minimises its “combinatorial rank” among all isometric copies in a Hamming cube. The rank is the number of non‑constant columns after alignment; it quantifies how **redundantly** the subset can be encoded. A metrically dense subset is one that *cannot be compressed into many constant columns*, i.e. it has high intrinsic dimensionality and therefore strong covering properties. In continuous spaces, the covering loss \(\mathcal{L}(S)\) plays an analogous role: a subset that yields a small \(\mathcal{L}(S)\) forces every point in \(V\) to be close to some chosen element, i.e. it acts as a “dense” sample of the metric space.  
- The evolutionary computation paradigm (mutation, crossover, selection) is a principled way to explore the vast combinatorial space of subsets when the objective is not submodular or convex. It mimics the natural dynamics of **population mutation and selection** that drive adaptation – a perfect match for the “geometry + evolution” cell we must instantiate.  

**c. Computational steps and their PyTorch mapping**  

| Theory step | Concrete PyTorch / Python implementation |
|-------------|-------------------------------------------|
| Compute pairwise distance matrix \(D\) from \(V\) | Normalise `image_features` to unit length; `D = 1 - image_features_clip @ image_features_clip.T` |
| Initialise population of \(P\) subsets of size \(k\) | `for i in range(P): pop[i] = torch.randperm(N)[:k]` (deterministic with a fixed seed) |
| Evaluate fitness \(f(S)=-\mathcal{L}(S)\) | For subset indices, gather rows of \(D\) → `dist_vec = D[subset, :]`; `f = -torch.min(dist_vec, dim=0).values.sum()` |
| Tournament selection (pick two parents) | `idx1 = torch.randint(P, ...)`; compare fitness; choose the one with larger fitness |
| Crossover: create child from two parent subsets | Union of both subsets, then apply **Farthest Point Sampling (FPS)** on the union (using \(D\)) to select \(k\) most diverse points. FPS: start with random point from union, then greedily add point that maximises distance to already selected set. |
| Mutation | For each token in child, with probability \(p_m\) replace it by a random token from \(V\) not yet in the child. |
| Elitism: keep top‑\(P\) individuals from parents+children | Stack all fitnesses, `torch.argsort(descending=True)[:P]` |
| Output best subset | `selected_indices = best_subset`; `selected_image_embeds = image_embeds[selected_indices]` |

All heavy linear‑algebra operations are done on the precomputed distance matrix; the evolutionary loop uses only indexing, min‑reduction, and torch‑rand operations.

---

### 3. Concrete Forward Computation Graph and PyTorch Pseudocode

```python
def evolutionary_facility_location_select(
    image_features: torch.Tensor,   # [N, d_clip] in CLIP space
    image_embeds: torch.Tensor,     # [N, d_llm] projector output (same token count)
    target_k: int,
    population_size: int = 10,
    generations: int = 20,
    mutation_prob: float = 0.1,
    seed: int = 42
):
    """
    Pure‑diversity token selection: evolutionary k‑medoids in CLIP space.
    """
    N, d_clip = image_features.shape
    device = image_features.device
    dtype = image_features.dtype

    # Edge cases
    if target_k <= 0:
        return torch.empty(0, dtype=torch.long, device=device), torch.empty(0, image_embeds.shape[1], device=device, dtype=image_embeds.dtype)
    if target_k >= N:
        return torch.arange(N, device=device), image_embeds

    # 1. Precompute pairwise cosine distance matrix (N x N)
    # Normalise CLIP features for cosine similarity
    x_norm = image_features / image_features.norm(dim=1, keepdim=True).clamp_min(1e-12)
    D = 1.0 - x_norm @ x_norm.T   # cosine distance in [0,2]
    # D is symmetric with zero diag; ensure nonnegativity
    D = D.clamp_min(0.0)

    # 2. Initialise population (fixed seed for reproducibility)
    torch.manual_seed(seed)
    pop = []  # list of LongTensors (k,)
    for _ in range(population_size):
        idx = torch.randperm(N, device=device)[:target_k]
        pop.append(idx)
    # fitness = - sum_i min_{j in S} D[j,i]
    def fitness(subset_idx):
        # subset_idx: (k,)
        dists = D[subset_idx, :]       # (k, N)
        min_dists, _ = torch.min(dists, dim=0)  # (N,)
        return -min_dists.sum()        # higher is better

    # Evaluate initial fitness
    pop_fitness = torch.stack([fitness(sub) for sub in pop])  # (P,)

    # 3. Evolutionary loop
    for gen in range(generations):
        # --- Selection (parents) ---
        # Each parent chosen via tournament of size 2
        parent1_idx = torch.randint(0, population_size, (population_size,), device=device)
        parent2_idx = torch.randint(0, population_size, (population_size,), device=device)
        # tournament: pick the one with higher fitness from the pair
        fitness1 = pop_fitness[parent1_idx]
        fitness2 = pop_fitness[parent2_idx]
        mask = (fitness2 > fitness1)   # if parent2 better, use that index
        parent_idx = torch.where(mask, parent2_idx, parent1_idx)  # shape (P,)
        parents = [pop[i] for i in parent_idx.tolist()]  # list of tensors

        children = []
        for i in range(population_size):
            p1 = parents[i]
            p2 = parents[(i+1) % population_size]  # couple with next
            # --- Crossover: FPS on union ---
            union = torch.unique(torch.cat([p1, p2]))  # up to 2k
            if len(union) <= target_k:
                child = union
            else:
                # Farthest Point Sampling within union using D restricted to union
                # Use a simple loop (union size small, ≤2k with k small)
                # Start with a random point
                start_idx = torch.randint(0, len(union), (1,), device=device).item()
                selected = [union[start_idx].item()]
                dist_to_selected = D[selected[0], union]  # (len(union),)
                for _ in range(target_k - 1):
                    # pick farthest
                    farthest = torch.argmax(dist_to_selected).item()
                    selected.append(union[farthest].item())
                    # update distances as min of current and new point's distances
                    new_dists = D[union[farthest], union]
                    dist_to_selected = torch.minimum(dist_to_selected, new_dists)
                child = torch.tensor(selected, device=device, dtype=torch.long)

            # --- Mutation ---
            mutate_mask = torch.rand(target_k, device=device) < mutation_prob
            if mutate_mask.any():
                # replace those positions with random tokens not in child
                current_set = set(child.tolist())
                all_indices = set(range(N))
                available = list(all_indices - current_set)
                if available:
                    replacement = torch.tensor(
                        np.random.choice(available, size=mutate_mask.sum().item(), replace=False),
                        device=device, dtype=torch.long
                    )
                    child[mutate_mask] = replacement

            children.append(child)

        # Evaluate children
        children_fitness = torch.stack([fitness(ch) for ch in children])

        # --- Next generation (elitism) ---
        all_subsets = pop + children
        all_fitness = torch.cat([pop_fitness, children_fitness])
        _, topk_idx = torch.topk(all_fitness, population_size)
        pop = [all_subsets[i] for i in topk_idx.tolist()]
        pop_fitness = all_fitness[topk_idx]

    # 4. Return the best individual
    best_idx = torch.argmax(pop_fitness).item()
    selected_indices = pop[best_idx]                    # LongTensor of length k
    selected_image_embeds = image_embeds[selected_indices]  # [k, d_llm]
    return selected_indices, selected_image_embeds
```

**Boundary conditions handled:**
- `target_k==0` → return empty tensors.
- `target_k >= N` → return all tokens.
- Empty union in crossover (if k=0) – already caught by edge case.
- `available` mutation token set may be empty if child already contains all N tokens; we skip mutation in that branch.
- Division‐by‑zero in normalisation: `clamp_min(1e-12)` prevents zero norms.
- Device/dtype consistency: all tensors stay on the same device and float32; `np.random.choice` uses CPU but we convert back to GPU; a fully GPU‑based alternative would be to sample from `torch.randperm`, but cross‑device is acceptable.

---

### 4. Key Hyperparameters

- **population_size** = 10: enough diversity for 20 generations; can be increased if more exploration is desired.
- **generations** = 20: a balance between convergence and forward‑pass latency.
- **mutation_prob** = 0.1 per token: prevents premature convergence while keeping most structure inherited.
- **Distance metric**: cosine distance in CLIP space. Alternative: squared Euclidean after normalisation.
- **Tournament size** = 2: simple and effective.

---

### 5. Numerical Stability Precautions

- **Zero‑norm vectors**: handled by `clamp_min(1e-12)` during normalisation.
- **Cosine distance** can be slightly negative due to floating point; we clamp to `[0, 2]`.
- **Fitness ties**: `torch.argmax` returns the first occurrence; tie‑breaking is deterministic but may favour earlier individuals.
- **FPS loop** uses `torch.minimum` to update distances; this is stable.
- **Device/dtype**: all operations are done in `float32` on the same device as input; no mixed‑precision issues.

---

### 6. Cited Theoretical Sources

- **Abdurakhmanov (2025)** – “The Combinatorial Rank of Subsets: Metric Density in Finite Hamming Spaces”. Introduces the notion of metric density and inspires the use of geometric coverage as a subset quality measure.
- Classical **facility location / k‑medoids** problem (geometry domain).
- **Evolutionary computation** (mutation, crossover, selection) as a search mechanism.

---

### 7. Difference from Historical Schemes

- It is **not** a greedy distance‑based sampling (FPS) alone; the evolutionary loop actively recombines and mutates subsets, which can escape local optima that single‑pass greedy methods get trapped in.
- It **does not** use any projector‑space or text‑conditioning, staying purely in CLIP space for diversity.
- It replaces the conventional “scoring and sorting” paradigm with a population‑based optimisation driven by a geometric coverage objective, making it a genuinely new algorithmic template.

---

### 8. Primary Direction Declaration
PRIMARY_DIRECTION: geometry