# MMTok: Multimodal Coverage Maximization for Efficient Inference of VLMs
# Paper: https://arxiv.org/abs/2508.18264
# Copyright (c) 2025 Zoom Communications, Inc.
# Author: Anonymous
# Licensed under the Apache License, Version 2.0

"""
Qwen2.5-VL algorithm core: query-aware vision token selection.

This file contains the algorithmic core for vision token selection in Qwen2.5-VL.
The Coder Agent modifies the region between ALGORITHM CORE placeholders to experiment
with new selection algorithms, while the model file (qwen2_5_VLmodel_mmtok.py) handles
the fixed post-processing (compaction, padding, position_ids/attention_mask updates).
"""

import torch
import torch.nn.functional as F
from typing import List, Optional, Tuple


class QwenAlgorithmCore:
    """
    Algorithm core for Qwen2.5-VL vision token selection.

    Separates the selection algorithm from the model's forward-pass plumbing,
    enabling safe AutoResearch experiments on the algorithm without risking
    the multimodal sequence post-processing logic.
    """

    def __init__(self, mmtok_core=None):
        self.mmtok_core = mmtok_core

    def select_vision_tokens(
        self,
        image_embeds: torch.Tensor,
        image_features: torch.Tensor,
        question: str = "",
        target_vision_tokens: int = None,
        image_grid_thw: torch.Tensor = None,
        text_token_embedding: torch.Tensor = None,
    ) -> torch.Tensor:
        """
        Select vision tokens for a single sample.

        Args:
            image_embeds: [N, D] mm_projector output embeddings.
            image_features: [N, D] CLIP-space vision features.
            question: Question text string.
            target_vision_tokens: Target number of tokens to retain.
            image_grid_thw: [3] or [num_images, 3] grid shape (optional).

        Returns:
            selected_indices: [K] torch.long, indices of selected vision tokens.
        """
        if target_vision_tokens is None:
            target_vision_tokens = getattr(
                self.mmtok_core, "target_vision_tokens", 64
            )

        # --- ALGORITHM CORE START ---
        N = image_features.shape[0]
        # Use CLIP-space features as source of vision-vision diversity
        x = F.normalize(image_features, p=2, dim=1).float()  # [N, d]
        d = x.shape[1]
        L = 32  # number of random projections
        lambda_ = 0.1  # risk penalty weight

        # Generate L random unit vectors
        W = torch.randn(d, L, device=image_features.device, dtype=torch.float32)
        W = W / W.norm(dim=0, keepdim=True)  # unit sphere

        # Project all points
        proj = x @ W.to(x.dtype)  # [N, L]

        # --- First selection: maximum variance across projections ---
        var_proj = proj.var(dim=1)  # [N]
        first_idx = var_proj.argmax().item()
        selected = [first_idx]

        if target_vision_tokens > 1:
            # Initialize min distance with distance to the first selected point
            # (distances are unsigned, larger = better)
            min_dist = (proj - proj[first_idx:first_idx+1]).abs()  # [N, L]
            # For remaining k-1 points
            for _ in range(1, target_vision_tokens):
                # Mask already selected tokens
                mask = torch.ones(N, dtype=torch.bool, device=image_features.device)
                mask[selected] = False
                cand_indices = mask.nonzero(as_tuple=True)[0]  # shape [C]

                # Utility values for candidates in each projection
                util_c = min_dist[cand_indices]  # [C, L]   (larger is better)

                # Compute dense ranks per projection (descending: largest -> rank 1)
                C = cand_indices.shape[0]
                ranks = torch.empty(C, L, dtype=torch.long, device=image_features.device)
                for l in range(L):
                    col = util_c[:, l]  # [C]
                    # sort descending
                    sorted_idx = torch.argsort(-col)  # ascending of -col => descending
                    sorted_col = col[sorted_idx]
                    # mark where distinct values appear
                    first = torch.tensor([True], device=image_features.device)
                    distinct = torch.cat([first, sorted_col[1:] != sorted_col[:-1]])
                    # dense rank values
                    rank_vals = distinct.cumsum(dim=0)
                    # invert the sort to assign ranks back to original indices
                    inv_idx = torch.empty_like(sorted_idx)
                    inv_idx[sorted_idx] = torch.arange(C, device=image_features.device)
                    ranks[:, l] = rank_vals[inv_idx]

                # Mean and std rank across projections
                ranks_f = ranks.float()
                mean_r = ranks_f.mean(dim=1)  # [C]
                std_r = ranks_f.std(dim=1)    # [C]
                score = mean_r + lambda_ * std_r  # lower is better

                best_in_cand = score.argmin().item()
                best_idx = cand_indices[best_in_cand].item()
                selected.append(best_idx)

                # Update min distances with the newly selected point
                new_dist = (proj - proj[best_idx:best_idx+1]).abs()
                min_dist = torch.min(min_dist, new_dist)

        # Sort indices to maintain original spatial/sequential order
        selected_indices = torch.tensor(sorted(selected), dtype=torch.long, device=image_features.device)
        # --- ALGORITHM CORE END ---

        return selected_indices

    def select_vision_tokens_batch(
        self,
        image_embeds_list,
        image_features_list,
        questions,
        target_vision_tokens_list,
        image_grid_thw_list=None,
    ):
        """
        Select vision tokens for a batch of samples.

        Args:
            image_embeds_list: List of [N_i, D] tensors.
            image_features_list: List of [N_i, D] tensors.
            questions: List of question strings.
            target_vision_tokens_list: List of target token counts.
            image_grid_thw_list: Optional list of grid shapes.

        Returns:
            selected_indices_list: List of [K_i] tensors.
        """
        selected_indices_list = []
        n = len(image_embeds_list)
        for i in range(n):
            emb = image_embeds_list[i]
            feat = image_features_list[i]
            q = questions[i] if i < len(questions) else questions[-1]
            tgt = (
                target_vision_tokens_list[i]
                if i < len(target_vision_tokens_list)
                else target_vision_tokens_list[-1]
            )
            grid = None
            if image_grid_thw_list is not None and i < len(image_grid_thw_list):
                grid = image_grid_thw_list[i]

            selected_indices = self.select_vision_tokens(
                emb, feat, q, target_vision_tokens=tgt, image_grid_thw=grid
            )
            selected_indices_list.append(selected_indices)

        return selected_indices_list


# ---------------------------------------------------------------------------
# AutoResearchSelector wrapper
# ---------------------------------------------------------------------------
# mmtok/qwen/mmtok_core.py imports AutoResearchSelector from this module and
# expects it to expose the same interface as the selectors in mmtok/qwen/
# (i.e. __init__(target_vision_tokens, alpha) and mm_coverage_selection(...)).
# The QwenAlgorithmCore class above is the actual target that the Coder Agent
# patches; this thin wrapper adapts it to the interface expected by MMTokCore.
# ---------------------------------------------------------------------------


class AutoResearchSelector:
    """
    Adapter that exposes the MMTok selector interface on top of
    QwenAlgorithmCore (the file that the AutoResearch Coder Agent modifies).
    """

    def __init__(self, target_vision_tokens: int = 32, alpha: float = 0.5):
        self.target_vision_tokens = target_vision_tokens
        self.alpha = alpha
        # QwenAlgorithmCore only needs mmtok_core for a default
        # target_vision_tokens fallback; passing None is safe because we always
        # supply target_vision_tokens explicitly in the call below.
        self._core = QwenAlgorithmCore(mmtok_core=None)

    def mm_coverage_selection(
        self,
        text_token_embedding: torch.Tensor,
        vision_tokens: torch.Tensor,
        vision_tokens_clip: torch.Tensor,
        tv_temp: float = 0.01,
        vv_temp: float = 0.2,
        padding_patch_indices: Optional[List[int]] = None,
    ) -> Tuple[List[int], torch.Tensor]:
        """
        Run the algorithm core and return results in the format expected by
        MMTokCore.select_vision_tokens.

        Args / Returns follow the contract of the other selectors in
        mmtok/qwen/ (e.g. semantic_selector.py).
        """
        # QwenAlgorithmCore.select_vision_tokens returns a [K] torch.long tensor.
        selected_indices_tensor = self._core.select_vision_tokens(
            image_embeds=vision_tokens,
            image_features=vision_tokens_clip,
            question="",
            target_vision_tokens=self.target_vision_tokens,
            text_token_embedding=text_token_embedding,
        )

        # Convert to Python list to match the selector contract.
        selected_indices = selected_indices_tensor.tolist()
        # Guard against scalar tensor (when only one index is selected).
        if not isinstance(selected_indices, list):
            selected_indices = torch.tensor([selected_indices], dtype=torch.long, device=image_embeds.device)
        selected_tokens = vision_tokens[selected_indices_tensor]
        return selected_indices, selected_tokens
