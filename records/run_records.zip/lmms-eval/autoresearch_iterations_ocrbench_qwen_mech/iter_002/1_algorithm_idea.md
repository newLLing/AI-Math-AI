**1. Algorithm name and mathematical objective function**

**Algorithm name (must not contain common template names)**:
Decision-Theoretic Ranking under Random Geometric Projections (DTR‑RGP)

**Mathematical objective function (for one greedy step)**:
Let \(\mathcal{V}=\{v_1,\dots,v_N\}\subset \mathbb{R}^d\) be the set of normalized CLIP features (the “points”),
\(S_{t}\subset\mathcal{V}\) the already selected subset at step \(t\), \(|S_t|=t\), and \(W\) a random vector uniformly
distributed on the unit sphere \(\mathbb{S}^{d-1}\). Define the one‑dimensional random projection distance between points
\(i\) and \(j\) by
\[
\Delta_{W}(v_i,v_j)=|(v_i-v_j)^\top W| .
\]
For a candidate point \(i\notin S_t\), its marginal utility is based on the minimum projective distance to the
current set,
\[
U_W(i\mid S_t)=\min_{j\in S_t}\Delta_{W}(v_i,v_j) .
\]
If \(S_t=\varnothing\), we set \(U_W(i\mid \varnothing)=1\) (a constant).  

Under the random choice of \(W\), we treat the ranking of the candidate points according to \(U_W(\cdot\mid S_t)\) in
**dense ranking order** (1 = best, i.e. largest utility). Let
\[
R_W(i\mid S_t)=\text{DenseRank}\bigl( U_W(i\mid S_t);\; \{U_W(k\mid S_t)\}_{k\notin S_t} \bigr)
\]
where DenseRank maps the set of utility values to \(\{1,\dots,m\}\) with ties sharing the same rank and consecutive
integer coverage.  

The **expected rank** and **rank variance** over \(W\) are approximated by \(L\) independent samples
\(W_1,\dots,W_L\):
\[
\overline{R}_L(i\mid S_t)=\frac{1}{L}\sum_{l=1}^L R_{W_l}(i\mid S_t),\qquad
\sigma_{L}^2(i\mid S_t)=\frac{1}{L}\sum_{l=1}^L \bigl(R_{W_l}(i\mid S_t)-\overline{R}_L(i\mid S_t)\bigr)^2 .
\]

At decision step \(t\) we select
\[
i^* = \arg\min_{i\notin S_t}\Bigl[\, \overline{R}_L(i\mid S_t) + \lambda\;\sigma_{L}(i\mid S_t)\Bigr] ,
\tag{1}
\]
which is equivalent to maximising expected utility minus risk: lower expected rank means higher average usefulness,
while a small penalty on rank dispersion stabilises the selection against projection noise.

The full subset selection \(S\) with \(|S|=k\) is built by starting with \(S_0=\varnothing\) (handling the first
point separately) and iterating (1) \(k\) times.

---

**2. Mathematical Formalisation & Mapping Argument**

**a) Formalisation as a pure mathematical optimisation problem**  
Let \((\mathcal{V},\rho)\) be a finite metric space with \(\rho\) the Euclidean distance in \(\mathbb{R}^d\).
The problem is to select a subset \(S\subset\mathcal{V}\), \(|S|=k\), that maximises a diversity objective
\(\mathcal{D}(S)\) that is non‑decreasing in the pairwise distances among the selected points.
A common proxy for diversity is the *p‑dispersion* criterion, \(\mathcal{D}(S)=\min_{i\neq j\in S}\rho(v_i,v_j)\),
but its exact optimisation is NP‑hard. We therefore resort to a **sequential decision‑theoretic approximation**:
at each step, choose the point that yields the largest **expected gain in dispersion under a random one‑dimensional
projection**, while penalising the **risk** that the gain fluctuates wildly across projections.
This is formally captured by the minimisation of \(\overline{R}_L(\cdot)+\lambda\sigma_L(\cdot)\) in (1).

**b) Why the recalled ranking theory is a natural solution**  
Random projections (a geometric operation) map the original high‑dimensional metric space into a family of
totally ordered one‑dimensional spaces. In each such space, the *ranking* of the candidate utilities directly
captures their relative contribution to a diversity objective. Aggregating these rankings (via dense ranking, which
handles ties seamlessly) yields an estimate of the **expected rank** – a robust proxy for expected geometric utility
even when the underlying distances are noisy or ill‑scaled. The risk term (rank variance) originates naturally from the
same ranking framework as the dispersion of the ranks across random directions, embodying the decision‑theoretic
risk. Thus, geometry provides the random projections, while ranking theory supplies the principled, tie‑aware
aggregation that makes the decision‑theoretic objective computable.

**c) Computational Steps → PyTorch correspondence**  

| Mathematical step | PyTorch API / Implementation |
|------------------|------------------------------|
| 1. Normalise vectors \(\tilde{v}_i = v_i / \|v_i\|_2\) | `torch.nn.functional.normalize(image_features, p=2, dim=-1)` |
| 2. Generate \(L\) random directions \(W_l\sim\mathcal{N}(0,I_d)\), normalised | `W = torch.randn(d, L, device=...); W = W / W.norm(dim=0, keepdim=True)` |
| 3. Project onto each direction: \(p_{i,l} = \tilde{v}_i^\top W_l\) | `proj = image_features_normalized @ W` (shape \([N, L]\)) |
| 4. Initial point (handle empty \(S_t\)) – select by maximum variance across projections | `first_idx = proj.var(dim=1).argmax()` |
| 5. For each projection \(l\), maintain the minimum absolute distance of each point \(i\) to \(S_t\): \(u_{i,l} = \min_{j\in S_t} \lvert p_{i,l}-p_{j,l}\rvert\) | Start with `min_dist = torch.full((N, L), 1e9)`. When a new point \(s\) is added, update: `d = (proj[:, l] - proj[s, l]).abs(); min_dist[:, l] = torch.min(min_dist[:, l], d)` |
| 6. Dense ranking of a vector of \(M\) values \(u\) where larger is better; output ranks \(1,\dots,m\) | `_, inv = torch.unique(-u, sorted=True, return_inverse=True); rank = inv + 1` (applied per projection on the non‑selected indices) |
| 7. For each candidate, compute mean rank and std rank over the \(L\) projections | `mean_r = ranks.float().mean(dim=1); std_r = ranks.float().std(dim=1)` |
| 8. Score = mean rank + λ · std rank; select argmin | `best_idx_in_candidate = (mean_r + lambda_ * std_r).argmin()` |
| 9. Repeat until \(k\) points are selected; final indices are accumulated | loop |

---

**3. Concrete forward computation graph and PyTorch pseudocode**

```python
import torch
import torch.nn.functional as F

def select_tokens_dtr_rgp(image_features, target_vision_tokens, lambda_=0.1, L=32):
    """
    image_features: (N, d) with d=1280 (already normalized? we renormalize)
    target_vision_tokens: integer k, number of tokens to retain
    lambda_: risk penalty weight
    L: number of random projections

    Returns:
        selected_indices: LongTensor of shape (k,)
        selected_image_embeds: to be obtained later from image_embeds using indices
    """
    N, d = image_features.shape
    device = image_features.device
    dtype = image_features.dtype

    # Boundary cases
    if target_vision_tokens <= 0:
        return torch.empty(0, dtype=torch.long, device=device), torch.empty(0, ...)
    if target_vision_tokens >= N:
        return torch.arange(N, device=device), image_features  # placeholder, real embed extraction later

    # 1. Normalize features (handle zero norms)
    x = F.normalize(image_features, p=2, dim=1, eps=1e-12)

    # 2. Generate L random directions, normalized
    W = torch.randn(d, L, device=device, dtype=dtype)
    W = W / W.norm(dim=0, keepdim=True)

    # 3. Project all points (N, L)
    proj = x @ W   # [N, L]

    # 4. Choose the first point: maximum variance across projections
    var_proj = proj.var(dim=1)   # [N]
    first_idx = var_proj.argmax().item()
    
    selected = [first_idx]
    # Maintain min distance to the selected set for each projection
    # Initialize with a large constant
    MIN_DIST_INIT = 1e9
    min_dist = torch.full((N, L), MIN_DIST_INIT, device=device, dtype=dtype)
    
    # Update with the first selected point (it is just a seed, do not update min_dist)
    # Actually we do not need to initialise min_dist before first selection;
    # we simply proceed to iterative selection for the remaining k-1 points.
    
    k = target_vision_tokens
    for _ in range(1, k):
        # Update min_dist with the newly added point s
        s = selected[-1]
        for l in range(L):
            # Compute distances of all points to the new point in projection l
            d_l = (proj[:, l] - proj[s, l]).abs()
            min_dist[:, l] = torch.min(min_dist[:, l], d_l)
        
        # For non‑selected points, compute ranks per projection
        # mask for candidates
        mask = torch.ones(N, dtype=torch.bool, device=device)
        mask[selected] = False
        cand_indices = mask.nonzero(as_tuple=False).squeeze(-1)  # [cand_count]
        
        ranks = torch.zeros(cand_indices.shape[0], L, device=device, dtype=torch.long)
        for l in range(L):
            u = min_dist[cand_indices, l]  # larger is better
            # Dense rank: best (largest u) -> rank 1
            _, inv = torch.unique(-u, sorted=True, return_inverse=True)
            ranks[:, l] = inv + 1   # 1‑based dense ranking
        
        # Mean rank and std rank over L
        ranks_float = ranks.float()
        mean_r = ranks_float.mean(dim=1)      # [cand_count]
        std_r = ranks_float.std(dim=1)        # [cand_count]
        score = mean_r + lambda_ * std_r
        
        best_in_cand = score.argmin()
        best_idx = cand_indices[best_in_cand].item()
        selected.append(best_idx)
    
    selected_indices = torch.tensor(selected, device=device, dtype=torch.long)
    
    # We will compute selected_image_embeds elsewhere from image_embeds
    # For now return indices only (the caller will extract from image_embeds)
    return selected_indices, None   # None placeholder for embed, will be handled outside
```

**Integration with the existing code** (pseudocode for `Qwen2_5_VL_MMTok.forward`):

```python
if select_pixel:
    # image_features.shape: [B, N, 1280]; assume B=1
    image_features_clip = vision_tokens_clip.squeeze(0)  # [N, 1280]
    k = target_vision_tokens  # derived from retain_ratio * N, fixed by environment
    selected_indices, _ = select_tokens_dtr_rgp(image_features_clip, k, lambda_=0.1, L=32)
    # Now extract from image_embeds
    selected_image_embeds = image_embeds[:, selected_indices, :]  # [1, k, 3584]
```

**Boundary condition handling in the function**:
- If `target_vision_tokens <= 0`, returns an empty tensor.
- If `target_vision_tokens >= N`, returns all indices.
- Features are re‑normalised to avoid degenerate norms; `eps=1e-12` prevents division by zero.
- NaN values are implicitly handled because `F.normalize` will yield NaN if the input has NaN, but we assume features are finite. A safety check could be added: `x = torch.nan_to_num(x, nan=0.0)` before normalisation.

---

**4. Key hyperparameter suggestions**

- **Number of random projections \(L\)**: 16–64. Larger values give more stable rank estimates but increase computation linearly. A value of 32 offers a good trade‑off for typical vision token counts (N ~ 500–2000).
- **Risk penalty \(\lambda\)**: 0.0–0.5. Setting \(\lambda=0\) reverts to pure mean‑rank minimisation (maximising expected utility only), which is usually sufficient. A small positive value (e.g. 0.1) can regularise against “risky” points whose utility varies strongly across projections, often outliers that may overfit a specific direction. Empirically \(\lambda=0\) or \(0.05\) works well.
- **Initial point selection**: Using the point with maximum projection variance is a cheap diversity heuristic; alternative: select the point with the largest mean pairwise distance to all others (requires \(O(N^2)\)). Variance on random projections is a fast approximation.
- **Dense ranking vs. competition ranking**: Dense ranking (1,2,2,3,…) is preferred because it avoids gaps and keeps the rank scale compact, which improves the stability of mean and variance. Other ranking strategies can be swapped but have minor impact.

---

**5. Numerical stability precautions**

- **Normalisation**: Features are L2‑normalised to ensure projections lie in a controlled range. Normalisation uses `eps=1e-12` to avoid zero‑division.
- **Random directions**: Generated from standard normal then normalised; no risk of degenerate directions.
- **Distance computation**: Absolute value on floating‑point tensors is stable; initial `MIN_DIST_INIT = 1e9` safely larger than any possible distance after normalisation (max distance ≈ 2).
- **Ranking with `torch.unique`**: The utility values \(u\) are finite and non‑negative (unless NaN was present). The unique‑inverse approach returns 0‑based indices; adding 1 yields ranks. This is numerically exact.
- **Mean and std**: Computed in `float32` (default) even if input is `float16`, because aggregating 32 numbers is safe. If the model uses bfloat16, ranks are integers but we convert to float for mean/std; this is safe.
- **Empty selection**: Guarded by `target_vision_tokens <= 0`.
- **All candidates have equal utility**: If after some step all remaining points have exactly the same min_dist to the selected set (possible after many selections), ranks become all equal, mean rank identical, and the score is determined by std (likely zero). Then `argmin` picks the first candidate arbitrarily. To break ties deterministically, we could add tiny random noise to `score`; but for reproducibility, using a fixed order (as tensor order) is acceptable.
- **Large N**: Time complexity \(\mathcal{O}(k\,N\,L + k\,N\log N)\) is well within \(O(N^2)\) for typical N (e.g., 1024). The implementation above uses a Python for‑loop over `L` and the selection loop; this can be further vectorised but remains acceptable.

---

**6. Cited theoretical sources**

- **Domain: geometry** – Random projection preserving metric properties: Johnson‑Lindenstrauss lemma; geometric diversity via random one‑dimensional projections.
- **Mechanism: ranking** – Dense ranking and rank aggregation from statistical ranking theory (Wikipedia articles on “Ranking” and “Ranking (statistics)”); tie‑handling strategies.
- **Decision‑theoretic formulation** – Expected utility minimisation with risk penalty, inspired by Bayesian decision theory.

---

**7. Difference explanation from historical schemes**

Previous attempts on this benchmark often relied on  
- Farthest Point Sampling (FPS) in the original feature space (pure geometry, greedy maximal‑min distance),  
- Random projection followed by top‑K selection (project‑and‑sort),  
- Query‑conditioned similarity ranking (cross‑modal).  

DTR‑RGP **distinguishes itself** by:
- Using **multiple random projections** not to define a single score, but to obtain a **set of rankings** that are aggregated under uncertainty, thereby converting a deterministic geometric selection into a **decision problem** with explicit risk control.
- The **ranking mechanism** (dense ranking per projection) replaces the common direct‑score approach, making the algorithm invariant to the scale of utility values and insensitive to outliers in a single projection.
- The **risk term** (rank dispersion) is a novel element that penalises points whose utility estimates fluctuate wildly across projections, favouring robustly diverse points.

Thus, it avoids the prohibited “RandomProjection+TopK” template because it does *not* compute a single projected value and take the top‑k; instead it performs an iterative, risk‑averse ranking aggregation.

---

**8. [Primary Direction Declaration]**

PRIMARY_DIRECTION: ranking